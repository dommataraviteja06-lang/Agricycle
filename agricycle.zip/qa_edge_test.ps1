# AgriCycle Automated Edge-Case & Boundary Testing Script
# Target: http://localhost:8080

$ErrorActionPreference = "Continue"
$BaseUrl = "http://localhost:8080"
$Results = [System.Collections.Generic.List[PSCustomObject]]::new()

Write-Host "================================================================" -ForegroundColor Cyan
Write-Host "  AgriCycle Edge-Case & Boundary Automated Test Suite" -ForegroundColor Cyan
Write-Host "  Target URL: $BaseUrl" -ForegroundColor Cyan
Write-Host "================================================================" -ForegroundColor Cyan

# Helper function to invoke HTTP requests robustly across PS 5.1 and PS 7
function Invoke-ApiRequest {
    param(
        [string]$Method,
        [string]$Uri,
        [hashtable]$Headers = @{},
        [string]$Body = $null
    )

    $reqHeaders = @{
        "Content-Type" = "application/json"
        "Accept"       = "application/json"
    }
    foreach ($k in $Headers.Keys) {
        $reqHeaders[$k] = $Headers[$k]
    }

    $statusCode = 0
    $responseBody = ""
    $parsedJson = $null

    try {
        $params = @{
            Uri         = $Uri
            Method      = $Method
            Headers     = $reqHeaders
            UseBasicParsing = $true
        }
        if ($Body) {
            $params["Body"] = $Body
        }

        $resp = Invoke-WebRequest @params
        $statusCode = [int]$resp.StatusCode
        $responseBody = $resp.Content
    }
    catch [System.Net.WebException] {
        $webEx = $_.Exception
        if ($webEx.Response) {
            $httpResp = [System.Net.HttpWebResponse]$webEx.Response
            $statusCode = [int]$httpResp.StatusCode
            $reader = New-Object System.IO.StreamReader($httpResp.GetResponseStream())
            $responseBody = $reader.ReadToEnd()
            $reader.Close()
        } else {
            $statusCode = 0
            $responseBody = $webEx.Message
        }
    }
    catch {
        $statusCode = 0
        $responseBody = $_.Exception.Message
    }

    if (-not $responseBody -or $responseBody.Trim() -eq "") {
        try {
            if ($Body) {
                $responseBody = & curl.exe -s -X $Method $Uri -H "Content-Type: application/json" -d $Body
            } else {
                $responseBody = & curl.exe -s -X $Method $Uri
            }
        } catch {}
    }

    if ($responseBody) {
        try {
            $parsedJson = $responseBody | ConvertFrom-Json
        } catch {
            $parsedJson = $null
        }
    }

    return @{
        StatusCode   = $statusCode
        RawContent   = $responseBody
        Json         = $parsedJson
    }
}

function Assert-Test {
    param(
        [string]$TestId,
        [string]$Suite,
        [string]$Description,
        [int[]]$ExpectedStatusCodes,
        [hashtable]$ApiResponse,
        [string]$ExpectedSubstr = ""
    )

    $status = $ApiResponse.StatusCode
    $raw = $ApiResponse.RawContent
    $json = $ApiResponse.Json

    $statusMatch = ($ExpectedStatusCodes -contains $status)
    $envelopeValid = $false
    $envelopeDetails = ""

    if ($json -ne $null) {
        if ($json.PSObject.Properties['success'] -ne $null -or $null -ne $json.success) {
            $envelopeValid = $true
            $envelopeDetails = "Envelope valid (success=$($json.success), message='$($json.message)')"
        } else {
            $envelopeDetails = "JSON returned without standard ApiResponse envelope"
        }
    } else {
        $envelopeDetails = "Non-JSON response returned"
    }

    $msgMatch = $true
    if ($ExpectedSubstr -ne "") {
        if (-not ($raw -like "*$ExpectedSubstr*")) {
            $msgMatch = $false
        }
    }

    $passed = $statusMatch -and $envelopeValid -and $msgMatch

    $resultObj = [PSCustomObject]@{
        TestId       = $TestId
        Suite        = $Suite
        Description  = $Description
        ExpectedCode = ($ExpectedStatusCodes -join " / ")
        ActualCode   = $status
        EnvelopeOk   = $envelopeValid
        Passed       = $passed
        Notes        = if ($passed) { "PASSED: Code $status matches expected" } else { "FAILED: Expected $($ExpectedStatusCodes -join '/') but received $status ($envelopeDetails)" }
        RawResponse  = if ($raw.Length -gt 250) { $raw.Substring(0, 250) + "..." } else { $raw }
    }

    $script:Results.Add($resultObj)

    $color = if ($passed) { "Green" } else { "Red" }
    $tag = if ($passed) { "[PASS]" } else { "[FAIL]" }
    Write-Host "$tag ${TestId}: $Description | Actual: $status | Expected: $($ExpectedStatusCodes -join '/') | Env: $envelopeValid" -ForegroundColor $color
}

# --- STEP 1: AUTHENTICATION SETUP ---
Write-Host "`n>>> [Step 1] Authenticating Test Actors..." -ForegroundColor Yellow

# Farmer Login
$farmerLoginBody = '{"email":"ramesh.farmer@agricycle.com","password":"Password@123"}'
$farmerAuth = Invoke-ApiRequest -Method "POST" -Uri "$BaseUrl/api/v1/auth/login" -Body $farmerLoginBody
$FarmerToken = if ($farmerAuth.Json -and $farmerAuth.Json.data) { $farmerAuth.Json.data.accessToken } else { $null }

# Buyer 1 (Livestock Owner)
$buyer1LoginBody = '{"email":"gopal.dairy@agricycle.com","password":"Password@123"}'
$buyer1Auth = Invoke-ApiRequest -Method "POST" -Uri "$BaseUrl/api/v1/auth/login" -Body $buyer1LoginBody
$Buyer1Token = if ($buyer1Auth.Json -and $buyer1Auth.Json.data) { $buyer1Auth.Json.data.accessToken } else { $null }

# Buyer 2 (Company / 3rd Party)
$buyer2LoginBody = '{"email":"procure@greenenergy.com","password":"Password@123"}'
$buyer2Auth = Invoke-ApiRequest -Method "POST" -Uri "$BaseUrl/api/v1/auth/login" -Body $buyer2LoginBody
$Buyer2Token = if ($buyer2Auth.Json -and $buyer2Auth.Json.data) { $buyer2Auth.Json.data.accessToken } else { $null }

# Super Admin
$adminLoginBody = '{"email":"admin@agricycle.com","password":"Admin@AgriCycle2026!"}'
$adminAuth = Invoke-ApiRequest -Method "POST" -Uri "$BaseUrl/api/v1/auth/login" -Body $adminLoginBody
$AdminToken = if ($adminAuth.Json -and $adminAuth.Json.data) { $adminAuth.Json.data.accessToken } else { $null }

Write-Host "Farmer Token:   $(if ($FarmerToken) { 'Acquired' } else { 'FAILED' })"
Write-Host "Buyer 1 Token:  $(if ($Buyer1Token) { 'Acquired' } else { 'FAILED' })"
Write-Host "Buyer 2 Token:  $(if ($Buyer2Token) { 'Acquired' } else { 'FAILED' })"
Write-Host "Admin Token:    $(if ($AdminToken) { 'Acquired' } else { 'FAILED' })"

# --- STEP 2: DISCOVER ACTIVE SEED DATA ---
Write-Host "`n>>> [Step 2] Discovering Active Seed IDs..." -ForegroundColor Yellow

$catResp = Invoke-ApiRequest -Method "GET" -Uri "$BaseUrl/api/v1/categories"
$ValidCategoryId = 1
if ($catResp.Json -and $catResp.Json.data -and $catResp.Json.data.Count -gt 0) {
    $ValidCategoryId = $catResp.Json.data[0].id
    Write-Host "Found Category ID: $ValidCategoryId ($($catResp.Json.data[0].name))"
}

$listingResp = Invoke-ApiRequest -Method "GET" -Uri "$BaseUrl/api/v1/listings/public?size=5"
$ValidListingId = 1
if ($listingResp.Json -and $listingResp.Json.data -and $listingResp.Json.data.content -and $listingResp.Json.data.content.Count -gt 0) {
    $ValidListingId = $listingResp.Json.data.content[0].id
    Write-Host "Found Valid Listing ID: $ValidListingId ($($listingResp.Json.data.content[0].title))"
}

# Farmer creates a clean listing for order state testing
$seedListingJson = @"
{
  "categoryId": $ValidCategoryId,
  "title": "QA Test Seed Lot Crop",
  "productMaterialName": "Seed Paddy Grain",
  "quantity": 500.0,
  "unit": "Tons",
  "pricePerUnit": 2200.0,
  "district": "Nalgonda",
  "state": "Telangana"
}
"@
$createSeedListing = Invoke-ApiRequest -Method "POST" -Uri "$BaseUrl/api/v1/listings" -Headers @{"Authorization"="Bearer $FarmerToken"} -Body $seedListingJson
$OrderTestListingId = if ($createSeedListing.Json -and $createSeedListing.Json.data) { $createSeedListing.Json.data.id } else { $ValidListingId }
Write-Host "Order Test Listing ID: $OrderTestListingId"

# Buyer 1 places a fresh order to create a known PENDING order
$seedOrderJson = @"
{
  "listingId": $OrderTestListingId,
  "quantity": 5.0,
  "deliveryAddress": "QA Test Warehouse, Hyderabad",
  "district": "Hyderabad",
  "state": "Telangana"
}
"@
$createSeedOrder = Invoke-ApiRequest -Method "POST" -Uri "$BaseUrl/api/v1/orders" -Headers @{"Authorization"="Bearer $Buyer1Token"} -Body $seedOrderJson
$PendingOrderId = if ($createSeedOrder.Json -and $createSeedOrder.Json.data) { $createSeedOrder.Json.data.id } else { 1 }
Write-Host "Created Fresh PENDING Order ID: $PendingOrderId"


# ==============================================================================
# SUITE 1: BOUNDARY TESTING - NEGATIVE & ZERO QUANTITIES / PRICES
# ==============================================================================
Write-Host "`n>>> [SUITE 1] Boundary Testing: Negative & Zero Quantities / Prices" -ForegroundColor Magenta

# 1.1 Listing with negative quantity
$b1 = @"
{
  "categoryId": $ValidCategoryId,
  "title": "Invalid Negative Qty Listing",
  "productMaterialName": "Rice Straw",
  "quantity": -25.0,
  "unit": "Tons",
  "pricePerUnit": 1500.0,
  "district": "Nalgonda",
  "state": "Telangana"
}
"@
$r = Invoke-ApiRequest -Method "POST" -Uri "$BaseUrl/api/v1/listings" -Headers @{"Authorization"="Bearer $FarmerToken"} -Body $b1
Assert-Test -TestId "TC-BND-01" -Suite "Boundary" -Description "Create listing with negative quantity (-25.0)" -ExpectedStatusCodes @(400) -ApiResponse $r

# 1.2 Listing with zero quantity
$b2 = @"
{
  "categoryId": $ValidCategoryId,
  "title": "Invalid Zero Qty Listing",
  "productMaterialName": "Rice Straw",
  "quantity": 0.0,
  "unit": "Tons",
  "pricePerUnit": 1500.0,
  "district": "Nalgonda",
  "state": "Telangana"
}
"@
$r = Invoke-ApiRequest -Method "POST" -Uri "$BaseUrl/api/v1/listings" -Headers @{"Authorization"="Bearer $FarmerToken"} -Body $b2
Assert-Test -TestId "TC-BND-02" -Suite "Boundary" -Description "Create listing with zero quantity (0.0)" -ExpectedStatusCodes @(400) -ApiResponse $r

# 1.3 Listing with negative price
$b3 = @"
{
  "categoryId": $ValidCategoryId,
  "title": "Invalid Negative Price Listing",
  "productMaterialName": "Rice Straw",
  "quantity": 10.0,
  "unit": "Tons",
  "pricePerUnit": -500.0,
  "district": "Nalgonda",
  "state": "Telangana"
}
"@
$r = Invoke-ApiRequest -Method "POST" -Uri "$BaseUrl/api/v1/listings" -Headers @{"Authorization"="Bearer $FarmerToken"} -Body $b3
Assert-Test -TestId "TC-BND-03" -Suite "Boundary" -Description "Create listing with negative pricePerUnit (-500.0)" -ExpectedStatusCodes @(400) -ApiResponse $r

# 1.4 Listing with zero price
$b4 = @"
{
  "categoryId": $ValidCategoryId,
  "title": "Invalid Zero Price Listing",
  "productMaterialName": "Rice Straw",
  "quantity": 10.0,
  "unit": "Tons",
  "pricePerUnit": 0.0,
  "district": "Nalgonda",
  "state": "Telangana"
}
"@
$r = Invoke-ApiRequest -Method "POST" -Uri "$BaseUrl/api/v1/listings" -Headers @{"Authorization"="Bearer $FarmerToken"} -Body $b4
Assert-Test -TestId "TC-BND-04" -Suite "Boundary" -Description "Create listing with zero pricePerUnit (0.0)" -ExpectedStatusCodes @(400) -ApiResponse $r

# 1.5 Order with negative quantity
$b5 = @"
{
  "listingId": $OrderTestListingId,
  "quantity": -5.0,
  "deliveryAddress": "Test Address",
  "district": "Nalgonda",
  "state": "Telangana"
}
"@
$r = Invoke-ApiRequest -Method "POST" -Uri "$BaseUrl/api/v1/orders" -Headers @{"Authorization"="Bearer $Buyer1Token"} -Body $b5
Assert-Test -TestId "TC-BND-05" -Suite "Boundary" -Description "Create order with negative quantity (-5.0)" -ExpectedStatusCodes @(400) -ApiResponse $r

# 1.6 Order with zero quantity
$b6 = @"
{
  "listingId": $OrderTestListingId,
  "quantity": 0.0,
  "deliveryAddress": "Test Address",
  "district": "Nalgonda",
  "state": "Telangana"
}
"@
$r = Invoke-ApiRequest -Method "POST" -Uri "$BaseUrl/api/v1/orders" -Headers @{"Authorization"="Bearer $Buyer1Token"} -Body $b6
Assert-Test -TestId "TC-BND-06" -Suite "Boundary" -Description "Create order with zero quantity (0.0)" -ExpectedStatusCodes @(400) -ApiResponse $r

# 1.7 Order with quantity exceeding listing available stock
$b7 = @"
{
  "listingId": $OrderTestListingId,
  "quantity": 99999999.0,
  "deliveryAddress": "Test Address",
  "district": "Nalgonda",
  "state": "Telangana"
}
"@
$r = Invoke-ApiRequest -Method "POST" -Uri "$BaseUrl/api/v1/orders" -Headers @{"Authorization"="Bearer $Buyer1Token"} -Body $b7
Assert-Test -TestId "TC-BND-07" -Suite "Boundary" -Description "Create order exceeding available stock (99999999.0)" -ExpectedStatusCodes @(400) -ApiResponse $r

# 1.8 Propose order negotiation with negative price
$b8 = @"
{
  "proposedPrice": -100.0,
  "proposedQuantity": 5.0,
  "notes": "Testing negative negotiation price"
}
"@
$r = Invoke-ApiRequest -Method "POST" -Uri "$BaseUrl/api/v1/orders/$PendingOrderId/negotiate" -Headers @{"Authorization"="Bearer $Buyer1Token"} -Body $b8
Assert-Test -TestId "TC-BND-08" -Suite "Boundary" -Description "Negotiate order with negative price (-100.0)" -ExpectedStatusCodes @(400) -ApiResponse $r


# ==============================================================================
# SUITE 2: NON-EXISTENT & INVALID IDENTIFIERS (404 VALIDATION)
# ==============================================================================
Write-Host "`n>>> [SUITE 2] Non-Existent & Invalid Identifiers" -ForegroundColor Magenta

# 2.1 Create listing with non-existent categoryId (99999)
$b21 = @"
{
  "categoryId": 99999,
  "title": "Invalid Category Listing",
  "productMaterialName": "Straw",
  "quantity": 10.0,
  "unit": "Tons",
  "pricePerUnit": 1500.0,
  "district": "Nalgonda",
  "state": "Telangana"
}
"@
$r = Invoke-ApiRequest -Method "POST" -Uri "$BaseUrl/api/v1/listings" -Headers @{"Authorization"="Bearer $FarmerToken"} -Body $b21
Assert-Test -TestId "TC-ID-01" -Suite "Invalid IDs" -Description "Create listing with non-existent categoryId (99999)" -ExpectedStatusCodes @(404) -ApiResponse $r

# 2.2 Get listing with non-existent listing ID (99999)
$r = Invoke-ApiRequest -Method "GET" -Uri "$BaseUrl/api/v1/listings/99999"
Assert-Test -TestId "TC-ID-02" -Suite "Invalid IDs" -Description "GET listing with non-existent ID (99999)" -ExpectedStatusCodes @(404) -ApiResponse $r

# 2.3 Get listing with non-existent Digital Lot ID
$r = Invoke-ApiRequest -Method "GET" -Uri "$BaseUrl/api/v1/listings/lot/AGC-FAKE-TG-2026-999999"
Assert-Test -TestId "TC-ID-03" -Suite "Invalid IDs" -Description "GET listing by non-existent Digital Lot ID" -ExpectedStatusCodes @(404) -ApiResponse $r

# 2.4 Create order for non-existent listing ID (99999)
$b24 = @"
{
  "listingId": 99999,
  "quantity": 5.0,
  "deliveryAddress": "Test Address",
  "district": "Nalgonda",
  "state": "Telangana"
}
"@
$r = Invoke-ApiRequest -Method "POST" -Uri "$BaseUrl/api/v1/orders" -Headers @{"Authorization"="Bearer $Buyer1Token"} -Body $b24
Assert-Test -TestId "TC-ID-04" -Suite "Invalid IDs" -Description "Create order for non-existent listing ID (99999)" -ExpectedStatusCodes @(404) -ApiResponse $r

# 2.5 Get order with non-existent order ID (99999)
$r = Invoke-ApiRequest -Method "GET" -Uri "$BaseUrl/api/v1/orders/99999" -Headers @{"Authorization"="Bearer $Buyer1Token"}
Assert-Test -TestId "TC-ID-05" -Suite "Invalid IDs" -Description "GET order with non-existent order ID (99999)" -ExpectedStatusCodes @(404) -ApiResponse $r

# 2.6 Update status for non-existent order ID (99999)
$b26 = '{"status":"CONFIRMED"}'
$r = Invoke-ApiRequest -Method "PATCH" -Uri "$BaseUrl/api/v1/orders/99999/status" -Headers @{"Authorization"="Bearer $FarmerToken"} -Body $b26
Assert-Test -TestId "TC-ID-06" -Suite "Invalid IDs" -Description "Update status on non-existent order ID (99999)" -ExpectedStatusCodes @(404) -ApiResponse $r


# ==============================================================================
# SUITE 3: ILLEGAL STATE TRANSITIONS & ACCESS CONTROL
# ==============================================================================
Write-Host "`n>>> [SUITE 3] Illegal Order State Transitions & RBAC" -ForegroundColor Magenta

# 3.1 Non-seller (buyer) attempting to ACCEPT a PENDING order
$b31 = '{"status":"ACCEPTED"}'
$r = Invoke-ApiRequest -Method "PATCH" -Uri "$BaseUrl/api/v1/orders/$PendingOrderId/status" -Headers @{"Authorization"="Bearer $Buyer1Token"} -Body $b31
Assert-Test -TestId "TC-STAT-01" -Suite "State Machine" -Description "Buyer attempting to ACCEPT a PENDING order (Seller only)" -ExpectedStatusCodes @(403) -ApiResponse $r

# 3.2 Unauthorized third-party attempting to view someone else's order
$r = Invoke-ApiRequest -Method "GET" -Uri "$BaseUrl/api/v1/orders/$PendingOrderId" -Headers @{"Authorization"="Bearer $Buyer2Token"}
Assert-Test -TestId "TC-STAT-02" -Suite "State Machine" -Description "Unauthorized 3rd party attempting to GET order" -ExpectedStatusCodes @(403) -ApiResponse $r

# 3.3 Unauthorized third-party attempting to update someone else's order
$b33 = '{"status":"ACCEPTED"}'
$r = Invoke-ApiRequest -Method "PATCH" -Uri "$BaseUrl/api/v1/orders/$PendingOrderId/status" -Headers @{"Authorization"="Bearer $Buyer2Token"} -Body $b33
Assert-Test -TestId "TC-STAT-03" -Suite "State Machine" -Description "Unauthorized 3rd party attempting to update order status" -ExpectedStatusCodes @(403) -ApiResponse $r

# 3.4 Attempting to directly complete an unconfirmed/PENDING order
$b34 = '{"status":"COMPLETED"}'
$r = Invoke-ApiRequest -Method "PATCH" -Uri "$BaseUrl/api/v1/orders/$PendingOrderId/status" -Headers @{"Authorization"="Bearer $Buyer1Token"} -Body $b34
Assert-Test -TestId "TC-STAT-04" -Suite "State Machine" -Description "Attempting to skip lifecycle directly to COMPLETED from PENDING" -ExpectedStatusCodes @(400) -ApiResponse $r

# 3.5 Buyer attempting to purchase their own listing
# Farmer tries to buy his own listing
$b35 = @"
{
  "listingId": $OrderTestListingId,
  "quantity": 1.0,
  "deliveryAddress": "Self Farm"
}
"@
$r = Invoke-ApiRequest -Method "POST" -Uri "$BaseUrl/api/v1/orders" -Headers @{"Authorization"="Bearer $FarmerToken"} -Body $b35
Assert-Test -TestId "TC-STAT-05" -Suite "State Machine" -Description "Farmer attempting to buy their own listing" -ExpectedStatusCodes @(400) -ApiResponse $r

# 3.6 Attempting to modify an order that is already COMPLETED (Order ID 1 from seed data is COMPLETED)
$b36 = '{"status":"CANCELLED"}'
$r = Invoke-ApiRequest -Method "PATCH" -Uri "$BaseUrl/api/v1/orders/1/status" -Headers @{"Authorization"="Bearer $FarmerToken"} -Body $b36
Assert-Test -TestId "TC-STAT-06" -Suite "State Machine" -Description "Attempting to cancel an already COMPLETED order" -ExpectedStatusCodes @(400) -ApiResponse $r


# ==============================================================================
# SUITE 4: MALFORMED PAYLOADS, MISSING FIELDS & ENUM VALIDATION
# ==============================================================================
Write-Host "`n>>> [SUITE 4] Malformed Payloads, Missing Fields & Input Validation" -ForegroundColor Magenta

# 4.1 Missing mandatory fields on Create Listing (missing title, categoryId, quantity, unit, pricePerUnit)
$b41 = '{"village":"Miryalaguda"}'
$r = Invoke-ApiRequest -Method "POST" -Uri "$BaseUrl/api/v1/listings" -Headers @{"Authorization"="Bearer $FarmerToken"} -Body $b41
Assert-Test -TestId "TC-PAY-01" -Suite "Payload Validation" -Description "Create listing with missing mandatory fields" -ExpectedStatusCodes @(400) -ApiResponse $r

# 4.2 Missing mandatory fields on Create Order (missing listingId and quantity)
$b42 = '{"deliveryAddress":"Hyderabad"}'
$r = Invoke-ApiRequest -Method "POST" -Uri "$BaseUrl/api/v1/orders" -Headers @{"Authorization"="Bearer $Buyer1Token"} -Body $b42
Assert-Test -TestId "TC-PAY-02" -Suite "Payload Validation" -Description "Create order with missing mandatory listingId & quantity" -ExpectedStatusCodes @(400) -ApiResponse $r

# 4.3 Missing mandatory status field on update order status
$b43 = '{"note":"No status provided"}'
$r = Invoke-ApiRequest -Method "PATCH" -Uri "$BaseUrl/api/v1/orders/$PendingOrderId/status" -Headers @{"Authorization"="Bearer $FarmerToken"} -Body $b43
Assert-Test -TestId "TC-PAY-03" -Suite "Payload Validation" -Description "Update order status with null status field" -ExpectedStatusCodes @(400) -ApiResponse $r

# 4.4 Malformed JSON syntax (syntax error: trailing comma / unclosed brace)
$b44 = '{ "listingId": 1, "quantity": 5.0, }'
$r = Invoke-ApiRequest -Method "POST" -Uri "$BaseUrl/api/v1/orders" -Headers @{"Authorization"="Bearer $Buyer1Token"} -Body $b44
Assert-Test -TestId "TC-PAY-04" -Suite "Payload Validation" -Description "Malformed JSON syntax (trailing comma)" -ExpectedStatusCodes @(400) -ApiResponse $r

# 4.5 Completely broken raw JSON (unbalanced bracket)
$b45 = '{"listingId": 1, "quantity": 5.0'
$r = Invoke-ApiRequest -Method "POST" -Uri "$BaseUrl/api/v1/orders" -Headers @{"Authorization"="Bearer $Buyer1Token"} -Body $b45
Assert-Test -TestId "TC-PAY-05" -Suite "Payload Validation" -Description "Malformed JSON syntax (unclosed curly bracket)" -ExpectedStatusCodes @(400) -ApiResponse $r

# 4.6 Invalid enum value (e.g. status: "SUPER_COMPLETED")
$b46 = '{"status":"SUPER_COMPLETED"}'
$r = Invoke-ApiRequest -Method "PATCH" -Uri "$BaseUrl/api/v1/orders/$PendingOrderId/status" -Headers @{"Authorization"="Bearer $FarmerToken"} -Body $b46
Assert-Test -TestId "TC-PAY-06" -Suite "Payload Validation" -Description "Invalid enum value for OrderStatus" -ExpectedStatusCodes @(400) -ApiResponse $r

# 4.7 SQL Injection payload in search / text field
$sqlParam = [System.Uri]::EscapeDataString("' OR '1'='1")
$r = Invoke-ApiRequest -Method "GET" -Uri "$BaseUrl/api/v1/listings/public?keyword=$sqlParam"
Assert-Test -TestId "TC-PAY-07" -Suite "Payload Validation" -Description "SQL Injection string in public listing keyword parameter" -ExpectedStatusCodes @(200) -ApiResponse $r

# 4.8 XSS script tag in listing description
$b48 = @"
{
  "categoryId": $ValidCategoryId,
  "title": "XSS Probe Listing <script>alert('xss')</script>",
  "productMaterialName": "Rice Straw",
  "quantity": 10.0,
  "unit": "Tons",
  "pricePerUnit": 1500.0,
  "district": "Nalgonda",
  "state": "Telangana",
  "description": "<script>alert('attack')</script>"
}
"@
$r = Invoke-ApiRequest -Method "POST" -Uri "$BaseUrl/api/v1/listings" -Headers @{"Authorization"="Bearer $FarmerToken"} -Body $b48
Assert-Test -TestId "TC-PAY-08" -Suite "Payload Validation" -Description "XSS probe in listing title/description (sanitization test)" -ExpectedStatusCodes @(200, 400) -ApiResponse $r

# 4.9 Unauthenticated request to protected endpoint
$b49 = '{"listingId": 1, "quantity": 1.0}'
$r = Invoke-ApiRequest -Method "POST" -Uri "$BaseUrl/api/v1/orders" -Body $b49
Assert-Test -TestId "TC-PAY-09" -Suite "Payload Validation" -Description "Unauthenticated POST /orders (missing JWT)" -ExpectedStatusCodes @(401) -ApiResponse $r


# ==============================================================================
# SUMMARY & METRICS
# ==============================================================================
$TotalCount = $Results.Count
$PassedCount = ($Results | Where-Object { $_.Passed -eq $true }).Count
$FailedCount = ($Results | Where-Object { $_.Passed -eq $false }).Count
$PassRate = [Math]::Round(($PassedCount / $TotalCount) * 100, 1)

Write-Host "`n================================================================" -ForegroundColor Cyan
Write-Host "                    TEST EXECUTION SUMMARY" -ForegroundColor Cyan
Write-Host "================================================================" -ForegroundColor Cyan
Write-Host "Total Tests Executed: $TotalCount"
Write-Host "Passed Tests:         $PassedCount" -ForegroundColor Green
Write-Host "Failed / Anomalies:   $FailedCount" -ForegroundColor Red
Write-Host "Pass Rate:            $PassRate %"
Write-Host "================================================================`n" -ForegroundColor Cyan

# Output table
$Results | Format-Table -Property TestId, Suite, ExpectedCode, ActualCode, EnvelopeOk, Passed, Notes -AutoSize

# Export results JSON
$ReportPath = "c:\Users\domma\OneDrive\Desktop\AgriCycle\qa_test_results.json"
$Results | ConvertTo-Json -Depth 4 | Out-File -FilePath $ReportPath -Encoding utf8
Write-Host "Detailed test output saved to: $ReportPath" -ForegroundColor Yellow

---
marp: true
theme: default
paginate: true
header: "AgriCycle – AI-Powered Harvest, Fodder & Agricultural Residue Marketplace"
footer: "© 2026 AgriCycle Platform | Java Full Stack + MySQL"
---

# 🌱 AgriCycle
### AI-Powered Harvest, Fodder & Agricultural Residue Marketplace

> **“One Harvest. Multiple Markets. Better Income. Less Waste.”**

**Technology Stack:** Java 25 LTS | Spring Boot 3.5.16 | MySQL 8.0 | Bootstrap 5.3  
**Architecture:** Layered REST API | Role-Based Access Control | Docker & Nginx  
**Live Platform:** `http://localhost:8080/`

---

## 🌾 Slide 2: The Agricultural Paradox

### The Challenge Today:
1. **Residue Burning & Severe Pollution**:
   - Over **92 Million Tons** of crop residue are burned annually in India alone, causing catastrophic winter smog and hazardous AQI levels.
2. **Untapped Farmer Income**:
   - Farmers traditionally sell only the primary harvested grain, treating straw, husk, and stalks as worthless waste.
3. **Severe Fodder Deficits for Livestock**:
   - Dairy and cattle owners face severe seasonal feed shortages and exorbitant middleman markups.
4. **Industrial Biomass Sourcing Inefficiencies**:
   - Green energy, paper, and biofuel companies struggle to source high-volume agricultural residue directly from farms.

---

## 💡 Slide 3: The AgriCycle Solution

### Central Concept: *ONE HARVEST $\rightarrow$ MULTIPLE MARKETS*

```
                         ┌──▶ Food / Grain Buyers (Paddy Rice)
                         │
     [🌾 One Harvest] ───┼──▶ Cattle & Dairy Owners (Rice Straw Bales - Fodder)
     (e.g., Rice Paddy)  │
                         ├──▶ Biomass / Power Plants (Rice Husk - Fuel)
                         │
                         └──▶ Compost & Packaging Manufacturers (Organic Residue)
```

- **Maximize Farmer Income**: Monopolize secondary and tertiary by-product monetization.
- **Eliminate Stubble Burning**: Turn field burning into high-value supply chains.
- **Direct Marketplace**: Connect farmers directly with livestock owners, companies, and transporters.

---

## 👥 Slide 4: Multi-Stakeholder Ecosystem (5 Roles)

| Role | Core Capabilities | Primary Value |
| :--- | :--- | :--- |
| **ROLE_FARMER** | Log harvests, auto-generate sellable outputs, publish listings, accept/negotiate orders | 25–40% incremental income per harvest |
| **ROLE_LIVESTOCK_OWNER** | Search fodder by animal type (Cow, Buffalo, Goat, Sheep), post emergency SOS requests | Direct farm-fresh fodder at fair prices |
| **ROLE_COMPANY** | Post bulk residue RFPs, request quotations, procure biomass & by-products | Verified industrial supply chain |
| **ROLE_TRANSPORTER** | Browse regional dispatch jobs, accept delivery trips, live status updates | Guaranteed freight earnings per ton |
| **ROLE_ADMIN** | Platform moderation, user KYC, dispute arbitration, security audit log review | 100% regulatory oversight & trust |

---

## 🛠️ Slide 5: Enterprise Technology Stack

### Strict Technical Adherence:
- **Backend**: **Java 25 LTS** + **Spring Boot 3.5.16**
- **Persistence**: **MySQL 8.0** + Spring Data JPA + Hibernate ORM (HikariCP Pool)
- **Security**: **Spring Security 6** + Stateless **JJWT** Bearer Tokens + BCrypt ($rounds = 10$)
- **Frontend**: **HTML5**, **CSS3**, **JavaScript (Fetch API)**, **Bootstrap 5.3**, **Leaflet Maps**
- **DevOps**: Multi-stage **Dockerfile**, **Docker Compose**, **Nginx 1.27**, **GitHub Actions CI/CD**
- **Compliance**: **0%** Node.js / Express, **0%** MongoDB / Firebase, **0%** PHP. Pure Java Full Stack!

---

## 🏛️ Slide 6: Layered Enterprise Architecture

```
┌────────────────────────────────────────────────────────┐
│  Responsive Web Frontend (HTML5, Bootstrap 5, Leaflet) │
└───────────────────────────┬────────────────────────────┘
                            │ REST / JSON via Fetch API
┌───────────────────────────▼────────────────────────────┐
│      Nginx Edge Gateway & Rate Limiting (Port 80)       │
└───────────────────────────┬────────────────────────────┘
                            │ Upstream Reverse Proxy
┌───────────────────────────▼────────────────────────────┐
│        Spring Boot Controller Layer (@RestController)  │
│         - AuthenticationFilter, RBAC & Bean Validation │
├────────────────────────────────────────────────────────┤
│           Service Layer (Transactional Business Logic) │
│         - OrderService, ListingService, AiService      │
├────────────────────────────────────────────────────────┤
│          Repository Layer (Spring Data JPA / Hibernate)│
│         - Pessimistic Row Locks & Parameterized Queries│
├────────────────────────────────────────────────────────┤
│     MySQL 8.0 Relational Database (agricycle_db)       │
│         - 21 Normalized Entities, FK Constraints, UTF8 │
└────────────────────────────────────────────────────────┘
```

---

## 🤖 Slide 7: AI Core Capabilities

1. **Multi-Market Yield & Recovery Estimator**:
   - Calculates exact by-product output ratios based on crop type (e.g., 100 Tons Paddy $\rightarrow$ 68T Rice + 80T Straw + 22T Husk).
2. **Dynamic Fair Price Bands**:
   - Analyzes real-time regional supply/demand to suggest optimal pricing for farmers and buyers.
3. **Supply-Demand Matchmaking**:
   - Automatically connects industrial demand requirements with nearby farmer listings.
4. **Real-Time Carbon Footprint Mitigation Engine**:
   - Translates tonnage of repurposed residue into avoided $\text{CO}_2$ emissions ($1\text{ Ton Straw} \approx 1.46\text{ Tons }\text{CO}_2$).

---

## 🏷️ Slide 8: Digital Lot ID & Provenance Matrix

Every marketplace output is stamped with an immutable **Digital Lot ID**:

$$\text{Lot ID Format: } \mathbf{AGC\text{-}[CROP]\text{-}[STATE]\text{-}[YEAR]\text{-}[ID\_PADDED]}$$

*Example:* `AGC-BASM-TG-2026-000033`

- **Farm-to-Gate Traceability**: Links back to parent harvest record, soil type, and farmer identity.
- **Client-Side QR Canvas Matrix**: Instant scan code rendering for transporters and buyers at weighbridges.
- **Trust Badges**: Displays farmer verification level, farm size, and community review ratings.

---

## 🔄 Slide 9: 11-Step Verified Trade Lifecycle

```mermaid
flowchart LR
    A["1. Harvest Log"] --> B["2. Output Gen"]
    B --> C["3. Published"]
    C --> D["4. Order Placed"]
    D --> E["5. Confirmed"]
    E --> F["6. Escrow Lock"]
    E --> G["7. Freight Job"]
    G --> H["8. Dispatched"]
    H --> I["9. In Transit"]
    I --> J["10. Delivered"]
    J --> K["11. Escrow Release"]
```

- **Zero-Loss Guarantee**: Escrow payment locks buyer funds before dispatch.
- **Logistics Integration**: Transport job auto-created upon order confirmation.
- **Buyer Protection**: Funds released to seller and transporter only after buyer sign-off.

---

## 🧪 Slide 10: Team B Quality & Security Benchmarks

### 100% Pass Rate Across Autonomous Squad Audits:

| Audit Domain | Tests Run | Result | Key Protections Enforced |
| :--- | :---: | :---: | :--- |
| **QA Edge-Case Testing** | 29 | **100% PASS** | `@Positive` bean validation, strict sequential state machine, malformed payload handling |
| **Security Penetration Audit** | 13 | **100% PASS** | Zero privilege escalation (`ROLE_ADMIN` blocked), IDOR protection, zero stack traces |
| **Performance & Load Stress** | 150+ | **10.5ms Avg** | `@Lock(PESSIMISTIC_WRITE)` prevents overselling; 20 concurrent requests $\rightarrow$ 0 errors |

---

## 🚢 Slide 11: Production DevOps & Deployment

- **Turn-Key Startup**: One command brings up the full production stack:
  ```bash
  docker compose up -d --build
  ```
- **Lightweight JRE Image**: Multi-stage Docker build producing a secure, non-root Alpine container (`agricycle:agricycle`).
- **Nginx Edge Layer**: Rate limiting (`30 req/s`), Gzip level 6 compression, security headers (HSTS, CSP, nosniff, SAMEORIGIN).
- **Automated CI/CD**: GitHub Actions pipeline compiles on Java 25, runs JUnit tests against a live MySQL container, and validates Docker packaging.

---

## 🌍 Slide 12: Environmental Impact & Next Horizons

### Verified Platform Impact (Seeded Demonstration):
- **Residue Reused**: **890.0 Metric Tons**
- **$\text{CO}_2$ Mitigated**: **1,299.4 Metric Tons**
- **Farmer Incremental Earnings**: **₹17,45,000+**

### Future Horizons:
- **IoT Smart Weighbridge Integration**: Automated gross/tare weight logging via Bluetooth/RFID.
- **Verified Carbon Credit Certificates**: Tokenized carbon offset credits issued to participating farmers.
- **Multilingual Voice Commerce**: Regional voice search for rural farmers in Telugu, Hindi, and Tamil.

---

# Thank You!
### 🌱 AgriCycle Marketplace
*“One Harvest. Multiple Markets. Better Income. Less Waste.”*

- **Web Application**: `http://localhost:8080/`
- **Swagger Documentation**: `http://localhost:8080/swagger-ui/index.html`
- **GitHub Repository**: Complete Java Full Stack + MySQL Source

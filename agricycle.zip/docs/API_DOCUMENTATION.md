# AgriCycle – REST API Documentation

Base URL: `/api/v1`

---

## 1. Authentication (`/api/v1/auth`)
| Method | Endpoint | Description | Access |
|---|---|---|---|
| `POST` | `/api/v1/auth/register` | Register new user (Farmer, Livestock, Company, Transporter) | Public |
| `POST` | `/api/v1/auth/login` | Authenticate with email/password, returns JWT token | Public |
| `POST` | `/api/v1/auth/refresh` | Exchange valid refresh token for a new access token | Public |
| `GET`  | `/api/v1/auth/me` | Fetch current logged-in user profile | Authenticated |

---

## 2. Harvests (`/api/v1/harvests`)
| Method | Endpoint | Description | Access |
|---|---|---|---|
| `POST` | `/api/v1/harvests` | Record a new primary crop harvest | `ROLE_FARMER` |
| `GET`  | `/api/v1/harvests/my` | Get current farmer's recorded harvests | `ROLE_FARMER` |
| `GET`  | `/api/v1/harvests/{id}` | Get harvest details and provenance by ID | Authenticated |
| `GET`  | `/api/v1/harvests/recommended-outputs` | Get recommended sellable outputs for a crop | Public |
| `DELETE`| `/api/v1/harvests/{id}` | Delete a harvest record (Owner only) | `ROLE_FARMER` |

---

## 3. Marketplace & Listings (`/api/v1/listings`)
| Method | Endpoint | Description | Access |
|---|---|---|---|
| `GET`  | `/api/v1/listings/public` | Search listings with filters (keyword, category, price, district) | Public |
| `GET`  | `/api/v1/listings/{id}` | Get product details by listing ID | Public |
| `GET`  | `/api/v1/listings/lot/{lotId}` | Lookup listing by Digital Lot ID (e.g. `AGC-RICE-TG-2026-000145`) | Public |
| `GET`  | `/api/v1/listings/fodder` | Search specialized livestock fodder supplies | Public |
| `GET`  | `/api/v1/listings/residue` | Search industrial residue & biomass | Public |
| `POST` | `/api/v1/listings` | Create listing branched from a harvest | `ROLE_FARMER` |
| `GET`  | `/api/v1/listings/my` | Get current seller's active listings | Authenticated |
| `DELETE`| `/api/v1/listings/{id}` | Delete a listing (Owner only) | Authenticated |

---

## 4. Requirements & Demands (`/api/v1/requirements`)
| Method | Endpoint | Description | Access |
|---|---|---|---|
| `GET`  | `/api/v1/requirements/public` | Browse open industrial and fodder demands | Public |
| `POST` | `/api/v1/requirements` | Post industrial RFQ or emergency fodder alert | Authenticated |
| `GET`  | `/api/v1/requirements/my` | Get user's posted requirements | Authenticated |
| `POST` | `/api/v1/requirements/{id}/offers` | Submit supply offer to fulfill requirement | `ROLE_FARMER` |
| `GET`  | `/api/v1/requirements/{id}/offers` | View received offers for a requirement | Authenticated (Buyer) |

---

## 5. Orders & Lifecycle (`/api/v1/orders`)
| Method | Endpoint | Description | Access |
|---|---|---|---|
| `POST` | `/api/v1/orders` | Place an order for a marketplace listing | Authenticated |
| `GET`  | `/api/v1/orders/buyer` | Get current user's purchased orders | Authenticated |
| `GET`  | `/api/v1/orders/seller` | Get current farmer's received orders | `ROLE_FARMER` |
| `PUT`  | `/api/v1/orders/{id}/status` | Update order lifecycle status (`CONFIRMED`, `READY_FOR_PICKUP`) | Authenticated |
| `POST` | `/api/v1/orders/{id}/negotiate`| Submit price/quantity counter-offer | Authenticated |

---

## 6. Transport & Logistics (`/api/v1/transport`)
| Method | Endpoint | Description | Access |
|---|---|---|---|
| `GET`  | `/api/v1/transport/available-jobs` | Find unassigned delivery jobs in region | `ROLE_TRANSPORTER` |
| `POST` | `/api/v1/transport/jobs/{id}/accept`| Accept an available delivery job | `ROLE_TRANSPORTER` |
| `PATCH`| `/api/v1/transport/jobs/{id}/status`| Update delivery status (`DISPATCHED`, `IN_TRANSIT`, `DELIVERED`)| `ROLE_TRANSPORTER` |
| `GET`  | `/api/v1/transport/my-jobs` | Get assigned and completed trips | `ROLE_TRANSPORTER` |
| `GET`  | `/api/v1/transport/vehicles`| Get registered fleet vehicles | `ROLE_TRANSPORTER` |
| `POST` | `/api/v1/transport/vehicles`| Register a new vehicle | `ROLE_TRANSPORTER` |

---

## 7. AI & Predictive Engines (`/api/v1/ai`)
| Method | Endpoint | Description | Access |
|---|---|---|---|
| `POST` | `/api/v1/ai/harvest-calculator` | Calculate multi-market recovery income boost | Public |
| `GET`  | `/api/v1/ai/environmental-impact` | Live carbon mitigation and stubble prevention stats | Public |
| `GET`  | `/api/v1/ai/market-demand-trends`| Market demand trends and fair price bands | Public |
| `GET`  | `/api/v1/ai/match` | Multi-factor compatibility matching score | Public |
| `GET`  | `/api/v1/ai/best-use/{materialName}`| Downstream application recommendations | Public |
| `GET`  | `/api/v1/ai/suggested-price` | AI suggested price range per unit | Public |

---

## 8. Super Admin Governance (`/api/v1/admin`)
| Method | Endpoint | Description | Access |
|---|---|---|---|
| `GET`  | `/api/v1/admin/stats` | Platform-wide KPIs (Users, Volume, CO2 saved) | `ROLE_ADMIN` |
| `GET`  | `/api/v1/admin/users` | Search, filter, and inspect registered users | `ROLE_ADMIN` |
| `PATCH`| `/api/v1/admin/users/{id}/status` | Suspend or reactivate user account | `ROLE_ADMIN` |
| `PATCH`| `/api/v1/admin/listings/{id}/status`| Approve, reject, or suspend listing | `ROLE_ADMIN` |
| `GET`  | `/api/v1/admin/audit-logs` | Immutable security and operational audit trail | `ROLE_ADMIN` |
| `GET`  | `/api/v1/admin/categories` | Manage taxonomy categories | `ROLE_ADMIN` |
| `POST` | `/api/v1/admin/categories` | Create new category | `ROLE_ADMIN` |

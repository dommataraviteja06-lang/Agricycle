# 🚢 AgriCycle – Enterprise Production Deployment & DevOps Guide

This guide outlines the production deployment architectures, container orchestration, environment configurations, and maintenance routines for **AgriCycle – AI-Powered Harvest, Fodder & Agricultural Residue Marketplace**.

---

## 🏛️ Production Container Architecture

```mermaid
flowchart TD
    Client["Clients & Mobile Browsers<br/>(Internet)"]
    
    subgraph Host["Production Host / Cloud VM (Docker Engine)"]
        subgraph Edge["Reverse Proxy Gateway"]
            Nginx["Nginx 1.27 Proxy<br/>Ports 80 / 443<br/>• Rate Limiting (30 req/s)<br/>• Gzip & Cache Control<br/>• SSL Termination"]
        end
        
        subgraph AppTier["Application Container"]
            SpringBoot["AgriCycle Spring Boot 3.5.16<br/>Port 8080 (Internal)<br/>• Non-Root User ('agricycle')<br/>• Java 25 JRE Container-Aware<br/>• HikariCP High-Throughput Pool"]
        end
        
        subgraph DataTier["Data Persistence"]
            MySQL["MySQL 8.0 Enterprise<br/>Port 3306 (Internal)<br/>• UTF8MB4 Character Set<br/>• InnoDB Engine<br/>• Persistent Volume"]
        end
        
        Nginx -->|Proxy Pass /api & /| SpringBoot
        SpringBoot -->|HikariCP JDBC Connection| MySQL
    end
    
    Client --> Nginx
```

---

## ⚡ Option 1: Turn-Key Docker Compose Deployment (Recommended)

### 1. Prerequisites
- Docker Engine $\ge 24.0$
- Docker Compose $\ge 2.20$
- Minimum 2 CPU cores, 4 GB RAM, 20 GB SSD storage.

### 2. Configuration Setup
Create and review `.env` in the project root:
```bash
cp .env.example .env
```

Ensure sensitive variables are set:
```ini
MYSQL_ROOT_PASSWORD=YourStrongRootPassword2026!
MYSQL_DATABASE=agricycle_db
MYSQL_USER=agricycle_user
MYSQL_PASSWORD=YourStrongUserPassword2026!

# Generate with: openssl rand -hex 32
JWT_SECRET=8f7e6d5c4b3a20198f7e6d5c4b3a20198f7e6d5c4b3a20198f7e6d5c4b3a2019

ADMIN_EMAIL=admin@agricycle.com
ADMIN_PASSWORD=YourSecureSuperAdminPassword!
HTTP_PORT=80
```

### 3. Launch Platform
```bash
# Build images and start all services in detached mode
docker compose up -d --build
```

### 4. Verify Service Health
```bash
# Inspect running containers
docker compose ps

# Check application boot logs
docker compose logs -f app

# Verify Nginx proxy logs
docker compose logs -f nginx
```

### 5. Access the Platform
- **Marketplace Web Portal**: `http://<your-server-ip>/`
- **Swagger API Docs**: `http://<your-server-ip>/swagger-ui/index.html`
- **Health Check Endpoint**: `http://<your-server-ip>/healthz` (returns `healthy`)

---

## 🖥️ Option 2: Standalone Linux VM / Bare Metal Deployment

### 1. Install Java 25 & MySQL 8
```bash
sudo apt update && sudo apt install -y openjdk-25-jre-headless mysql-server nginx
```

### 2. Initialize MySQL Database
```bash
sudo mysql -e "CREATE DATABASE agricycle_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
sudo mysql -e "CREATE USER 'agricycle_user'@'localhost' IDENTIFIED BY 'AgriCycle@Prod2026!';"
sudo mysql -e "GRANT ALL PRIVILEGES ON agricycle_db.* TO 'agricycle_user'@'localhost';"
sudo mysql -e "FLUSH PRIVILEGES;"

# Seed initial tables and catalog
mysql -u agricycle_user -p agricycle_db < database/schema.sql
mysql -u agricycle_user -p agricycle_db < database/data.sql
```

### 3. Setup Systemd Service
Create `/etc/systemd/system/agricycle.service`:
```ini
[Unit]
Description=AgriCycle Spring Boot Application
After=syslog.target network.target mysql.service

[Service]
User=www-data
Group=www-data
WorkingDirectory=/opt/agricycle
ExecStart=/usr/bin/java -XX:+UseG1GC -XX:MaxRAMPercentage=75.0 -jar /opt/agricycle/agricycle-marketplace-1.0.0.jar --spring.profiles.active=prod
SuccessExitStatus=143
Restart=always
RestartSec=10
Environment="DB_URL=jdbc:mysql://localhost:3306/agricycle_db?useSSL=false&serverTimezone=UTC"
Environment="DB_USERNAME=agricycle_user"
Environment="DB_PASSWORD=AgriCycle@Prod2026!"
Environment="JWT_SECRET=8f7e6d5c4b3a20198f7e6d5c4b3a20198f7e6d5c4b3a20198f7e6d5c4b3a2019"

[Install]
WantedBy=multi-user.target
```

Enable and start the service:
```bash
sudo systemctl daemon-reload
sudo systemctl enable --now agricycle.service
```

---

## 🔒 SSL / HTTPS Setup with Let's Encrypt

To secure domain traffic with valid TLS certificates:

```bash
# Install Certbot
sudo apt install -y certbot python3-certbot-nginx

# Obtain SSL Certificate
sudo certbot --nginx -d agricycle.yourdomain.com
```

---

## 💾 Database Backup & Disaster Recovery

### Automated Backup Script (`backup.sh`):
```bash
#!/bin/bash
BACKUP_DIR="/var/backups/agricycle"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
mkdir -p "$BACKUP_DIR"

docker exec agricycle_mysql mysqldump -u root -p"$MYSQL_ROOT_PASSWORD" agricycle_db | gzip > "$BACKUP_DIR/agricycle_$TIMESTAMP.sql.gz"

# Keep last 14 days of backups
find "$BACKUP_DIR" -type f -name "*.sql.gz" -mtime +14 -delete
```

### Restore from Backup:
```bash
gunzip < /var/backups/agricycle/agricycle_YYYYMMDD_HHMMSS.sql.gz | docker exec -i agricycle_mysql mysql -u root -p"$MYSQL_ROOT_PASSWORD" agricycle_db
```

---

## 📊 Monitoring & Telemetry Endpoints

| Endpoint | Access Level | Description |
| :--- | :--- | :--- |
| `GET /healthz` | Public (Nginx Edge) | Instant 200 OK edge health verification |
| `GET /api/v1/categories` | Public (REST) | Database connection & JPA connectivity check |
| `GET /actuator/health` | Authenticated | Spring Boot Actuator deep subsystem health |
| `GET /actuator/metrics` | Admin Only | JVM memory, GC pauses, HikariCP pool utilization |
| `GET /api/v1/admin/audit-logs` | Admin Only | Real-time immutable platform security audit feed |

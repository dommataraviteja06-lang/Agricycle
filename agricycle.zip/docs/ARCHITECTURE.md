# AgriCycle – Architecture & System Design Documentation

## 1. Executive Overview & Problem Statement
AgriCycle solves two interconnected agricultural and environmental problems in India:
1. **Unmonetized Agricultural Residue & Open Stubble Burning**: Over 500 million tons of crop residue are generated each year. Due to high clearing labor costs and lack of immediate market connectivity, farmers frequently burn rice straw and stubble, emitting hazardous air pollutants (PM2.5, carbon monoxide).
2. **Livestock Fodder & Industrial Feedstock Inefficiencies**: Dairy and livestock farmers regularly face acute feed shortages, while green manufacturing industries (biofuel pellets, biochar, eco-packaging, organic compost) struggle with reliable, traceable agricultural biomass supply chains.

AgriCycle addresses this through the paradigm:
```
           ┌──────────────────────┐
           │  ONE HARVEST RECORD  │
           │  (e.g., Rice Paddy)  │
           └──────────┬───────────┘
                      │
     ┌────────────────┼────────────────┐
     ▼                ▼                ▼
┌──────────────┐ ┌──────────────┐ ┌──────────────┐
│  Food Grain  │ │ Fodder Straw │ │  Rice Husk   │
│   (Milling)  │ │   (Livestock)│ │ (Bio-Energy) │
└──────────────┘ └──────────────┘ └──────────────┘
```

---

## 2. Technical Stack & Architectural Layers
The project adheres to a strict layered design:

```
+-----------------------------------------------------------+
|              Bootstrap 5 / HTML5 / JS (Fetch)             |
|              Interactive Leaflet OpenStreetMap            |
+-----------------------------------------------------------+
                             | (REST JSON via HTTP/HTTPS)
+-----------------------------------------------------------+
|      Spring Security 6.x + JWT Authentication Filter      |
|               Role-Based Access Control (RBAC)            |
+-----------------------------------------------------------+
                             |
+-----------------------------------------------------------+
|             REST Controllers (API Contracts & DTOs)       |
+-----------------------------------------------------------+
                             |
+-----------------------------------------------------------+
|             Service Layer (Transactions & Business Logic) |
+-----------------------------------------------------------+
                             |
+-----------------------------------------------------------+
|             Spring Data JPA Repositories (Hibernate)      |
+-----------------------------------------------------------+
                             |
+-----------------------------------------------------------+
|             Relational Database: MySQL 8.x                |
+-----------------------------------------------------------+
```

---

## 3. Core Database Entities & Relationships
1. **User & Profiles**:
   - `User`: Central authentication record storing email, BCrypt-hashed password, status (`ACTIVE`, `SUSPENDED`, `PENDING_VERIFICATION`), and `Role` (`ROLE_FARMER`, `ROLE_LIVESTOCK_OWNER`, `ROLE_COMPANY`, `ROLE_TRANSPORTER`, `ROLE_ADMIN`).
   - Profile Entities: One-to-one mapped `FarmerProfile`, `LivestockProfile`, `CompanyProfile`, `TransportProfile`.
2. **Harvest & Multi-Market Listings**:
   - `Harvest`: Primary agricultural production record created by the farmer (crop, variety, harvest date, total yield, location).
   - `Listing`: Generated commercial lot referenced back to parent `Harvest` (`harvest_id` foreign key). Contains unique Digital Lot ID (`lot_id`), available quantity, price, unit, and verification status.
3. **Demand & Reverse Marketplace**:
   - `Requirement`: Posted by industrial companies or livestock owners with required quantity, max budget, urgency, and destination.
   - `RequirementOffer`: Proposed by farmers to fulfill buyer requirements with agreed price and quantity.
4. **Orders, Negotiations & Logistics**:
   - `Order`: Contract of sale tracking buyer, seller, total price, and lifecycle status (`PENDING`, `CONFIRMED`, `READY_FOR_PICKUP`, `IN_TRANSIT`, `DELIVERED`, `COMPLETED`, `CANCELLED`).
   - `OrderNegotiation`: Counter-offer history between buyer and seller.
   - `TransportJob`: Matched delivery trip tracking assigned vehicle, transporter, pickup, and destination.
   - `Payment`: Mock escrow record holding funds until successful delivery confirmation.
5. **Transparency & Trust**:
   - `Review`: Bi-directional rating and feedback.
   - `Dispute`: Customer complaint and mediation tickets.
   - `AuditLog`: Immutable audit trail recording actor ID, action, entity, timestamp, and IP address.

---

## 4. Digital Lot ID & Provenance Matrix
Every approved listing is assigned a deterministic digital lot code:
```
AGC - [CROP] - [STATE] - [YEAR] - [UNIQUE SEQUENCE]
Example: AGC-RICE-TG-2026-000145
```
- A client-side visual QR canvas renders a 21x21 data matrix based on this code.
- Buyers, transporters, and agricultural inspectors scan the lot code to verify harvest provenance, variety, and harvest date without exposing private personal phone numbers or bank credentials publicly.

---

## 5. Security & Defense-in-Depth
- **Stateless JWT**: Access tokens signed using HMAC-SHA256 with short expiry and refresh token rotation.
- **RBAC**: Enforced at the controller method level (`@PreAuthorize("hasAuthority('ROLE_FARMER')")`).
- **Admin Isolation**: Regular registration explicitly forbids `ROLE_ADMIN`. Super Admin is only bootstrapped securely via environment variables or initial database seeds.
- **Ownership Validation**: Farmers and buyers can only update or cancel orders belonging to their own user IDs.
- **Audit Logging**: Any user suspension, listing rejection, dispute resolution, or administrative change is permanently recorded in `audit_logs`.

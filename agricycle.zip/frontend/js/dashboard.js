/**
 * AgriCycle – Master Multi-Role Dashboard Controller
 * Powering Farmer, Livestock Owner, Company, Transporter, and Super Admin Panels.
 */

// Global Role Route Protection Guard
function requireRole(expectedRole) {
  if (!Auth.isLoggedIn()) {
    showToast("Please log in to access your dashboard.", "warning");
    setTimeout(() => { window.location.href = '/login.html'; }, 500);
    return false;
  }
  const user = Auth.getUser();
  if (expectedRole && user.role !== expectedRole) {
    showToast(`Access restricted: Requires ${expectedRole.replace('ROLE_', '')} role.`, "danger");
    setTimeout(() => { window.location.href = Auth.getDashboardUrl(); }, 1000);
    return false;
  }
  return true;
}

// Populate user identity widget
function initDashboardHeader() {
  const user = Auth.getUser();
  if (!user) return;
  const nameEl = document.getElementById('dashUserName');
  const roleEl = document.getElementById('dashUserRole');
  const locEl = document.getElementById('dashUserLoc');

  if (nameEl) nameEl.textContent = user.fullName;
  if (roleEl) roleEl.textContent = user.role.replace('ROLE_', '').replace('_', ' ');
  if (locEl && user.profile) {
    locEl.textContent = `${user.profile.district || 'Telangana'}, ${user.profile.state || 'India'}`;
  }
}

/* =========================================================================
   1. FARMER DASHBOARD CONTROLLER
   ========================================================================= */
const FarmerDashboard = {
  async init() {
    if (!requireRole('ROLE_FARMER')) return;
    initDashboardHeader();
    await this.loadStats();
    await this.loadHarvests();
    await this.loadListings();
    await this.loadOrders();
    await this.loadAiRecommendations();
  },

  async loadStats() {
    const harvestsRes = await api('/harvests/my');
    const listingsRes = await api('/listings/my');
    const ordersRes = await api('/orders/seller');

    const totalHarvests = harvestsRes.success && harvestsRes.data ? harvestsRes.data.length : 0;
    const activeListings = listingsRes.success && listingsRes.data ? listingsRes.data.filter(l => l.status === 'APPROVED' || l.status === 'PENDING_APPROVAL').length : 0;
    const orders = ordersRes.success && ordersRes.data ? ordersRes.data : [];
    const totalOrders = orders.length;

    let earnings = 0;
    orders.forEach(o => {
      if (o.status === 'COMPLETED' || o.status === 'DELIVERED') {
        earnings += (o.finalPrice || o.totalPrice || 0);
      }
    });

    if (document.getElementById('statTotalHarvests')) document.getElementById('statTotalHarvests').textContent = totalHarvests;
    if (document.getElementById('statActiveListings')) document.getElementById('statActiveListings').textContent = activeListings;
    if (document.getElementById('statTotalOrders')) document.getElementById('statTotalOrders').textContent = totalOrders;
    if (document.getElementById('statTotalEarnings')) document.getElementById('statTotalEarnings').textContent = formatCurrency(earnings);
  },

  async loadHarvests() {
    const listEl = document.getElementById('farmerHarvestsList');
    if (!listEl) return;
    const res = await api('/harvests/my');
    if (!res.success || !res.data || res.data.length === 0) {
      listEl.innerHTML = `
        <div class="text-center py-5">
          <i class="bi bi-tree text-muted fs-1"></i>
          <h6 class="mt-2 text-dark">No harvests recorded yet</h6>
          <p class="text-muted small">Record your harvested crop to generate multiple sellable products (grain, straw, husk).</p>
          <button class="btn btn-success btn-sm" onclick="FarmerDashboard.openAddHarvestModal()">Add Your First Harvest</button>
        </div>
      `;
      return;
    }

    let html = '';
    res.data.forEach(h => {
      html += `
        <div class="card border-0 shadow-sm mb-3">
          <div class="card-body p-3">
            <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-2">
              <div>
                <div class="d-flex align-items-center gap-2 mb-1">
                  <span class="badge bg-success-subtle text-success fw-bold px-2 py-1">Harvest #${h.id}</span>
                  <span class="text-muted small"><i class="bi bi-calendar3 me-1"></i>${formatDate(h.harvestDate)}</span>
                </div>
                <h5 class="fw-bold mb-1 text-dark">${h.cropName} <span class="text-muted fs-6">(${h.cropVariety || 'Standard'})</span></h5>
                <div class="small text-muted">
                  <span>Harvest Volume: <strong>${h.totalQuantity} ${h.unit}</strong></span> • 
                  <span>Location: <strong>${h.village ? h.village + ', ' : ''}${h.district}</strong></span>
                </div>
              </div>
              <div class="d-flex gap-2">
                <button class="btn btn-outline-primary btn-sm fw-semibold" onclick="FarmerDashboard.openCreateOutputModal(${h.id}, '${h.cropName.replace(/'/g, "\\'")}', ${h.totalQuantity}, '${h.unit}', '${(h.district || 'Nalgonda').replace(/'/g, "\\'")}', '${(h.state || 'Telangana').replace(/'/g, "\\'")}')">
                  <i class="bi bi-plus-circle me-1"></i> Create Sellable Outputs
                </button>
              </div>
            </div>
          </div>
        </div>
      `;
    });
    listEl.innerHTML = html;
  },

  async loadListings() {
    const listEl = document.getElementById('farmerListingsList');
    if (!listEl) return;
    const res = await api('/listings/my');
    if (!res.success || !res.data || res.data.length === 0) {
      listEl.innerHTML = `<div class="text-center py-4 text-muted">No active listings created yet. Click "Create Sellable Outputs" on any harvest.</div>`;
      return;
    }

    let html = '';
    res.data.forEach(l => {
      const statusBadge = l.status === 'APPROVED' ? 'bg-success' :
                          l.status === 'PENDING_APPROVAL' ? 'bg-warning text-dark' :
                          l.status === 'SOLD' ? 'bg-secondary' : 'bg-danger';

      html += `
        <div class="card border-0 shadow-sm mb-3">
          <div class="card-body p-3">
            <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-2">
              <div>
                <div class="d-flex align-items-center gap-2 mb-1">
                  <span class="badge-lot">${l.lotId}</span>
                  <span class="badge ${statusBadge}">${l.status}</span>
                  <span class="badge bg-info text-white">${l.categoryName || 'Material'}</span>
                </div>
                <h5 class="fw-bold mb-1">${l.title}</h5>
                <div class="small text-muted">
                  <span>Available: <strong>${l.availableQuantity} ${l.unit}</strong></span> • 
                  <span>Price: <strong class="text-success">${formatCurrency(l.pricePerUnit)} / ${l.unit}</strong></span>
                </div>
              </div>
              <div class="d-flex align-items-center gap-2">
                <button class="btn btn-outline-secondary btn-sm" onclick="FarmerDashboard.showQrLotModal('${l.lotId}', '${l.title}')">
                  <i class="bi bi-qr-code me-1"></i> View QR
                </button>
                <a href="/product-detail.html?id=${l.id}" class="btn btn-outline-success btn-sm">
                  <i class="bi bi-box-arrow-up-right me-1"></i> Public View
                </a>
              </div>
            </div>
          </div>
        </div>
      `;
    });
    listEl.innerHTML = html;
  },

  async loadOrders() {
    const listEl = document.getElementById('farmerOrdersList');
    if (!listEl) return;
    const res = await api('/orders/seller');
    if (!res.success || !res.data || res.data.length === 0) {
      listEl.innerHTML = `<div class="text-center py-4 text-muted">No orders received yet.</div>`;
      return;
    }

    let html = '';
    res.data.forEach(o => {
      const statusBadge = o.status === 'COMPLETED' || o.status === 'DELIVERED' ? 'bg-success' :
                          o.status === 'CONFIRMED' || o.status === 'IN_TRANSIT' ? 'bg-primary' :
                          o.status === 'PENDING' ? 'bg-warning text-dark' : 'bg-secondary';

      html += `
        <div class="card border-0 shadow-sm mb-3">
          <div class="card-body p-3">
            <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-2">
              <div>
                <div class="d-flex align-items-center gap-2 mb-1">
                  <span class="fw-bold text-dark">Order #${o.orderNumber}</span>
                  <span class="badge ${statusBadge}">${o.status}</span>
                  <small class="text-muted">${formatDate(o.createdAt)}</small>
                </div>
                <h6 class="fw-bold mb-1">${o.listingTitle}</h6>
                <div class="small text-muted">
                  <span>Buyer: <strong>${o.buyerName}</strong></span> • 
                  <span>Quantity: <strong>${o.quantity} ${o.unit}</strong></span> • 
                  <span>Total: <strong class="text-success">${formatCurrency(o.totalPrice)}</strong></span>
                </div>
                <div class="small text-muted mt-1"><i class="bi bi-geo-alt me-1"></i>Delivery: ${o.deliveryAddress}</div>
              </div>
              <div class="d-flex gap-2">
                ${o.status === 'PENDING' ? `
                  <button class="btn btn-success btn-sm" onclick="FarmerDashboard.updateOrderStatus(${o.id}, 'CONFIRMED')">
                    <i class="bi bi-check-lg me-1"></i> Accept
                  </button>
                  <button class="btn btn-outline-danger btn-sm" onclick="FarmerDashboard.updateOrderStatus(${o.id}, 'CANCELLED')">
                    Reject
                  </button>
                ` : ''}
                ${o.status === 'CONFIRMED' ? `
                  <button class="btn btn-primary btn-sm" onclick="FarmerDashboard.updateOrderStatus(${o.id}, 'READY_FOR_PICKUP')">
                    <i class="bi bi-box-seam me-1"></i> Ready for Pickup
                  </button>
                ` : ''}
              </div>
            </div>
          </div>
        </div>
      `;
    });
    listEl.innerHTML = html;
  },

  async loadAiRecommendations() {
    const container = document.getElementById('farmerAiRecs');
    if (!container) return;
    const res = await api('/ai/market-demand-trends');
    if (!res.success || !res.data) return;

    let html = '';
    res.data.forEach(rec => {
      html += `
        <div class="col-md-4 mb-3">
          <div class="card border-0 shadow-sm h-100 p-3">
            <div class="d-flex justify-content-between align-items-center mb-2">
              <span class="badge bg-warning text-dark"><i class="bi bi-stars me-1"></i>${rec.crop}</span>
              <span class="badge bg-success-subtle text-success">${rec.demand} DEMAND</span>
            </div>
            <h6 class="fw-bold mb-1">${rec.bestUse}</h6>
            <p class="small text-muted mb-2">${rec.marketNotes}</p>
            <div class="small text-success fw-bold">Fair Band: ${rec.suggestedPriceBand}</div>
          </div>
        </div>
      `;
    });
    container.innerHTML = html;
  },

  openAddHarvestModal() {
    new bootstrap.Modal(document.getElementById('addHarvestModal')).show();
  },

  async submitAddHarvest() {
    const cropName = document.getElementById('harvestCropName').value.trim();
    const cropVariety = document.getElementById('harvestVariety').value.trim();
    const qty = parseFloat(document.getElementById('harvestQty').value);
    const unit = document.getElementById('harvestUnit').value;
    const harvestDate = document.getElementById('harvestDate').value || new Date().toISOString().split('T')[0];
    const village = document.getElementById('harvestVillage').value.trim();
    const district = document.getElementById('harvestDistrict').value;
    const state = document.getElementById('harvestState').value;
    const desc = document.getElementById('harvestDesc').value.trim();

    if (!cropName || !qty) {
      showToast("Please enter crop name and harvested quantity.", "danger");
      return;
    }

    const res = await api('/harvests', {
      method: 'POST',
      body: JSON.stringify({
        cropName, cropVariety, totalQuantity: qty, unit, harvestDate, village, district, state, description: desc
      })
    });

    if (res.success) {
      bootstrap.Modal.getInstance(document.getElementById('addHarvestModal')).hide();
      showToast("Harvest logged successfully! Now create sellable outputs.", "success");
      this.loadHarvests();
      this.loadStats();
    } else {
      showToast(res.message || "Failed to add harvest.", "danger");
    }
  },

  openCreateOutputModal(harvestId, cropName, totalQty, unit, district = 'Nalgonda', state = 'Telangana') {
    document.getElementById('outputHarvestId').value = harvestId;
    document.getElementById('outputModalCropName').textContent = cropName;
    document.getElementById('outputTitle').value = `${cropName} Straw / Residue`;
    document.getElementById('outputQty').value = Math.round(totalQty * 0.8);
    document.getElementById('outputUnit').value = unit;
    const distEl = document.getElementById('outputDistrict');
    if (distEl) distEl.value = district || 'Nalgonda';
    const stateEl = document.getElementById('outputState');
    if (stateEl) stateEl.value = state || 'Telangana';
    new bootstrap.Modal(document.getElementById('createOutputModal')).show();
  },

  async submitCreateOutput() {
    const harvestId = document.getElementById('outputHarvestId').value;
    const title = document.getElementById('outputTitle').value.trim();
    const categoryId = document.getElementById('outputCategorySelect').value;
    const qty = parseFloat(document.getElementById('outputQty').value);
    const unit = document.getElementById('outputUnit').value;
    const price = parseFloat(document.getElementById('outputPrice').value);
    const desc = document.getElementById('outputDesc').value.trim();
    const district = document.getElementById('outputDistrict')?.value || 'Nalgonda';
    const state = document.getElementById('outputState')?.value || 'Telangana';

    if (!title || !qty || !price) {
      showToast("Please complete required output fields.", "danger");
      return;
    }

    const res = await api('/listings', {
      method: 'POST',
      body: JSON.stringify({
        harvestId: parseInt(harvestId),
        categoryId: parseInt(categoryId),
        title,
        productMaterialName: title,
        quantity: qty,
        unit,
        pricePerUnit: price,
        district,
        state,
        description: desc
      })
    });

    if (res.success) {
      bootstrap.Modal.getInstance(document.getElementById('createOutputModal')).hide();
      showToast("Sellable listing created with unique Lot ID!", "success");
      this.loadListings();
      this.loadStats();
    } else {
      showToast(res.message || "Failed to create listing.", "danger");
    }
  },

  async updateOrderStatus(orderId, newStatus) {
    const res = await api(`/orders/${orderId}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status: newStatus })
    });
    if (res.success) {
      showToast(`Order status updated to ${newStatus}`, "success");
      this.loadOrders();
      this.loadStats();
    } else {
      showToast(res.message || "Failed to update order status.", "danger");
    }
  },

  showQrLotModal(lotId, title) {
    document.getElementById('qrModalLotId').textContent = lotId;
    document.getElementById('qrModalTitle').textContent = title;
    renderQrCode('modalQrCanvas', lotId);
    new bootstrap.Modal(document.getElementById('qrLotModal')).show();
  }
};

/* =========================================================================
   2. LIVESTOCK OWNER DASHBOARD CONTROLLER
   ========================================================================= */
const LivestockDashboard = {
  async init() {
    if (!requireRole('ROLE_LIVESTOCK_OWNER')) return;
    initDashboardHeader();
    await this.loadStats();
    await this.loadFodderOrders();
    await this.loadUrgentRequirements();
  },

  async loadStats() {
    const ordersRes = await api('/orders/buyer');
    const reqsRes = await api('/requirements/my');

    const orders = ordersRes.success && ordersRes.data ? ordersRes.data : [];
    const reqs = reqsRes.success && reqsRes.data ? reqsRes.data : [];

    if (document.getElementById('statLivestockOrders')) document.getElementById('statLivestockOrders').textContent = orders.length;
    if (document.getElementById('statActiveDeliveries')) {
      const active = orders.filter(o => o.status === 'IN_TRANSIT' || o.status === 'CONFIRMED' || o.status === 'READY_FOR_PICKUP').length;
      document.getElementById('statActiveDeliveries').textContent = active;
    }
    if (document.getElementById('statUrgentReqs')) document.getElementById('statUrgentReqs').textContent = reqs.length;
  },

  async loadFodderOrders() {
    const listEl = document.getElementById('livestockOrdersList');
    if (!listEl) return;
    const res = await api('/orders/buyer');
    if (!res.success || !res.data || res.data.length === 0) {
      listEl.innerHTML = `
        <div class="text-center py-5">
          <i class="bi bi-cart-x text-muted fs-1"></i>
          <h6 class="mt-2">No fodder orders placed yet</h6>
          <p class="text-muted small">Explore nearby livestock fodder supplies or post an emergency feed requirement.</p>
          <a href="/find-fodder.html" class="btn btn-warning btn-sm fw-bold">Browse Fodder Supplies</a>
        </div>
      `;
      return;
    }

    let html = '';
    res.data.forEach(o => {
      html += `
        <div class="card border-0 shadow-sm mb-3">
          <div class="card-body p-3">
            <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-2">
              <div>
                <div class="d-flex align-items-center gap-2 mb-1">
                  <span class="fw-bold">Order #${o.orderNumber}</span>
                  <span class="badge bg-success-subtle text-success">${o.status}</span>
                  <small class="text-muted">${formatDate(o.createdAt)}</small>
                </div>
                <h6 class="fw-bold mb-1">${o.listingTitle}</h6>
                <div class="small text-muted">
                  <span>Seller: <strong>${o.sellerName}</strong></span> • 
                  <span>Quantity: <strong>${o.quantity} ${o.unit}</strong></span> • 
                  <span>Total: <strong class="text-success">${formatCurrency(o.totalPrice)}</strong></span>
                </div>
              </div>
              <div class="d-flex gap-2">
                ${o.status === 'DELIVERED' || o.status === 'IN_TRANSIT' ? `
                  <button class="btn btn-outline-success btn-sm" onclick="LivestockDashboard.openRateModal(${o.id}, '${o.sellerName}')">
                    <i class="bi bi-star-fill text-warning me-1"></i> Rate Seller
                  </button>
                ` : ''}
              </div>
            </div>
          </div>
        </div>
      `;
    });
    listEl.innerHTML = html;
  },

  async loadUrgentRequirements() {
    const listEl = document.getElementById('livestockReqsList');
    if (!listEl) return;
    const res = await api('/requirements/my');
    if (!res.success || !res.data || res.data.length === 0) {
      listEl.innerHTML = `<div class="text-center py-4 text-muted">No urgent requests posted.</div>`;
      return;
    }

    let html = '';
    res.data.forEach(r => {
      html += `
        <div class="card border-0 shadow-sm mb-3">
          <div class="card-body p-3">
            <div class="d-flex justify-content-between align-items-center">
              <div>
                <span class="badge bg-danger mb-1">${r.urgency}</span>
                <h6 class="fw-bold mb-1">${r.title}</h6>
                <div class="small text-muted">
                  Needed: <strong>${r.requiredQuantity} ${r.unit}</strong> • Target: <strong>${formatCurrency(r.maxPricePerUnit)} / ${r.unit}</strong>
                </div>
              </div>
              <span class="badge bg-secondary">${r.status}</span>
            </div>
          </div>
        </div>
      `;
    });
    listEl.innerHTML = html;
  },

  openRateModal(orderId, sellerName) {
    document.getElementById('rateOrderId').value = orderId;
    document.getElementById('rateSellerName').textContent = sellerName;
    new bootstrap.Modal(document.getElementById('rateSellerModal')).show();
  },

  async submitRating() {
    const orderId = document.getElementById('rateOrderId').value;
    const stars = parseInt(document.getElementById('rateStars').value) || 5;
    const comments = document.getElementById('rateComments').value.trim();

    const res = await api('/reviews', {
      method: 'POST',
      body: JSON.stringify({
        orderId: parseInt(orderId),
        rating: stars,
        comment: comments,
        reviewType: 'SELLER_REVIEW'
      })
    });

    if (res.success) {
      bootstrap.Modal.getInstance(document.getElementById('rateSellerModal')).hide();
      showToast("Thank you for submitting your seller rating!", "success");
    } else {
      showToast(res.message || "Failed to submit review.", "danger");
    }
  }
};

/* =========================================================================
   3. COMPANY DASHBOARD CONTROLLER
   ========================================================================= */
const CompanyDashboard = {
  async init() {
    if (!requireRole('ROLE_COMPANY')) return;
    initDashboardHeader();
    await this.loadStats();
    await this.loadRequirements();
    await this.loadOrders();
  },

  async loadStats() {
    const reqsRes = await api('/requirements/my');
    const ordersRes = await api('/orders/buyer');

    const reqs = reqsRes.success && reqsRes.data ? reqsRes.data : [];
    const orders = ordersRes.success && ordersRes.data ? ordersRes.data : [];

    if (document.getElementById('statCompanyReqs')) document.getElementById('statCompanyReqs').textContent = reqs.length;
    if (document.getElementById('statCompanyOrders')) document.getElementById('statCompanyOrders').textContent = orders.length;
    
    let tonsProcured = 0;
    orders.forEach(o => {
      if (o.status === 'DELIVERED' || o.status === 'COMPLETED') {
        tonsProcured += (o.quantity || 0);
      }
    });
    if (document.getElementById('statTonsProcured')) document.getElementById('statTonsProcured').textContent = `${tonsProcured} T`;
  },

  async loadRequirements() {
    const listEl = document.getElementById('companyReqsList');
    if (!listEl) return;
    const res = await api('/requirements/my');
    if (!res.success || !res.data || res.data.length === 0) {
      listEl.innerHTML = `<div class="text-center py-4 text-muted">No industrial requirements posted yet. Click "Post New Requirement" above.</div>`;
      return;
    }

    let html = '';
    res.data.forEach(r => {
      html += `
        <div class="card border-0 shadow-sm mb-3">
          <div class="card-body p-3">
            <div class="d-flex justify-content-between align-items-center">
              <div>
                <span class="badge bg-primary mb-1">${r.materialType}</span>
                <h6 class="fw-bold mb-1">${r.title}</h6>
                <div class="small text-muted">
                  Required: <strong>${r.requiredQuantity} ${r.unit}</strong> • Max Budget: <strong>${formatCurrency(r.maxPricePerUnit)} / ${r.unit}</strong> • Location: <strong>${r.deliveryLocation}</strong>
                </div>
              </div>
              <div class="d-flex align-items-center gap-2">
                <span class="badge bg-secondary">${r.status}</span>
                <button class="btn btn-outline-primary btn-sm" onclick="CompanyDashboard.viewOffers(${r.id})">
                  <i class="bi bi-inbox me-1"></i> View Supplier Offers
                </button>
              </div>
            </div>
          </div>
        </div>
      `;
    });
    listEl.innerHTML = html;
  },

  async loadOrders() {
    const listEl = document.getElementById('companyOrdersList');
    if (!listEl) return;
    const res = await api('/orders/buyer');
    if (!res.success || !res.data || res.data.length === 0) {
      listEl.innerHTML = `<div class="text-center py-4 text-muted">No active procurement orders.</div>`;
      return;
    }

    let html = '';
    res.data.forEach(o => {
      html += `
        <div class="card border-0 shadow-sm mb-3">
          <div class="card-body p-3">
            <div class="d-flex justify-content-between align-items-center">
              <div>
                <div class="d-flex align-items-center gap-2 mb-1">
                  <span class="fw-bold">PO #${o.orderNumber}</span>
                  <span class="badge bg-primary">${o.status}</span>
                </div>
                <h6 class="fw-bold mb-1">${o.listingTitle}</h6>
                <div class="small text-muted">
                  Volume: <strong>${o.quantity} ${o.unit}</strong> • Value: <strong class="text-success">${formatCurrency(o.totalPrice)}</strong> • Supplier: <strong>${o.sellerName}</strong>
                </div>
              </div>
              <div>
                <span class="badge bg-light text-dark border"><i class="bi bi-truck me-1"></i>Track Shipment</span>
              </div>
            </div>
          </div>
        </div>
      `;
    });
    listEl.innerHTML = html;
  },

  async viewOffers(requirementId) {
    const res = await api(`/requirements/${requirementId}/offers`);
    const container = document.getElementById('offersListContent');
    if (!container) return;

    if (!res.success || !res.data || res.data.length === 0) {
      container.innerHTML = `<div class="text-center py-4 text-muted">No offers received from farmers yet for this requirement.</div>`;
    } else {
      let html = '';
      res.data.forEach(off => {
        html += `
          <div class="card border-0 shadow-sm mb-2 p-3">
            <div class="d-flex justify-content-between align-items-center">
              <div>
                <h6 class="fw-bold mb-1">${off.farmerName}</h6>
                <div class="small text-muted">Offered: <strong>${off.offeredQuantity} Tons</strong> at <strong class="text-success">${formatCurrency(off.offeredPricePerUnit)} / Ton</strong></div>
                <div class="small text-muted fst-italic">"${off.notes || 'Ready for supply'}"</div>
              </div>
              <div>
                <span class="badge bg-secondary">${off.status}</span>
              </div>
            </div>
          </div>
        `;
      });
      container.innerHTML = html;
    }
    new bootstrap.Modal(document.getElementById('viewOffersModal')).show();
  }
};

/* =========================================================================
   4. TRANSPORTER DASHBOARD CONTROLLER
   ========================================================================= */
const TransporterDashboard = {
  async init() {
    if (!requireRole('ROLE_TRANSPORTER')) return;
    initDashboardHeader();
    await this.loadStats();
    await this.loadAvailableJobs();
    await this.loadMyTrips();
    await this.loadVehicles();
  },

  async loadStats() {
    const jobsRes = await api('/transport/available-jobs');
    const myTripsRes = await api('/transport/my-jobs');

    const available = jobsRes.success && jobsRes.data && jobsRes.data.content ? jobsRes.data.content.length : 0;
    const myTrips = myTripsRes.success && myTripsRes.data ? myTripsRes.data : [];
    const active = myTrips.filter(t => t.status === 'ASSIGNED' || t.status === 'DISPATCHED' || t.status === 'IN_TRANSIT').length;
    const completed = myTrips.filter(t => t.status === 'DELIVERED').length;

    let earnings = 0;
    myTrips.forEach(t => {
      if (t.status === 'DELIVERED') earnings += (t.agreedFare || t.transportFee || 1500);
    });

    if (document.getElementById('statAvailableJobs')) document.getElementById('statAvailableJobs').textContent = available;
    if (document.getElementById('statActiveTrips')) document.getElementById('statActiveTrips').textContent = active;
    if (document.getElementById('statCompletedTrips')) document.getElementById('statCompletedTrips').textContent = completed;
    if (document.getElementById('statTransportEarnings')) document.getElementById('statTransportEarnings').textContent = formatCurrency(earnings);
  },

  async loadAvailableJobs() {
    const listEl = document.getElementById('transporterAvailableJobs');
    if (!listEl) return;
    const res = await api('/transport/available-jobs');
    const jobs = res.success && res.data && res.data.content ? res.data.content : [];
    if (jobs.length === 0) {
      listEl.innerHTML = `<div class="text-center py-4 text-muted">No unassigned delivery jobs currently available in your region.</div>`;
      return;
    }

    let html = '';
    jobs.forEach(j => {
      const jobId = j.id || j.jobId;
      const fare = j.agreedFare || j.transportFee || 2000;
      html += `
        <div class="card border-0 shadow-sm mb-3">
          <div class="card-body p-3">
            <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-2">
              <div>
                <span class="badge bg-warning text-dark mb-1">Job #${jobId} (Order #${j.orderNumber || ''})</span>
                <h6 class="fw-bold mb-1">${j.pickupDistrict || 'District'} Delivery (${j.weightTons || 5} Tons)</h6>
                <div class="small text-muted">
                  <span>Pickup: <strong>${j.pickupLocation}</strong></span> → 
                  <span>Drop: <strong>${j.deliveryLocation}</strong></span>
                </div>
                <div class="small text-success fw-bold mt-1">Guaranteed Trip Fare: ${formatCurrency(fare)}</div>
              </div>
              <div>
                <button class="btn btn-success btn-sm fw-bold px-3" onclick="TransporterDashboard.acceptJob(${jobId})">
                  <i class="bi bi-check2-circle me-1"></i> Accept Job
                </button>
              </div>
            </div>
          </div>
        </div>
      `;
    });
    listEl.innerHTML = html;
  },

  async loadMyTrips() {
    const listEl = document.getElementById('transporterMyTrips');
    if (!listEl) return;
    const res = await api('/transport/my-jobs');
    if (!res.success || !res.data || res.data.length === 0) {
      listEl.innerHTML = `<div class="text-center py-4 text-muted">No assigned trips. Accept an available job above.</div>`;
      return;
    }

    let html = '';
    res.data.forEach(t => {
      const tripId = t.id || t.jobId;
      html += `
        <div class="card border-0 shadow-sm mb-3">
          <div class="card-body p-3">
            <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-2">
              <div>
                <div class="d-flex align-items-center gap-2 mb-1">
                  <span class="fw-bold">Trip #${tripId}</span>
                  <span class="badge bg-primary">${t.status}</span>
                </div>
                <h6 class="fw-bold mb-1">Order #${t.orderNumber || tripId} (${t.weightTons || 5} Tons)</h6>
                <div class="small text-muted">
                  From: <strong>${t.pickupLocation}</strong> → To: <strong>${t.deliveryLocation}</strong>
                </div>
                <div class="small text-success fw-bold">Fare: ${formatCurrency(t.agreedFare || 1500)}</div>
              </div>
              <div class="d-flex gap-2">
                ${t.status === 'ASSIGNED' ? `
                  <button class="btn btn-outline-primary btn-sm" onclick="TransporterDashboard.updateTripStatus(${tripId}, 'DISPATCHED')">Mark Dispatched</button>
                ` : ''}
                ${t.status === 'DISPATCHED' ? `
                  <button class="btn btn-primary btn-sm" onclick="TransporterDashboard.updateTripStatus(${tripId}, 'IN_TRANSIT')">Start In-Transit</button>
                ` : ''}
                ${t.status === 'IN_TRANSIT' ? `
                  <button class="btn btn-success btn-sm fw-bold" onclick="TransporterDashboard.updateTripStatus(${tripId}, 'DELIVERED')">Confirm Delivery</button>
                ` : ''}
              </div>
            </div>
          </div>
        </div>
      `;
    });
    listEl.innerHTML = html;
  },

  async loadVehicles() {
    const listEl = document.getElementById('transporterVehiclesList');
    if (!listEl) return;
    const res = await api('/transport/vehicles');
    if (!res.success || !res.data || res.data.length === 0) {
      listEl.innerHTML = `<div class="text-center py-4 text-muted">No vehicles registered in fleet.</div>`;
      return;
    }

    let html = '';
    res.data.forEach(v => {
      html += `
        <div class="card border-0 shadow-sm mb-2 p-3">
          <div class="d-flex justify-content-between align-items-center">
            <div>
              <h6 class="fw-bold mb-0">${v.vehicleType}</h6>
              <small class="text-muted">Reg: <strong>${v.registrationNumber}</strong> • Capacity: <strong>${v.capacityTons} Tons</strong></small>
            </div>
            <span class="badge bg-success-subtle text-success">Active Fleet</span>
          </div>
        </div>
      `;
    });
    listEl.innerHTML = html;
  },

  async acceptJob(jobId) {
    const res = await api(`/transport/jobs/${jobId}/accept`, { method: 'POST' });
    if (res.success) {
      showToast("Job accepted successfully! Drive safely.", "success");
      this.loadAvailableJobs();
      this.loadMyTrips();
      this.loadStats();
    } else {
      showToast(res.message || "Failed to accept job.", "danger");
    }
  },

  async updateTripStatus(jobId, status) {
    const res = await api(`/transport/jobs/${jobId}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status })
    });
    if (res.success) {
      showToast(`Trip status updated to ${status}`, "success");
      this.loadMyTrips();
      this.loadStats();
    } else {
      showToast(res.message || "Failed to update trip status.", "danger");
    }
  }
};

/* =========================================================================
   5. SUPER ADMIN DASHBOARD CONTROLLER
   ========================================================================= */
const AdminDashboard = {
  async init() {
    if (!requireRole('ROLE_ADMIN')) return;
    initDashboardHeader();
    await this.loadStats();
    await this.loadUsers();
    await this.loadListings();
    await this.loadAuditLogs();
    await this.loadCategories();
  },

  async loadStats() {
    const res = await api('/admin/stats');
    if (res.success && res.data) {
      const d = res.data;
      if (document.getElementById('admTotalUsers')) document.getElementById('admTotalUsers').textContent = d.totalUsers || 25;
      if (document.getElementById('admTotalListings')) document.getElementById('admTotalListings').textContent = d.totalListings || 30;
      if (document.getElementById('admTotalOrders')) document.getElementById('admTotalOrders').textContent = d.totalOrders || 20;
      if (document.getElementById('admTotalRevenue')) document.getElementById('admTotalRevenue').textContent = formatCurrency(d.totalTradingVolume || 485000);
      if (document.getElementById('admCo2Saved')) document.getElementById('admCo2Saved').textContent = `${d.co2SavedTons || 120} T`;
    }
  },

  async loadUsers() {
    const listEl = document.getElementById('admUsersTableBody');
    if (!listEl) return;
    const res = await api('/admin/users');
    const users = res.success && res.data && res.data.content ? res.data.content : [];

    let html = '';
    users.forEach(u => {
      const statusBadge = u.status === 'ACTIVE' ? 'bg-success' :
                          u.status === 'SUSPENDED' ? 'bg-danger' : 'bg-warning text-dark';

      html += `
        <tr>
          <td><span class="badge bg-light text-dark border">#${u.id}</span></td>
          <td class="fw-bold">${u.fullName}</td>
          <td class="small text-muted">${u.email}</td>
          <td><span class="badge bg-secondary">${u.role.replace('ROLE_', '')}</span></td>
          <td><span class="badge ${statusBadge}">${u.status}</span></td>
          <td class="text-end">
            ${u.status === 'ACTIVE' ? `
              <button class="btn btn-outline-danger btn-sm py-0" onclick="AdminDashboard.setUserStatus(${u.id}, 'SUSPENDED')">Suspend</button>
            ` : `
              <button class="btn btn-outline-success btn-sm py-0" onclick="AdminDashboard.setUserStatus(${u.id}, 'ACTIVE')">Reactivate</button>
            `}
          </td>
        </tr>
      `;
    });
    listEl.innerHTML = html;
  },

  async loadListings() {
    const listEl = document.getElementById('admListingsTableBody');
    if (!listEl) return;
    const res = await api('/listings/public?size=30');
    const listings = res.success && res.data && res.data.content ? res.data.content : [];

    let html = '';
    listings.forEach(l => {
      const statusBadge = l.status === 'APPROVED' ? 'bg-success' :
                          l.status === 'PENDING_APPROVAL' ? 'bg-warning text-dark' : 'bg-danger';

      html += `
        <tr>
          <td><span class="badge-lot">${l.lotId}</span></td>
          <td class="fw-bold">${l.title}</td>
          <td>${l.availableQuantity} ${l.unit}</td>
          <td class="text-success fw-bold">${formatCurrency(l.pricePerUnit)}</td>
          <td><span class="badge ${statusBadge}">${l.status}</span></td>
          <td class="text-end">
            ${l.status === 'PENDING_APPROVAL' ? `
              <button class="btn btn-success btn-sm py-0" onclick="AdminDashboard.setListingStatus(${l.id}, 'APPROVED')">Approve</button>
              <button class="btn btn-outline-danger btn-sm py-0" onclick="AdminDashboard.setListingStatus(${l.id}, 'REJECTED')">Reject</button>
            ` : `
              <span class="small text-muted">Audited</span>
            `}
          </td>
        </tr>
      `;
    });
    listEl.innerHTML = html;
  },

  async loadAuditLogs() {
    const listEl = document.getElementById('admAuditTableBody');
    if (!listEl) return;
    const res = await api('/admin/audit-logs');
    if (!res.success || !res.data) return;

    let html = '';
    res.data.slice(0, 15).forEach(a => {
      html += `
        <tr>
          <td class="small text-muted">${formatDate(a.timestamp)}</td>
          <td class="fw-bold">${a.action}</td>
          <td><span class="badge bg-secondary">${a.entityName} #${a.entityId}</span></td>
          <td class="small text-muted">${a.details || '-'}</td>
          <td class="small text-dark">${a.actorEmail || 'System'}</td>
        </tr>
      `;
    });
    listEl.innerHTML = html;
  },

  async loadCategories() {
    const listEl = document.getElementById('admCategoriesTableBody');
    if (!listEl) return;
    const res = await api('/admin/categories');
    const categories = res.success && res.data ? res.data : [];

    let html = '';
    categories.forEach(c => {
      html += `
        <tr>
          <td><span class="badge bg-light text-dark">#${c.id}</span></td>
          <td class="fw-bold">${c.name}</td>
          <td><span class="badge bg-info text-white">${c.type}</span></td>
          <td><span class="badge bg-success">${c.active ? 'Active' : 'Inactive'}</span></td>
        </tr>
      `;
    });
    listEl.innerHTML = html;
  },

  async setUserStatus(userId, status) {
    const res = await api(`/admin/users/${userId}/status?status=${status}`, {
      method: 'PATCH'
    });
    if (res.success) {
      showToast(`User status updated to ${status}`, "success");
      this.loadUsers();
    } else {
      showToast(res.message || "Failed to update user.", "danger");
    }
  },

  async setListingStatus(listingId, status) {
    const res = await api(`/admin/listings/${listingId}/status?status=${status}`, {
      method: 'PATCH'
    });
    if (res.success) {
      showToast(`Listing status updated to ${status}`, "success");
      this.loadListings();
    } else {
      showToast(res.message || "Failed to update listing.", "danger");
    }
  }
};

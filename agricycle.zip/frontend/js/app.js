﻿/**
 * AgriCycle â€“ Core Client-Side Application Library
 * Centralizes authentication, API communication, notifications, i18n, and UI utilities.
 */

const API_BASE = '/api/v1';

// Authentication & Token Management
const Auth = {
  getToken() {
    return localStorage.getItem('agricycle_token');
  },
  getRefreshToken() {
    return localStorage.getItem('agricycle_refresh_token');
  },
  getUser() {
    const raw = localStorage.getItem('agricycle_user');
    return raw ? JSON.parse(raw) : null;
  },
  setSession(authResponse) {
    if (authResponse.accessToken) {
      localStorage.setItem('agricycle_token', authResponse.accessToken);
    }
    if (authResponse.refreshToken) {
      localStorage.setItem('agricycle_refresh_token', authResponse.refreshToken);
    }
    const user = {
      id: authResponse.userId,
      email: authResponse.email,
      fullName: authResponse.fullName,
      role: authResponse.role,
      status: authResponse.status,
      profile: authResponse.profile
    };
    localStorage.setItem('agricycle_user', JSON.stringify(user));
  },
  logout() {
    localStorage.removeItem('agricycle_token');
    localStorage.removeItem('agricycle_refresh_token');
    localStorage.removeItem('agricycle_user');
    window.location.href = '/login.html';
  },
  isLoggedIn() {
    return !!this.getToken();
  },
  hasRole(role) {
    const u = this.getUser();
    return u && u.role === role;
  },
  getDashboardUrl() {
    const u = this.getUser();
    if (!u) return '/login.html';
    switch (u.role) {
      case 'ROLE_FARMER': return '/dashboard-farmer.html';
      case 'ROLE_LIVESTOCK_OWNER': return '/dashboard-livestock.html';
      case 'ROLE_COMPANY': return '/dashboard-company.html';
      case 'ROLE_TRANSPORTER': return '/dashboard-transporter.html';
      case 'ROLE_ADMIN': return '/dashboard-admin.html';
      default: return '/index.html';
    }
  }
};

// Unified AJAX / Fetch API Wrapper
async function api(endpoint, options = {}) {
  const url = endpoint.startsWith('http') ? endpoint : API_BASE + endpoint;
  const headers = options.headers || {};

  const token = Auth.getToken();
  if (token && !headers['Authorization']) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  if (!(options.body instanceof FormData) && !headers['Content-Type']) {
    headers['Content-Type'] = 'application/json';
  }

  const config = {
    method: options.method || 'GET',
    headers: headers,
    ...options
  };

  try {
    const response = await fetch(url, config);

    if (response.status === 401 && Auth.isLoggedIn()) {
      // Token expired or invalid
      console.warn("Session expired. Logging out.");
      Auth.logout();
      return { success: false, message: "Session expired. Please log in again." };
    }

    const data = await response.json();
    return data;
  } catch (err) {
    console.error("API Request Error:", err);
    return { success: false, message: "Network connection error. Is the server running?" };
  }
}

// UI Toast Notification
function showToast(message, type = 'success') {
  let container = document.getElementById('toastContainer');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toastContainer';
    container.className = 'toast-container position-fixed bottom-0 end-0 p-3';
    document.body.appendChild(container);
  }

  const toastId = 'toast-' + Date.now();
  const bgClass = type === 'success' ? 'bg-success text-white' :
                  type === 'danger' || type === 'error' ? 'bg-danger text-white' :
                  type === 'warning' ? 'bg-warning text-dark' : 'bg-primary text-white';

  const toastEl = document.createElement('div');
  toastEl.className = `toast align-items-center ${bgClass} border-0 show mb-2`;
  toastEl.role = 'alert';
  toastEl.innerHTML = `
    <div class="d-flex">
      <div class="toast-body fw-medium">${message}</div>
      <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
    </div>
  `;

  container.appendChild(toastEl);
  setTimeout(() => {
    toastEl.classList.remove('show');
    setTimeout(() => toastEl.remove(), 300);
  }, 4000);
}

// Currency & Value Formatters
function formatCurrency(amount) {
  if (amount == null) return 'â‚¹0';
  return 'â‚¹' + Number(amount).toLocaleString('en-IN', { maximumFractionDigits: 2 });
}

function formatDate(dateStr) {
  if (!dateStr) return '';
  const d = new Date(dateStr);
  return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
}

// Global Navbar Initializer
function updateGlobalNavbar() {
  const user = Auth.getUser();
  const navAuthArea = document.getElementById('navbarAuthArea');
  if (!navAuthArea) return;

  if (user) {
    navAuthArea.innerHTML = `
      <div class="d-flex align-items-center gap-2">
        <a href="${Auth.getDashboardUrl()}" class="btn btn-outline-success btn-sm fw-semibold">
          <i class="bi bi-speedometer2 me-1"></i> Dashboard
        </a>
        <div class="dropdown">
          <button class="btn btn-light btn-sm dropdown-toggle fw-medium" type="button" data-bs-toggle="dropdown">
            <i class="bi bi-person-circle text-success me-1"></i> ${user.fullName.split(' ')[0]}
          </button>
          <ul class="dropdown-menu dropdown-menu-end shadow-sm">
            <li><span class="dropdown-item-text text-muted small">${user.email}</span></li>
            <li><span class="dropdown-item-text"><span class="badge bg-secondary">${user.role.replace('ROLE_', '')}</span></span></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="${Auth.getDashboardUrl()}"><i class="bi bi-grid me-2"></i>My Dashboard</a></li>
            <li><button class="dropdown-item text-danger" onclick="Auth.logout()"><i class="bi bi-box-arrow-right me-2"></i>Logout</button></li>
          </ul>
        </div>
      </div>
    `;
  } else {
    navAuthArea.innerHTML = `
      <div class="d-flex gap-2">
        <a href="/login.html" class="btn btn-outline-success btn-sm fw-semibold">Log In</a>
        <a href="/register.html" class="btn btn-success btn-sm fw-semibold">Register</a>
      </div>
    `;
  }
}

// QR Code Canvas Renderer for Digital Lot IDs
function renderQrCode(canvasId, text) {
  const canvas = document.getElementById(canvasId);
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const size = canvas.width;
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, size, size);

  // Generate deterministic visual matrix based on text hash
  ctx.fillStyle = '#0f172a';
  const cells = 21;
  const cellSize = size / cells;

  // Outer alignment squares
  function drawEye(x, y) {
    ctx.fillRect(x * cellSize, y * cellSize, 7 * cellSize, 7 * cellSize);
    ctx.fillStyle = '#ffffff';
    ctx.fillRect((x + 1) * cellSize, (y + 1) * cellSize, 5 * cellSize, 5 * cellSize);
    ctx.fillStyle = '#0f172a';
    ctx.fillRect((x + 2) * cellSize, (y + 2) * cellSize, 3 * cellSize, 3 * cellSize);
  }

  drawEye(0, 0);
  drawEye(14, 0);
  drawEye(0, 14);

  // Pseudo-random data modules seeded by string
  let hash = 0;
  for (let i = 0; i < text.length; i++) {
    hash = (hash << 5) - hash + text.charCodeAt(i);
    hash |= 0;
  }

  for (let r = 0; r < cells; r++) {
    for (let c = 0; c < cells; c++) {
      if ((r < 8 && c < 8) || (r < 8 && c > 12) || (r > 12 && c < 8)) continue;
      const bit = ((hash ^ (r * 31 + c * 17)) & 1);
      if (bit === 1) {
        ctx.fillRect(c * cellSize, r * cellSize, cellSize, cellSize);
      }
    }
  }
}

// Multi-Language i18n Dictionary
const I18N = {
  en: {
    tagline: "One Harvest. Multiple Markets. Better Income. Less Waste.",
    heroTitle: "Turn Every Harvest Into Opportunity.",
    heroSub: "Sell your harvest, fodder and agricultural residue to the right buyers through one trusted platform.",
    exploreMkt: "Explore Marketplace",
    sellHarvest: "Sell Your Harvest",
    findFodder: "Find Fodder",
    postReq: "Post a Requirement"
  },
  te: {
    tagline: "à°’à°•à±‡ à°ªà°‚à°Ÿ. à°¬à°¹à±à°³ à°®à°¾à°°à±à°•à±†à°Ÿà±à°²à±. à°®à±†à°°à±à°—à±ˆà°¨ à°†à°¦à°¾à°¯à°‚. à°µà±à°¯à°°à±à°¥à°‚ à°°à°¹à°¿à°¤à°‚.",
    heroTitle: "à°ªà±à°°à°¤à°¿ à°ªà°‚à°Ÿà°¨à± à°¬à°¹à±à°³ à°…à°µà°•à°¾à°¶à°‚à°—à°¾ à°®à°¾à°°à±à°šà°‚à°¡à°¿.",
    heroSub: "à°®à±€ à°ªà°‚à°Ÿ à°§à°¾à°¨à±à°¯à°‚, à°®à±‡à°¤ à°®à°°à°¿à°¯à± à°µà±à°¯à°µà°¸à°¾à°¯ à°µà±à°¯à°°à±à°¥à°¾à°²à°¨à± à°¸à°°à±ˆà°¨ à°•à±Šà°¨à±à°—à±‹à°²à±à°¦à°¾à°°à±à°²à°•à± à°¨à°®à±à°®à°•à°®à±ˆà°¨ à°µà±‡à°¦à°¿à°• à°¦à±à°µà°¾à°°à°¾ à°µà°¿à°•à±à°°à°¯à°¿à°‚à°šà°‚à°¡à°¿.",
    exploreMkt: "à°®à°¾à°°à±à°•à±†à°Ÿà±â€Œà°¨à± à°šà±‚à°¡à°‚à°¡à°¿",
    sellHarvest: "à°ªà°‚à°Ÿà°¨à± à°…à°®à±à°®à°‚à°¡à°¿",
    findFodder: "à°®à±‡à°¤à°¨à± à°µà±†à°¤à°•à°‚à°¡à°¿",
    postReq: "à°…à°µà°¸à°°à°¾à°¨à±à°¨à°¿ à°ªà±‹à°¸à±à°Ÿà± à°šà±‡à°¯à°‚à°¡à°¿"
  },
  hi: {
    tagline: "à¤à¤• à¤«à¤¸à¤²à¥¤ à¤…à¤¨à¥‡à¤• à¤¬à¤¾à¤œà¤¾à¤°à¥¤ à¤¬à¥‡à¤¹à¤¤à¤° à¤†à¤®à¤¦à¤¨à¥€à¥¤ à¤•à¤® à¤¬à¤°à¥à¤¬à¤¾à¤¦à¥€à¥¤",
    heroTitle: "à¤¹à¤° à¤«à¤¸à¤² à¤•à¥‹ à¤…à¤µà¤¸à¤° à¤®à¥‡à¤‚ à¤¬à¤¦à¤²à¥‡à¤‚à¥¤",
    heroSub: "à¤…à¤ªà¤¨à¥€ à¤®à¥à¤–à¥à¤¯ à¤«à¤¸à¤², à¤šà¤¾à¤°à¤¾ à¤”à¤° à¤•à¥ƒà¤·à¤¿ à¤…à¤µà¤¶à¥‡à¤·à¥‹à¤‚ à¤•à¥‹ à¤¸à¤¹à¥€ à¤–à¤°à¥€à¤¦à¤¾à¤°à¥‹à¤‚ à¤•à¥‹ à¤à¤• à¤µà¤¿à¤¶à¥à¤µà¤¸à¤¨à¥€à¤¯ à¤®à¤‚à¤š à¤ªà¤° à¤¬à¥‡à¤šà¥‡à¤‚à¥¤",
    exploreMkt: "à¤®à¤¾à¤°à¥à¤•à¥‡à¤Ÿà¤ªà¥à¤²à¥‡à¤¸ à¤¦à¥‡à¤–à¥‡à¤‚",
    sellHarvest: "à¤«à¤¸à¤² à¤¬à¥‡à¤šà¥‡à¤‚",
    findFodder: "à¤šà¤¾à¤°à¤¾ à¤–à¥‹à¤œà¥‡à¤‚",
    postReq: "à¤®à¤¾à¤‚à¤— à¤ªà¥‹à¤¸à¥à¤Ÿ à¤•à¤°à¥‡à¤‚"
  }
};

function switchLanguage(lang) {
  localStorage.setItem('agricycle_lang', lang);
  const dict = I18N[lang] || I18N.en;
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.getAttribute('data-i18n');
    if (dict[key]) el.textContent = dict[key];
  });
}

document.addEventListener('DOMContentLoaded', () => {
  updateGlobalNavbar();
  const savedLang = localStorage.getItem('agricycle_lang') || 'en';
  switchLanguage(savedLang);
});


/**
 * AgriCycle – Marketplace and Leaflet OpenStreetMap Search Controller
 */

let leafletMap = null;
let mapMarkers = [];

document.addEventListener('DOMContentLoaded', () => {
  loadCategoriesFilter();
  loadMarketplaceListings();

  // Filter input listeners
  const searchInput = document.getElementById('searchKeyword');
  if (searchInput) {
    let debounceTimer;
    searchInput.addEventListener('input', () => {
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(() => loadMarketplaceListings(), 400);
    });
  }

  const districtSelect = document.getElementById('filterDistrict');
  if (districtSelect) {
    districtSelect.addEventListener('change', () => loadMarketplaceListings());
  }

  const sortSelect = document.getElementById('filterSort');
  if (sortSelect) {
    sortSelect.addEventListener('change', () => loadMarketplaceListings());
  }
});

async function loadCategoriesFilter() {
  const res = await api('/categories');
  const container = document.getElementById('categoryPills');
  if (!container || !res.success) return;

  let html = `<button class="btn btn-outline-success btn-sm rounded-pill active" onclick="filterByCategory(null, this)">All Categories</button>`;
  res.data.forEach(cat => {
    html += `<button class="btn btn-outline-success btn-sm rounded-pill" onclick="filterByCategory(${cat.id}, this)">${cat.name}</button>`;
  });
  container.innerHTML = html;
}

let selectedCategoryId = null;

function filterByCategory(catId, btnEl) {
  selectedCategoryId = catId;
  const container = document.getElementById('categoryPills');
  if (container) {
    container.querySelectorAll('button').forEach(b => b.classList.remove('active'));
    if (btnEl) btnEl.classList.add('active');
  }
  loadMarketplaceListings();
}

async function loadMarketplaceListings() {
  const grid = document.getElementById('listingsGrid');
  if (!grid) return;

  grid.innerHTML = `
    <div class="col-12 text-center py-5">
      <div class="spinner-border text-success" role="status"></div>
      <p class="text-muted mt-2">Loading marketplace listings...</p>
    </div>
  `;

  const keyword = document.getElementById('searchKeyword') ? document.getElementById('searchKeyword').value.trim() : '';
  const district = document.getElementById('filterDistrict') ? document.getElementById('filterDistrict').value : '';
  const sortBy = document.getElementById('filterSort') ? document.getElementById('filterSort').value : 'recent';

  let query = `?size=24&sortBy=${sortBy}`;
  if (keyword) query += `&keyword=${encodeURIComponent(keyword)}`;
  if (district) query += `&district=${encodeURIComponent(district)}`;
  if (selectedCategoryId) query += `&categoryId=${selectedCategoryId}`;

  const res = await api('/listings/public' + query);

  if (!res.success || !res.data || !res.data.content || res.data.content.length === 0) {
    grid.innerHTML = `
      <div class="col-12 text-center py-5">
        <i class="bi bi-inbox text-muted" style="font-size: 3rem;"></i>
        <h5 class="mt-3">No listings match your criteria</h5>
        <p class="text-muted">Try clearing your search keyword or selected filters.</p>
        <button class="btn btn-outline-success btn-sm" onclick="resetFilters()">Reset All Filters</button>
      </div>
    `;
    updateMapMarkers([]);
    return;
  }

  const listings = res.data.content;
  renderListings(listings);
  updateMapMarkers(listings);
}

function renderListings(listings) {
  const grid = document.getElementById('listingsGrid');
  grid.innerHTML = '';

  listings.forEach(l => {
    const col = document.createElement('div');
    col.className = 'col-md-6 col-lg-4 mb-4';

    const categoryBadgeColor = l.categoryType === 'FODDER' ? 'bg-warning text-dark' :
                               l.categoryType === 'AGRICULTURAL_RESIDUE' ? 'bg-info text-white' : 'bg-success text-white';

    col.innerHTML = `
      <div class="listing-card">
        <div class="listing-img-box">
          <span class="badge ${categoryBadgeColor} listing-badge-float">${l.categoryName || 'Agricultural Material'}</span>
          <img src="/images/agri-pattern.png" onerror="this.onerror=null; this.src='https://images.unsplash.com/photo-1586771107445-d3ca888129ff?w=600&auto=format&fit=crop&q=60';" alt="${l.title}">
        </div>
        <div class="listing-card-body">
          <div class="d-flex justify-content-between align-items-center mb-1">
            <span class="badge-lot">${l.lotId || 'AGC-LOT'}</span>
            <small class="text-muted"><i class="bi bi-geo-alt-fill text-danger me-1"></i>${l.district}, ${l.state}</small>
          </div>
          <h5 class="fw-bold mb-1">${l.title}</h5>
          <p class="text-muted small mb-2 text-truncate">${l.description || 'Verified agricultural listing directly from farm.'}</p>
          
          <div class="d-flex align-items-center justify-content-between my-2 p-2 rounded bg-light">
            <div>
              <small class="text-muted d-block">Available Stock</small>
              <span class="fw-bold text-dark">${l.availableQuantity} ${l.unit}</span>
            </div>
            <div class="text-end">
              <small class="text-muted d-block">Price / ${l.unit}</small>
              <span class="listing-price-tag">${formatCurrency(l.pricePerUnit)}</span>
            </div>
          </div>

          <div class="d-flex justify-content-between align-items-center mt-auto pt-2">
            <div>
              <span class="fw-semibold text-dark small">${l.sellerName}</span>
              <div class="small text-warning"><i class="bi bi-star-fill"></i> ${l.sellerRating || 4.8} <span class="text-muted">(${l.sellerReviewsCount || 5})</span></div>
            </div>
            <div class="d-flex gap-1">
              <a href="/product-detail.html?id=${l.id}" class="btn btn-outline-secondary btn-sm">Details</a>
              <button class="btn btn-success btn-sm" onclick="openOrderModal(${l.id}, '${l.title.replace(/'/g, "\\'")}', ${l.pricePerUnit}, '${l.unit}', ${l.availableQuantity})">Order</button>
            </div>
          </div>
        </div>
      </div>
    `;
    grid.appendChild(col);
  });
}

// Leaflet OpenStreetMap Initialization
function initLeafletMap() {
  if (leafletMap != null) return;
  const mapEl = document.getElementById('mapContainer');
  if (!mapEl) return;

  // Center on Telangana (Hyderabad/Nalgonda region)
  leafletMap = L.map('mapContainer').setView([17.3850, 78.4867], 7);

  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 18,
    attribution: '&copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors'
  }).addTo(leafletMap);
}

function updateMapMarkers(listings) {
  if (!leafletMap) initLeafletMap();
  if (!leafletMap) return;

  // Clear existing markers
  mapMarkers.forEach(m => leafletMap.removeLayer(m));
  mapMarkers = [];

  listings.forEach(l => {
    if (l.latitude && l.longitude) {
      const marker = L.marker([l.latitude, l.longitude]).addTo(leafletMap);
      marker.bindPopup(`
        <div style="font-family: system-ui; max-width: 220px;">
          <span style="font-family: monospace; font-size: 11px; background: #e2e8f0; padding: 2px 4px; border-radius: 4px;">${l.lotId}</span>
          <h6 style="margin: 6px 0 2px 0; font-weight: bold;">${l.title}</h6>
          <div style="color: #1e7e34; font-weight: bold; font-size: 15px;">${formatCurrency(l.pricePerUnit)} / ${l.unit}</div>
          <div style="font-size: 12px; color: #64748b; margin-bottom: 8px;">Stock: ${l.availableQuantity} ${l.unit} | ${l.district}</div>
          <a href="/product-detail.html?id=${l.id}" class="btn btn-sm btn-primary" style="padding: 2px 8px; font-size: 12px; color: white; text-decoration: none; border-radius: 4px; display: inline-block;">View Product</a>
        </div>
      `);
      mapMarkers.push(marker);
    }
  });
}

function toggleView(mode) {
  const gridEl = document.getElementById('listingsGrid');
  const mapEl = document.getElementById('mapWrapper');
  const btnGrid = document.getElementById('btnGridView');
  const btnMap = document.getElementById('btnMapView');

  if (mode === 'map') {
    gridEl.classList.add('d-none');
    mapEl.classList.remove('d-none');
    btnMap.classList.add('active');
    btnGrid.classList.remove('active');
    setTimeout(() => {
      initLeafletMap();
      if (leafletMap) leafletMap.invalidateSize();
    }, 200);
  } else {
    gridEl.classList.remove('d-none');
    mapEl.classList.add('d-none');
    btnGrid.classList.add('active');
    btnMap.classList.remove('active');
  }
}

function resetFilters() {
  if (document.getElementById('searchKeyword')) document.getElementById('searchKeyword').value = '';
  if (document.getElementById('filterDistrict')) document.getElementById('filterDistrict').value = '';
  if (document.getElementById('filterSort')) document.getElementById('filterSort').value = 'recent';
  selectedCategoryId = null;
  const container = document.getElementById('categoryPills');
  if (container) {
    container.querySelectorAll('button').forEach((b, idx) => {
      if (idx === 0) b.classList.add('active');
      else b.classList.remove('active');
    });
  }
  loadMarketplaceListings();
}

// Order Modal Handler
let activeOrderListing = null;

function openOrderModal(listingId, title, pricePerUnit, unit, availableQty) {
  if (!Auth.isLoggedIn()) {
    showToast("Please log in to place an order.", "warning");
    setTimeout(() => { window.location.href = '/login.html'; }, 1000);
    return;
  }

  activeOrderListing = { id: listingId, title, pricePerUnit, unit, availableQty };
  document.getElementById('orderModalTitle').textContent = `Order: ${title}`;
  document.getElementById('orderModalPrice').textContent = `${formatCurrency(pricePerUnit)} / ${unit}`;
  document.getElementById('orderModalMaxQty').textContent = `${availableQty} ${unit}`;
  document.getElementById('orderQtyInput').value = Math.min(5, availableQty);
  document.getElementById('orderQtyInput').max = availableQty;

  calculateOrderTotal();

  const modal = new bootstrap.Modal(document.getElementById('placeOrderModal'));
  modal.show();
}

function calculateOrderTotal() {
  if (!activeOrderListing) return;
  const qty = parseFloat(document.getElementById('orderQtyInput').value) || 0;
  const total = qty * activeOrderListing.pricePerUnit;
  document.getElementById('orderCalculatedTotal').textContent = formatCurrency(total);
}

async function submitOrder() {
  if (!activeOrderListing) return;
  const qty = parseFloat(document.getElementById('orderQtyInput').value);
  const address = document.getElementById('orderDeliveryAddress').value.trim();
  const notes = document.getElementById('orderNotes').value.trim();

  if (!qty || qty <= 0) {
    showToast("Please enter a valid quantity.", "danger");
    return;
  }
  if (qty > activeOrderListing.availableQty) {
    showToast(`Quantity cannot exceed available stock (${activeOrderListing.availableQty} ${activeOrderListing.unit})`, "danger");
    return;
  }
  if (!address) {
    showToast("Please provide a delivery address.", "danger");
    return;
  }

  const payload = {
    listingId: activeOrderListing.id,
    quantity: qty,
    deliveryAddress: address,
    specialInstructions: notes
  };

  const res = await api('/orders', {
    method: 'POST',
    body: JSON.stringify(payload)
  });

  if (res.success) {
    bootstrap.Modal.getInstance(document.getElementById('placeOrderModal')).hide();
    showToast(`Order #${res.data.orderNumber} placed successfully!`, "success");
    loadMarketplaceListings();
  } else {
    showToast(res.message || "Failed to place order.", "danger");
  }
}

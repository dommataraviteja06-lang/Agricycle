package com.agricycle;

import com.agricycle.dto.BestUseRecommendationDto;
import com.agricycle.dto.HarvestValueCalculatorRequest;
import com.agricycle.dto.HarvestValueCalculatorResponse;
import com.agricycle.dto.PriceRecommendationDto;
import com.agricycle.service.AiService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.*;

class AiServiceTest {

    private AiService aiService;

    @BeforeEach
    void setUp() {
        aiService = new AiService(Mockito.mock(com.agricycle.repository.ListingRepository.class),
                                  Mockito.mock(com.agricycle.repository.RequirementRepository.class),
                                  Mockito.mock(com.agricycle.repository.OrderRepository.class),
                                  Mockito.mock(com.agricycle.repository.UserRepository.class));
    }

    @Test
    @DisplayName("AI Best-Use: Recommends multi-market uses for Rice Straw")
    void testBestUseRiceStraw() {
        BestUseRecommendationDto dto = aiService.getBestUseRecommendations("Rice Straw");
        assertNotNull(dto);
        assertEquals("Rice / Paddy", dto.getCropOrigin());
        assertFalse(dto.getRecommendedUses().isEmpty());
        assertTrue(dto.getRecommendedUses().stream().anyMatch(u -> u.getApplication().contains("Dairy & Cattle Fodder")));
        assertTrue(dto.getRecommendedUses().stream().anyMatch(u -> u.getApplication().contains("Biomass Pellets")));
        assertTrue(dto.getRecommendedUses().stream().anyMatch(u -> u.getApplication().contains("Mushroom Cultivation")));
        assertNotNull(dto.getDisclaimer());
    }

    @Test
    @DisplayName("AI Price: Returns realistic suggested price range with confidence rating")
    void testPriceRecommendation() {
        PriceRecommendationDto dto = aiService.getSuggestedPrice("Rice Husk", "Tons");
        assertNotNull(dto);
        assertTrue(dto.getSuggestedMinPrice() > 0);
        assertTrue(dto.getSuggestedMaxPrice() >= dto.getSuggestedMinPrice());
        assertNotNull(dto.getConfidence());
    }

    @Test
    @DisplayName("Harvest Value Calculator: Computes Main Crop + Fodder + Residue recovery total")
    void testHarvestValueCalculator() {
        HarvestValueCalculatorRequest req = new HarvestValueCalculatorRequest("Rice", 10.0, "Tons", "Nalgonda");
        HarvestValueCalculatorResponse res = aiService.calculateHarvestValue(req);

        assertNotNull(res);
        assertEquals(10.0, res.getMainCropYield());
        assertTrue(res.getMainCropEstimatedValue() > 0);
        assertTrue(res.getFodderEstimatedValue() > 0);
        assertTrue(res.getResidueEstimatedValue() > 0);
        assertEquals(res.getMainCropEstimatedValue() + res.getFodderEstimatedValue() + res.getResidueEstimatedValue(),
                     res.getEstimatedTotalRecoveryValue(), 0.01);
        assertTrue(res.getPercentageIncomeBoost() > 0);
        assertNotNull(res.getCalculationNote());
    }

    @Test
    @DisplayName("Environmental Impact: Calculates stubble burning avoided and CO2 mitigation")
    void testEnvironmentalImpact() {
        var impact = aiService.getEnvironmentalImpact();
        assertNotNull(impact);
        assertTrue(impact.getTotalResidueListedTons() > 0);
        assertTrue(impact.getResidueReusedTons() > 0);
        assertTrue(impact.getEstimatedCo2MitigatedTons() > 0);
        assertNotNull(impact.getMethodologyNote());
    }
}

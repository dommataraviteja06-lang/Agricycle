package com.agricycle;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;

@SpringBootTest
@AutoConfigureMockMvc
public class EndpointLatencyBenchmarkTest {

    @Autowired
    private MockMvc mockMvc;

    private static class BenchmarkResult {
        String endpoint;
        int totalRequests;
        double minMs;
        double avgMs;
        double maxMs;
        double p50Ms;
        double p95Ms;
        double p99Ms;
        double throughputReqSec;
        double errorRatePct;
        List<String> requestErrors;

        @Override
        public String toString() {
            return String.format("%-40s | Reqs: %3d | Min: %6.2fms | Avg: %6.2fms | Max: %6.2fms | P95: %6.2fms | Tput: %7.1f r/s | Err: %.1f%%",
                    endpoint, totalRequests, minMs, avgMs, maxMs, p95Ms, throughputReqSec, errorRatePct);
        }
    }

    private BenchmarkResult benchmarkEndpoint(String endpoint, int count) throws Exception {
        if (count <= 0) {
            throw new IllegalArgumentException("Request count must be positive");
        }

        List<Double> latencies = new ArrayList<>(count);
        List<String> requestErrors = new ArrayList<>();

        // Warm-up 5 requests
        for (int i = 0; i < 5; i++) {
            mockMvc.perform(get(endpoint)).andReturn();
        }

        long overallStart = System.nanoTime();

        for (int i = 0; i < count; i++) {
            long reqStart = System.nanoTime();
            try {
                MvcResult res = mockMvc.perform(get(endpoint)).andReturn();
                long reqDurationNs = System.nanoTime() - reqStart;
                latencies.add(reqDurationNs / 1_000_000.0);

                int statusCode = res.getResponse().getStatus();
                if (statusCode < 200 || statusCode >= 400) {
                    requestErrors.add("Request " + (i + 1) + " returned HTTP " + statusCode);
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw e;
            } catch (Exception e) {
                long reqDurationNs = System.nanoTime() - reqStart;
                latencies.add(reqDurationNs / 1_000_000.0);
                requestErrors.add("Request " + (i + 1) + " threw "
                        + e.getClass().getSimpleName() + ": " + e.getMessage());
            }
        }

        long totalDurationNs = System.nanoTime() - overallStart;
        double totalSeconds = totalDurationNs / 1_000_000_000.0;

        Collections.sort(latencies);
        BenchmarkResult r = new BenchmarkResult();
        r.endpoint = endpoint;
        r.totalRequests = count;
        r.minMs = latencies.get(0);
        r.maxMs = latencies.get(latencies.size() - 1);
        r.avgMs = latencies.stream().mapToDouble(Double::doubleValue).average().orElse(0.0);
        r.p50Ms = latencies.get(percentileIndex(count, 0.50));
        r.p95Ms = latencies.get(percentileIndex(count, 0.95));
        r.p99Ms = latencies.get(percentileIndex(count, 0.99));
        r.throughputReqSec = count / totalSeconds;
        r.errorRatePct = (requestErrors.size() * 100.0) / count;
        r.requestErrors = requestErrors;

        return r;
    }

    private static int percentileIndex(int sampleCount, double percentile) {
        if (sampleCount <= 0) {
            throw new IllegalArgumentException("Sample count must be positive");
        }
        if (!Double.isFinite(percentile) || percentile <= 0.0 || percentile > 1.0) {
            throw new IllegalArgumentException("Percentile must be in the range (0, 1]");
        }

        return (int) Math.ceil(sampleCount * percentile) - 1;
    }

    @Test
    @DisplayName("Calculate nearest-rank latency percentiles")
    void calculatesNearestRankPercentiles() {
        assertEquals(0, percentileIndex(1, 0.50));
        assertEquals(24, percentileIndex(50, 0.50));
        assertEquals(47, percentileIndex(50, 0.95));
        assertEquals(49, percentileIndex(50, 0.99));
        assertThrows(IllegalArgumentException.class, () -> percentileIndex(0, 0.50));
        assertThrows(IllegalArgumentException.class, () -> percentileIndex(50, 0.0));
        assertThrows(IllegalArgumentException.class, () -> percentileIndex(50, Double.NaN));
        assertThrows(IllegalArgumentException.class, () -> percentileIndex(50, 1.01));
        assertThrows(IllegalArgumentException.class, () -> percentileIndex(50, Double.POSITIVE_INFINITY));
    }

    @Test
    @DisplayName("Benchmark 50 rapid requests across high-frequency endpoints")
    void testHighFrequencyEndpointBenchmarks() throws Exception {
        int requestsPerEndpoint = 50;

        BenchmarkResult listingsResult = benchmarkEndpoint("/api/v1/listings/search", requestsPerEndpoint);
        BenchmarkResult categoriesResult = benchmarkEndpoint("/api/v1/categories", requestsPerEndpoint);
        BenchmarkResult aiImpactResult = benchmarkEndpoint("/api/v1/ai/environmental-impact", requestsPerEndpoint);

        System.out.println("==========================================================================================================");
        System.out.println("HIGH-FREQUENCY ENDPOINT LATENCY BENCHMARK REPORT (50 RAPID REQUESTS EACH)");
        System.out.println("==========================================================================================================");
        System.out.println(listingsResult);
        System.out.println(categoriesResult);
        System.out.println(aiImpactResult);
        System.out.println("==========================================================================================================");

        // Assertions for error rate
        assertEquals(0.0, listingsResult.errorRatePct,
                "GET /api/v1/listings/search error rate must be 0.0%: " + listingsResult.requestErrors);
        assertEquals(0.0, categoriesResult.errorRatePct,
                "GET /api/v1/categories error rate must be 0.0%: " + categoriesResult.requestErrors);
        assertEquals(0.0, aiImpactResult.errorRatePct,
                "GET /api/v1/ai/environmental-impact error rate must be 0.0%: " + aiImpactResult.requestErrors);

        // Assertions for latency
        assertTrue(listingsResult.avgMs < 200.0, "Listings search average latency should be under 200ms");
        assertTrue(categoriesResult.avgMs < 50.0, "Categories average latency should be under 50ms");
        assertTrue(aiImpactResult.avgMs < 100.0, "AI environmental impact average latency should be under 100ms");
    }
}

package com.agricycle;

import com.agricycle.dto.CreateOrderRequest;
import com.agricycle.entity.*;
import com.agricycle.exception.BadRequestException;
import com.agricycle.repository.CategoryRepository;
import com.agricycle.repository.ListingRepository;
import com.agricycle.repository.UserRepository;
import com.agricycle.service.OrderService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
public class OrderConcurrencyStressTest {

    @Autowired
    private OrderService orderService;

    @Autowired
    private ListingRepository listingRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private CategoryRepository categoryRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private PlatformTransactionManager transactionManager;

    private Long buyerId;
    private Long testListingId;

    @BeforeEach
    void setUp() {
        TransactionTemplate template = new TransactionTemplate(transactionManager);
        template.execute(status -> {
            // Setup Farmer / Seller
            User seller = userRepository.findByEmail("farmer.concurrency@agricycle.com")
                    .orElseGet(() -> userRepository.save(new User(
                            "farmer.concurrency@agricycle.com",
                            passwordEncoder.encode("Password@123"),
                            "Concurrency Farmer",
                            "9848099887",
                            Role.ROLE_FARMER,
                            UserStatus.ACTIVE
                    )));
            sellerId = seller.getId();

            // Setup Buyer
            User buyer = userRepository.findByEmail("buyer.concurrency@agricycle.com")
                    .orElseGet(() -> userRepository.save(new User(
                            "buyer.concurrency@agricycle.com",
                            passwordEncoder.encode("Password@123"),
                            "Concurrency Buyer",
                            "9701099887",
                            Role.ROLE_COMPANY,
                            UserStatus.ACTIVE
                    )));
            buyerId = buyer.getId();

            Category category = categoryRepository.findAll().stream().findFirst()
                    .orElseGet(() -> categoryRepository.save(new Category(
                            "Test Biomass", "test-biomass", CategoryType.AGRICULTURAL_RESIDUE, "Test category", "bi-fire", true
                    )));

            // Setup Listing with initial quantity of 10.0 Tons
            Listing listing = new Listing();
            listing.setSeller(seller);
            listing.setCategory(category);
            listing.setTitle("High Stress Test Fodder Lot");
            listing.setProductMaterialName("Rice Straw");
            listing.setQuantity(10.0);
            listing.setAvailableQuantity(10.0);
            listing.setUnit("Tons");
            listing.setPricePerUnit(1500.0);
            listing.setDistrict("Nalgonda");
            listing.setState("Telangana");
            listing.setLotId("AGC-TEST-CONCUR-" + System.currentTimeMillis());
            listing.setListingStatus(ListingStatus.APPROVED);
            listing.setVerificationStatus(VerificationStatus.VERIFIED);
            listing = listingRepository.save(listing);
            testListingId = listing.getId();

            return null;
        });
    }

    @Test
    @DisplayName("Verify atomic quantity deduction and zero overselling under 20 concurrent threads")
    void testConcurrentOrderPlacementAtomicity() throws InterruptedException {
        int concurrentThreads = 20;
        double orderQuantityEach = 1.0; // Each thread attempts to buy 1.0 Ton (Total requested = 20.0, available = 10.0)

        ExecutorService executor = Executors.newFixedThreadPool(concurrentThreads);
        CountDownLatch startLatch = new CountDownLatch(1);
        CountDownLatch finishLatch = new CountDownLatch(concurrentThreads);

        AtomicInteger successOrders = new AtomicInteger(0);
        AtomicInteger rejectedQuantityExceeded = new AtomicInteger(0);
        AtomicInteger otherErrors = new AtomicInteger(0);
        List<Long> latenciesMs = Collections.synchronizedList(new ArrayList<>());
        List<String> otherErrorMessages = Collections.synchronizedList(new ArrayList<>());

        for (int i = 0; i < concurrentThreads; i++) {
            final int threadIndex = i;
            executor.submit(() -> {
                try {
                    startLatch.await(); // Wait for all threads to be ready for synchronized burst
                    long startTime = System.nanoTime();

                    CreateOrderRequest req = new CreateOrderRequest();
                    req.setListingId(testListingId);
                    req.setQuantity(orderQuantityEach);
                    req.setDeliveryAddress("Concurrency Stress Test Hub");
                    req.setDistrict("Nalgonda");
                    req.setState("Telangana");
                    req.setSpecialInstructions("Thread " + threadIndex);

                    orderService.createOrder(req, buyerId, "127.0.0.1");
                    long durationMs = (System.nanoTime() - startTime) / 1_000_000;
                    latenciesMs.add(durationMs);
                    successOrders.incrementAndGet();

                } catch (BadRequestException bre) {
                    if (bre.getMessage().contains("Requested quantity exceeds available quantity")) {
                        rejectedQuantityExceeded.incrementAndGet();
                    } else {
                        otherErrors.incrementAndGet();
                    }
                } catch (Exception ex) {
                    otherErrors.incrementAndGet();
                    otherErrorMessages.add(ex.getClass().getSimpleName() + ": " + ex.getMessage());
                } finally {
                    finishLatch.countDown();
                }
            });
        }

        // Fire all threads simultaneously
        long burstStart = System.currentTimeMillis();
        startLatch.countDown();
        boolean completed = finishLatch.await(30, TimeUnit.SECONDS);
        long burstDurationMs = System.currentTimeMillis() - burstStart;

        executor.shutdown();

        assertTrue(completed, "All concurrent order placement threads must complete within timeout");

        // Verify remaining inventory in database
        Listing updatedListing = listingRepository.findById(testListingId).orElseThrow();

        System.out.println("=================================================");
        System.out.println("CONCURRENCY TEST EXECUTION SUMMARY");
        System.out.println("=================================================");
        System.out.println("Total Concurrent Requests:     " + concurrentThreads);
        System.out.println("Successful Orders:             " + successOrders.get());
        System.out.println("Quantity Exceeded Rejections:  " + rejectedQuantityExceeded.get());
        System.out.println("Other Errors:                  " + otherErrors.get());
        System.out.println("Burst Duration:                " + burstDurationMs + " ms");
        System.out.println("Final Available Quantity:      " + updatedListing.getAvailableQuantity());
        System.out.println("Final Listing Status:          " + updatedListing.getListingStatus());
        System.out.println("=================================================");

        // STRICT INVENTORY INTEGRITY ASSERTIONS:
        // 1. Initial quantity was 10.0, each successful order took 1.0 => exactly 10 orders must succeed
        assertEquals(10, successOrders.get(), "Exactly 10 orders must succeed for 10 units available");
        // 2. 10 orders must be rejected cleanly with stock exceeded
        assertEquals(10, rejectedQuantityExceeded.get(), "Remaining 10 orders must be rejected cleanly");
        // 3. Zero unexpected errors
        assertEquals(0, otherErrors.get(),
                "No unexpected 500 or deadlock errors allowed: " + otherErrorMessages);
        // 4. Final available quantity must be exactly 0.0, never negative
        assertEquals(0.0, updatedListing.getAvailableQuantity(), 0.001, "Final available quantity must be exactly 0.0");
        // 5. Listing status must transition to SOLD
        assertEquals(ListingStatus.SOLD, updatedListing.getListingStatus(), "Listing status must be SOLD when depleted");
    }
}

package com.agricycle;

import com.agricycle.dto.RegisterRequest;
import com.agricycle.entity.Role;
import com.agricycle.exception.BadRequestException;
import com.agricycle.repository.*;
import com.agricycle.security.JwtUtils;
import com.agricycle.service.AuditService;
import com.agricycle.service.AuthService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.jupiter.api.Assertions.*;

class SecurityAndRbacTest {

    private AuthService authService;
    private JwtUtils jwtUtils;
    private PasswordEncoder passwordEncoder;
    private UserRepository userRepository;

    @BeforeEach
    void setUp() {
        passwordEncoder = new BCryptPasswordEncoder(12);
        userRepository = Mockito.mock(UserRepository.class);
        jwtUtils = new JwtUtils();
        ReflectionTestUtils.setField(jwtUtils, "jwtSecret", "404E635266556A586E3272357538782F413F4428472B4B6250645367566B5970");
        ReflectionTestUtils.setField(jwtUtils, "jwtExpirationMs", 86400000L);
        ReflectionTestUtils.setField(jwtUtils, "jwtRefreshExpirationMs", 604800000L);

        authService = new AuthService(
                userRepository,
                Mockito.mock(FarmerProfileRepository.class),
                Mockito.mock(LivestockProfileRepository.class),
                Mockito.mock(CompanyProfileRepository.class),
                Mockito.mock(TransportProfileRepository.class),
                passwordEncoder,
                jwtUtils,
                Mockito.mock(AuditService.class)
        );
    }

    @Test
    @DisplayName("Security: Normal user registration with ROLE_ADMIN is strictly blocked")
    void testNormalUserCannotCreateRoleAdmin() {
        RegisterRequest req = new RegisterRequest();
        req.setEmail("attacker@exploit.com");
        req.setPassword("Password@123");
        req.setFullName("Attacker");
        req.setRole(Role.ROLE_ADMIN); // Privilege escalation attempt

        assertThrows(BadRequestException.class, () -> {
            authService.register(req, "192.168.1.100");
        });
    }

    @Test
    @DisplayName("Security: Passwords must be hashed using BCrypt and not stored in plaintext")
    void testBcryptPasswordHashing() {
        String rawPassword = "SecurePassword@2026";
        String encoded = passwordEncoder.encode(rawPassword);

        assertNotEquals(rawPassword, encoded);
        assertTrue(encoded.startsWith("$2a$") || encoded.startsWith("$2b$"));
        assertTrue(passwordEncoder.matches(rawPassword, encoded));
        assertFalse(passwordEncoder.matches("WrongPassword", encoded));
    }

    @Test
    @DisplayName("Security: JWT Access Token generation and claim extraction")
    void testJwtTokenGenerationAndClaims() {
        String token = jwtUtils.generateAccessToken("farmer@agricycle.com", "ROLE_FARMER", 42L);

        assertNotNull(token);
        assertTrue(jwtUtils.validateToken(token));
        assertEquals("farmer@agricycle.com", jwtUtils.getEmailFromToken(token));
        assertEquals("ROLE_FARMER", jwtUtils.getRoleFromToken(token));
        assertEquals(42L, jwtUtils.getUserIdFromToken(token));
    }

    @Test
    @DisplayName("Security: Tampered or forged JWT token must fail validation")
    void testForgedTokenRejected() {
        String token = jwtUtils.generateAccessToken("farmer@agricycle.com", "ROLE_FARMER", 42L);
        String forgedToken = token + "xyz123";

        assertFalse(jwtUtils.validateToken(forgedToken));
    }
}

package com.agricycle.service;

import com.agricycle.dto.NegotiateOrderRequest;
import com.agricycle.dto.OrderNegotiationDto;
import com.agricycle.entity.*;
import com.agricycle.exception.BadRequestException;
import com.agricycle.exception.ForbiddenException;
import com.agricycle.exception.ResourceNotFoundException;
import com.agricycle.repository.OrderNegotiationRepository;
import com.agricycle.repository.OrderRepository;
import com.agricycle.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class NegotiationService {

    private final OrderNegotiationRepository negotiationRepository;
    private final OrderRepository orderRepository;
    private final UserRepository userRepository;
    private final NotificationService notificationService;
    private final AuditService auditService;

    public NegotiationService(OrderNegotiationRepository negotiationRepository,
                              OrderRepository orderRepository,
                              UserRepository userRepository,
                              NotificationService notificationService,
                              AuditService auditService) {
        this.negotiationRepository = negotiationRepository;
        this.orderRepository = orderRepository;
        this.userRepository = userRepository;
        this.notificationService = notificationService;
        this.auditService = auditService;
    }

    @Transactional
    public OrderNegotiationDto proposeNegotiation(Long orderId, NegotiateOrderRequest req, Long currentUserId, String clientIp) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found with id: " + orderId));

        User currentUser = userRepository.findById(currentUserId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        boolean isBuyer = order.getBuyer().getId().equals(currentUserId);
        boolean isSeller = order.getSeller().getId().equals(currentUserId);

        if (!isBuyer && !isSeller) {
            throw new ForbiddenException("Only the buyer or seller can negotiate terms on this order.");
        }

        if (order.getStatus() != OrderStatus.PENDING &&
            order.getStatus() != OrderStatus.ACCEPTED &&
            order.getStatus() != OrderStatus.NEGOTIATION) {
            throw new BadRequestException("Order cannot be negotiated in status: " + order.getStatus() + ". Terms are locked.");
        }

        OrderNegotiation neg = new OrderNegotiation();
        neg.setOrder(order);
        neg.setProposedByUser(currentUser);
        neg.setProposedPrice(req.getProposedPrice());
        neg.setProposedQuantity(req.getProposedQuantity());
        neg.setProposedDeliveryDate(req.getProposedDeliveryDate());
        neg.setNotes(req.getNotes());
        neg.setStatus(OrderNegotiation.NegotiationStatus.PROPOSED);

        neg = negotiationRepository.save(neg);

        order.setStatus(OrderStatus.NEGOTIATION);
        orderRepository.save(order);

        // Notify other party
        User recipient = isBuyer ? order.getSeller() : order.getBuyer();
        notificationService.sendNotification(
                recipient,
                "🤝 New Negotiation Counter-Offer",
                String.format("%s proposed new terms: Price ₹%.2f, Qty %.1f on Order #%s",
                        currentUser.getFullName(), req.getProposedPrice(), req.getProposedQuantity(), order.getOrderNumber()),
                NotificationType.NEGOTIATION,
                order.getId()
        );

        auditService.log(currentUserId, currentUser.getEmail(), "ORDER_NEGOTIATION_PROPOSED", "OrderNegotiation", neg.getId(),
                "Proposed price: ₹" + req.getProposedPrice() + ", Qty: " + req.getProposedQuantity(), clientIp, "SUCCESS");

        return mapToDto(neg);
    }

    @Transactional
    public OrderNegotiationDto acceptNegotiation(Long negotiationId, Long currentUserId, String clientIp) {
        OrderNegotiation neg = negotiationRepository.findById(negotiationId)
                .orElseThrow(() -> new ResourceNotFoundException("Negotiation not found"));

        Order order = neg.getOrder();
        boolean isBuyer = order.getBuyer().getId().equals(currentUserId);
        boolean isSeller = order.getSeller().getId().equals(currentUserId);

        if (!isBuyer && !isSeller) {
            throw new ForbiddenException("Not authorized.");
        }

        if (neg.getProposedByUser().getId().equals(currentUserId)) {
            throw new BadRequestException("You cannot accept your own proposal.");
        }

        neg.setStatus(OrderNegotiation.NegotiationStatus.ACCEPTED);
        negotiationRepository.save(neg);

        // Apply negotiated terms to order
        order.setTotalAmount(neg.getProposedPrice() * neg.getProposedQuantity());
        if (!order.getItems().isEmpty()) {
            OrderItem item = order.getItems().get(0);
            item.setPricePerUnit(neg.getProposedPrice());
            item.setQuantity(neg.getProposedQuantity());
            item.setTotalPrice(order.getTotalAmount());
        }
        order.setStatus(OrderStatus.ACCEPTED);
        orderRepository.save(order);

        auditService.log(currentUserId, "user", "ORDER_NEGOTIATION_ACCEPTED", "OrderNegotiation", negotiationId,
                "Accepted terms: Price ₹" + neg.getProposedPrice() + ", Qty: " + neg.getProposedQuantity(), clientIp, "SUCCESS");

        return mapToDto(neg);
    }

    @Transactional(readOnly = true)
    public List<OrderNegotiationDto> getNegotiationHistory(Long orderId) {
        return negotiationRepository.findByOrderIdOrderByCreatedAtDesc(orderId)
                .stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    private OrderNegotiationDto mapToDto(OrderNegotiation n) {
        OrderNegotiationDto dto = new OrderNegotiationDto();
        dto.setId(n.getId());
        dto.setOrderId(n.getOrder().getId());
        dto.setProposedByUserId(n.getProposedByUser().getId());
        dto.setProposedByUserName(n.getProposedByUser().getFullName());
        dto.setProposedPrice(n.getProposedPrice());
        dto.setProposedQuantity(n.getProposedQuantity());
        dto.setProposedDeliveryDate(n.getProposedDeliveryDate());
        dto.setNotes(n.getNotes());
        dto.setStatus(n.getStatus());
        dto.setCreatedAt(n.getCreatedAt());
        return dto;
    }
}

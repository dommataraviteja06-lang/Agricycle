package com.agricycle.service;

import com.agricycle.dto.TransportJobDto;
import com.agricycle.dto.UpdateTransportStatusRequest;
import com.agricycle.dto.VehicleDto;
import com.agricycle.entity.*;
import com.agricycle.exception.BadRequestException;
import com.agricycle.exception.ForbiddenException;
import com.agricycle.exception.ResourceNotFoundException;
import com.agricycle.repository.*;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class TransportService {

    private final TransportJobRepository transportJobRepository;
    private final VehicleRepository vehicleRepository;
    private final OrderRepository orderRepository;
    private final UserRepository userRepository;
    private final NotificationService notificationService;
    private final AuditService auditService;

    public TransportService(TransportJobRepository transportJobRepository,
                            VehicleRepository vehicleRepository,
                            OrderRepository orderRepository,
                            UserRepository userRepository,
                            NotificationService notificationService,
                            AuditService auditService) {
        this.transportJobRepository = transportJobRepository;
        this.vehicleRepository = vehicleRepository;
        this.orderRepository = orderRepository;
        this.userRepository = userRepository;
        this.notificationService = notificationService;
        this.auditService = auditService;
    }

    @Transactional(readOnly = true)
    public Page<TransportJobDto> getAvailableJobs(String district, int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        return transportJobRepository.findAvailableJobs(district, pageable).map(this::mapToDto);
    }

    @Transactional
    public TransportJobDto acceptJob(Long jobId, Long transporterUserId, String clientIp) {
        TransportJob job = transportJobRepository.findById(jobId)
                .orElseThrow(() -> new ResourceNotFoundException("Transport job not found"));

        if (job.getStatus() != TransportStatus.REQUESTED) {
            throw new BadRequestException("This job is no longer available.");
        }

        User transporter = userRepository.findById(transporterUserId)
                .orElseThrow(() -> new ResourceNotFoundException("Transporter not found"));

        job.setTransporter(transporter);
        job.setStatus(TransportStatus.ASSIGNED);
        job.setAssignedAt(LocalDateTime.now());
        job = transportJobRepository.save(job);

        // Update corresponding order
        Order order = job.getOrder();
        order.setStatus(OrderStatus.TRANSPORT_ASSIGNED);
        orderRepository.save(order);

        // Notify buyer & seller
        String msg = String.format("Transporter %s (%s) assigned to Order #%s",
                transporter.getFullName(), transporter.getMobile(), order.getOrderNumber());
        notificationService.sendNotification(order.getBuyer(), "🚛 Transport Assigned", msg, NotificationType.TRANSPORT, order.getId());
        notificationService.sendNotification(order.getSeller(), "🚛 Transport Assigned", msg, NotificationType.TRANSPORT, order.getId());

        auditService.log(transporterUserId, transporter.getEmail(), "TRANSPORT_JOB_ACCEPTED", "TransportJob", jobId,
                "Accepted delivery job for Order #" + order.getOrderNumber(), clientIp, "SUCCESS");

        return mapToDto(job);
    }

    @Transactional
    public TransportJobDto updateJobStatus(Long jobId, UpdateTransportStatusRequest req, Long transporterUserId, String clientIp) {
        TransportJob job = transportJobRepository.findById(jobId)
                .orElseThrow(() -> new ResourceNotFoundException("Transport job not found"));

        if (!job.getTransporter().getId().equals(transporterUserId)) {
            throw new ForbiddenException("Not authorized to update this transport job.");
        }

        job.setStatus(req.getStatus());
        if (req.getTrackingNotes() != null) {
            job.setTrackingNotes(req.getTrackingNotes());
        }

        Order order = job.getOrder();

        if (req.getStatus() == TransportStatus.PICKED_UP) {
            job.setPickedUpAt(LocalDateTime.now());
            order.setStatus(OrderStatus.PICKED_UP);
        } else if (req.getStatus() == TransportStatus.IN_TRANSIT) {
            order.setStatus(OrderStatus.IN_TRANSIT);
        } else if (req.getStatus() == TransportStatus.DELIVERED) {
            job.setDeliveredAt(LocalDateTime.now());
            order.setStatus(OrderStatus.DELIVERED);
        } else if (req.getStatus() == TransportStatus.COMPLETED) {
            job.setStatus(TransportStatus.COMPLETED);
        }

        orderRepository.save(order);
        job = transportJobRepository.save(job);

        // Notify parties
        String updateMsg = "Delivery progress for Order #" + order.getOrderNumber() + ": Status is now " + req.getStatus();
        notificationService.sendNotification(order.getBuyer(), "📦 Transport Update", updateMsg, NotificationType.TRANSPORT, order.getId());
        notificationService.sendNotification(order.getSeller(), "📦 Transport Update", updateMsg, NotificationType.TRANSPORT, order.getId());

        auditService.log(transporterUserId, job.getTransporter().getEmail(), "TRANSPORT_STATUS_UPDATED", "TransportJob", jobId,
                "Status set to " + req.getStatus(), clientIp, "SUCCESS");

        return mapToDto(job);
    }

    @Transactional(readOnly = true)
    public List<TransportJobDto> getTransporterJobs(Long transporterUserId) {
        return transportJobRepository.findByTransporter_IdOrderByCreatedAtDesc(transporterUserId)
                .stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public Double getTransporterEarnings(Long transporterUserId) {
        Double total = transportJobRepository.sumTransporterEarnings(transporterUserId);
        return total != null ? total : 0.0;
    }

    // Vehicle management
    @Transactional
    public VehicleDto addVehicle(VehicleDto dto, Long transporterUserId) {
        User transporter = userRepository.findById(transporterUserId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        Vehicle vehicle = new Vehicle();
        vehicle.setTransporter(transporter);
        vehicle.setVehicleNumber(dto.getVehicleNumber().trim().toUpperCase());
        vehicle.setVehicleType(dto.getVehicleType().trim());
        vehicle.setCapacityTons(dto.getCapacityTons());
        vehicle.setDistrict(dto.getDistrict());
        vehicle.setAvailable(true);

        vehicle = vehicleRepository.save(vehicle);

        dto.setId(vehicle.getId());
        dto.setTransporterId(transporterUserId);
        dto.setCreatedAt(vehicle.getCreatedAt());
        return dto;
    }

    @Transactional(readOnly = true)
    public List<VehicleDto> getTransporterVehicles(Long transporterUserId) {
        return vehicleRepository.findByTransporter_Id(transporterUserId).stream().map(v -> {
            VehicleDto d = new VehicleDto();
            d.setId(v.getId());
            d.setTransporterId(v.getTransporter().getId());
            d.setVehicleNumber(v.getVehicleNumber());
            d.setVehicleType(v.getVehicleType());
            d.setCapacityTons(v.getCapacityTons());
            d.setDistrict(v.getDistrict());
            d.setAvailable(v.isAvailable());
            d.setCreatedAt(v.getCreatedAt());
            return d;
        }).collect(Collectors.toList());
    }

    public TransportJobDto mapToDto(TransportJob tj) {
        TransportJobDto dto = new TransportJobDto();
        dto.setId(tj.getId());
        dto.setOrderId(tj.getOrder().getId());
        dto.setOrderNumber(tj.getOrder().getOrderNumber());
        if (tj.getTransporter() != null) {
            dto.setTransporterId(tj.getTransporter().getId());
            dto.setTransporterName(tj.getTransporter().getFullName());
            dto.setTransporterMobile(tj.getTransporter().getMobile());
        }
        dto.setPickupLocation(tj.getPickupLocation());
        dto.setPickupDistrict(tj.getPickupDistrict());
        dto.setDeliveryLocation(tj.getDeliveryLocation());
        dto.setDeliveryDistrict(tj.getDeliveryDistrict());
        dto.setWeightTons(tj.getWeightTons());
        dto.setVehicleTypeRequired(tj.getVehicleTypeRequired());
        dto.setAgreedFare(tj.getAgreedFare());
        dto.setStatus(tj.getStatus());
        dto.setSharedTransport(tj.isSharedTransport());
        dto.setTrackingNotes(tj.getTrackingNotes());
        dto.setAssignedAt(tj.getAssignedAt());
        dto.setPickedUpAt(tj.getPickedUpAt());
        dto.setDeliveredAt(tj.getDeliveredAt());
        dto.setCreatedAt(tj.getCreatedAt());
        return dto;
    }
}

package com.agricycle.service;

import com.agricycle.dto.CreateDisputeRequest;
import com.agricycle.dto.DisputeDto;
import com.agricycle.dto.ResolveDisputeRequest;
import com.agricycle.entity.*;
import com.agricycle.exception.BadRequestException;
import com.agricycle.exception.ForbiddenException;
import com.agricycle.exception.ResourceNotFoundException;
import com.agricycle.repository.*;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class DisputeService {

    private final DisputeRepository disputeRepository;
    private final OrderRepository orderRepository;
    private final UserRepository userRepository;
    private final AuditService auditService;
    private final NotificationService notificationService;

    public DisputeService(DisputeRepository disputeRepository,
                          OrderRepository orderRepository,
                          UserRepository userRepository,
                          AuditService auditService,
                          NotificationService notificationService) {
        this.disputeRepository = disputeRepository;
        this.orderRepository = orderRepository;
        this.userRepository = userRepository;
        this.auditService = auditService;
        this.notificationService = notificationService;
    }

    @Transactional
    public DisputeDto raiseDispute(CreateDisputeRequest req, Long currentUserId, String clientIp) {
        Order order = orderRepository.findById(req.getOrderId())
                .orElseThrow(() -> new ResourceNotFoundException("Order not found"));

        boolean isBuyer = order.getBuyer().getId().equals(currentUserId);
        boolean isSeller = order.getSeller().getId().equals(currentUserId);

        if (!isBuyer && !isSeller) {
            throw new ForbiddenException("Only the buyer or seller can file a dispute on this order.");
        }

        User user = userRepository.findById(currentUserId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        Dispute dispute = new Dispute();
        dispute.setOrder(order);
        dispute.setRaisedByUser(user);
        dispute.setReason(req.getReason());
        dispute.setDescription(req.getDescription());
        dispute.setStatus(DisputeStatus.OPEN);

        dispute = disputeRepository.save(dispute);

        order.setStatus(OrderStatus.DISPUTED);
        orderRepository.save(order);

        auditService.log(currentUserId, user.getEmail(), "DISPUTE_RAISED", "Dispute", dispute.getId(),
                "Dispute raised on Order #" + order.getOrderNumber() + " Reason: " + req.getReason(), clientIp, "SUCCESS");

        return mapToDto(dispute);
    }

    @Transactional(readOnly = true)
    public Page<DisputeDto> getDisputesForAdmin(DisputeStatus status, int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "createdAt"));
        if (status != null) {
            return disputeRepository.findByStatus(status, pageable).map(this::mapToDto);
        }
        return disputeRepository.findAll(pageable).map(this::mapToDto);
    }

    @Transactional(readOnly = true)
    public List<DisputeDto> getUserDisputes(Long currentUserId) {
        return disputeRepository.findByRaisedByUser_Id(currentUserId)
                .stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Transactional
    public DisputeDto resolveDispute(Long disputeId, ResolveDisputeRequest req, Long adminId, String clientIp) {
        Dispute dispute = disputeRepository.findById(disputeId)
                .orElseThrow(() -> new ResourceNotFoundException("Dispute not found"));

        User admin = userRepository.findById(adminId)
                .orElseThrow(() -> new ResourceNotFoundException("Admin not found"));

        dispute.setStatus(req.getStatus());
        dispute.setResolutionNotes(req.getResolutionNotes());
        dispute.setResolvedByAdmin(admin);
        dispute.setResolvedAt(LocalDateTime.now());

        dispute = disputeRepository.save(dispute);

        // Notify dispute raiser
        notificationService.sendNotification(
                dispute.getRaisedByUser(),
                "Dispute Resolved",
                "Your dispute on Order #" + dispute.getOrder().getOrderNumber() + " has been marked " + req.getStatus() + ". Notes: " + req.getResolutionNotes(),
                NotificationType.ORDER,
                dispute.getOrder().getId()
        );

        auditService.log(adminId, admin.getEmail(), "DISPUTE_RESOLVED", "Dispute", disputeId,
                "Dispute marked " + req.getStatus() + " by Admin", clientIp, "SUCCESS");

        return mapToDto(dispute);
    }

    public DisputeDto mapToDto(Dispute d) {
        DisputeDto dto = new DisputeDto();
        dto.setId(d.getId());
        dto.setOrderId(d.getOrder().getId());
        dto.setOrderNumber(d.getOrder().getOrderNumber());
        dto.setRaisedByUserId(d.getRaisedByUser().getId());
        dto.setRaisedByUserName(d.getRaisedByUser().getFullName());
        dto.setReason(d.getReason());
        dto.setDescription(d.getDescription());
        dto.setStatus(d.getStatus());
        dto.setResolutionNotes(d.getResolutionNotes());
        if (d.getResolvedByAdmin() != null) {
            dto.setResolvedByAdminName(d.getResolvedByAdmin().getFullName());
        }
        dto.setCreatedAt(d.getCreatedAt());
        dto.setResolvedAt(d.getResolvedAt());
        return dto;
    }
}

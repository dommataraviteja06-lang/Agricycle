package com.agricycle.service;

import com.agricycle.dto.CreateListingRequest;
import com.agricycle.dto.ListingDto;
import com.agricycle.entity.*;
import com.agricycle.exception.ForbiddenException;
import com.agricycle.exception.ResourceNotFoundException;
import com.agricycle.repository.*;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class ListingService {

    private final ListingRepository listingRepository;
    private final UserRepository userRepository;
    private final HarvestRepository harvestRepository;
    private final CategoryRepository categoryRepository;
    private final ReviewRepository reviewRepository;
    private final AuditService auditService;

    // Approximate district coordinates for Telangana and Andhra Pradesh
    private static final Map<String, double[]> DISTRICT_COORDINATES = new HashMap<>();
    static {
        DISTRICT_COORDINATES.put("nalgonda", new double[]{17.0575, 79.2684});
        DISTRICT_COORDINATES.put("karimnagar", new double[]{18.4386, 79.1288});
        DISTRICT_COORDINATES.put("warangal", new double[]{17.9689, 79.5941});
        DISTRICT_COORDINATES.put("khammam", new double[]{17.2473, 80.1514});
        DISTRICT_COORDINATES.put("nizamabad", new double[]{18.6725, 78.0941});
        DISTRICT_COORDINATES.put("hyderabad", new double[]{17.3850, 78.4867});
        DISTRICT_COORDINATES.put("rangareddy", new double[]{17.4375, 78.4482});
        DISTRICT_COORDINATES.put("medak", new double[]{18.0478, 78.2619});
        DISTRICT_COORDINATES.put("suryapet", new double[]{17.1439, 79.6239});
        DISTRICT_COORDINATES.put("guntur", new double[]{16.3067, 80.4365});
        DISTRICT_COORDINATES.put("krishna", new double[]{16.1809, 81.1303});
        DISTRICT_COORDINATES.put("vijayawada", new double[]{16.5062, 80.6480});
        DISTRICT_COORDINATES.put("kurnool", new double[]{15.8281, 78.0373});
        DISTRICT_COORDINATES.put("west godavari", new double[]{16.7107, 81.0952});
    }

    public ListingService(ListingRepository listingRepository,
                          UserRepository userRepository,
                          HarvestRepository harvestRepository,
                          CategoryRepository categoryRepository,
                          ReviewRepository reviewRepository,
                          AuditService auditService) {
        this.listingRepository = listingRepository;
        this.userRepository = userRepository;
        this.harvestRepository = harvestRepository;
        this.categoryRepository = categoryRepository;
        this.reviewRepository = reviewRepository;
        this.auditService = auditService;
    }

    @Transactional
    public ListingDto createListing(CreateListingRequest req, Long sellerUserId, String clientIp) {
        User seller = userRepository.findById(sellerUserId)
                .orElseThrow(() -> new ResourceNotFoundException("Seller not found"));

        Category category = categoryRepository.findById(req.getCategoryId())
                .orElseThrow(() -> new ResourceNotFoundException("Category not found with id: " + req.getCategoryId()));

        Harvest harvest = null;
        if (req.getHarvestId() != null) {
            harvest = harvestRepository.findById(req.getHarvestId())
                    .orElseThrow(() -> new ResourceNotFoundException("Harvest not found with id: " + req.getHarvestId()));
            if (!harvest.getFarmer().getId().equals(sellerUserId)) {
                throw new ForbiddenException("Cannot create a listing for another farmer's harvest.");
            }
        }

        Listing listing = new Listing();
        listing.setSeller(seller);
        listing.setHarvest(harvest);
        listing.setCategory(category);
        listing.setTitle(req.getTitle().trim());
        listing.setProductMaterialName(req.getProductMaterialName().trim());
        listing.setQuantity(req.getQuantity());
        listing.setAvailableQuantity(req.getQuantity());
        listing.setUnit(req.getUnit());
        listing.setPricePerUnit(req.getPricePerUnit());
        listing.setVillage(req.getVillage());
        listing.setDistrict(req.getDistrict());
        listing.setState(req.getState());
        listing.setDescription(req.getDescription());
        listing.setSuitableUse(req.getSuitableUse());
        listing.setImagesJson(req.getImagesJson());

        // Geolocation fallback
        if (req.getLatitude() != null && req.getLongitude() != null) {
            listing.setLatitude(req.getLatitude());
            listing.setLongitude(req.getLongitude());
        } else {
            String distKey = req.getDistrict().trim().toLowerCase();
            if (DISTRICT_COORDINATES.containsKey(distKey)) {
                double[] coords = DISTRICT_COORDINATES.get(distKey);
                listing.setLatitude(coords[0]);
                listing.setLongitude(coords[1]);
            } else {
                listing.setLatitude(17.3850);
                listing.setLongitude(78.4867);
            }
        }

        listing.setListingStatus(ListingStatus.APPROVED);
        listing.setVerificationStatus(VerificationStatus.VERIFIED);

        listing = listingRepository.save(listing);

        // Generate unique Digital Lot ID: AGC-<CROP/MAT>-<ST>-<YEAR>-<ID_PADDED>
        String code = req.getProductMaterialName().replaceAll("[^a-zA-Z]", "").toUpperCase();
        if (code.length() > 4) code = code.substring(0, 4);
        if (code.isEmpty()) code = "AGRI";

        String stateCode = "TG";
        if (req.getState().equalsIgnoreCase("Andhra Pradesh")) stateCode = "AP";

        int year = LocalDateTime.now().getYear();
        String lotId = String.format("AGC-%s-%s-%d-%06d", code, stateCode, year, listing.getId());
        listing.setLotId(lotId);
        listing = listingRepository.save(listing);

        auditService.log(seller.getId(), seller.getEmail(), "LISTING_CREATED", "Listing", listing.getId(),
                "Listing created: " + listing.getTitle() + " [Lot ID: " + lotId + "]", clientIp, "SUCCESS");

        return mapToDto(listing);
    }

    @Transactional(readOnly = true)
    public Page<ListingDto> searchMarketplace(String keyword, Long categoryId, CategoryType categoryType,
                                              String district, String state, Double minPrice, Double maxPrice,
                                              Double minQty, String sortBy, int page, int size) {
        Sort sort;
        if ("lowest_price".equalsIgnoreCase(sortBy)) {
            sort = Sort.by(Sort.Direction.ASC, "pricePerUnit");
        } else if ("highest_quantity".equalsIgnoreCase(sortBy)) {
            sort = Sort.by(Sort.Direction.DESC, "availableQuantity");
        } else {
            sort = Sort.by(Sort.Direction.DESC, "createdAt");
        }

        Pageable pageable = PageRequest.of(page, size, sort);
        Page<Listing> listingPage = listingRepository.searchListings(
                ListingStatus.APPROVED, categoryId, categoryType, district, state, minPrice, maxPrice, minQty, keyword, pageable
        );

        return listingPage.map(this::mapToDto);
    }

    @Transactional(readOnly = true)
    public Page<ListingDto> searchFodder(String district, Double minQty, String keyword, int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "createdAt"));
        return listingRepository.searchFodderListings(district, minQty, keyword, pageable).map(this::mapToDto);
    }

    @Transactional(readOnly = true)
    public Page<ListingDto> searchResidue(String district, String keyword, int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "createdAt"));
        return listingRepository.searchResidueListings(district, keyword, pageable).map(this::mapToDto);
    }

    @Transactional
    public ListingDto getListingDetails(Long listingId) {
        Listing listing = listingRepository.findById(listingId)
                .orElseThrow(() -> new ResourceNotFoundException("Listing not found with id: " + listingId));

        listing.setViewCount(listing.getViewCount() + 1);
        listingRepository.save(listing);

        return mapToDto(listing);
    }

    @Transactional(readOnly = true)
    public ListingDto getListingByLotId(String lotId) {
        Listing listing = listingRepository.findByLotId(lotId.trim())
                .orElseThrow(() -> new ResourceNotFoundException("Listing not found with Digital Lot ID: " + lotId));
        return mapToDto(listing);
    }

    @Transactional(readOnly = true)
    public List<ListingDto> getSellerListings(Long sellerUserId) {
        return listingRepository.findBySellerIdOrderByCreatedAtDesc(sellerUserId)
                .stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<ListingDto> getHarvestListings(Long harvestId) {
        return listingRepository.findByHarvestId(harvestId)
                .stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Transactional
    public void deleteListing(Long listingId, Long currentUserId, String clientIp) {
        Listing listing = listingRepository.findById(listingId)
                .orElseThrow(() -> new ResourceNotFoundException("Listing not found with id: " + listingId));

        if (!listing.getSeller().getId().equals(currentUserId)) {
            throw new ForbiddenException("You cannot delete another user's listing.");
        }

        listingRepository.delete(listing);
        auditService.log(currentUserId, listing.getSeller().getEmail(), "LISTING_DELETED", "Listing", listingId,
                "Seller deleted listing ID: " + listingId, clientIp, "SUCCESS");
    }

    @Transactional
    public ListingDto updateStatusByAdmin(Long listingId, ListingStatus newStatus, Long adminId, String clientIp) {
        Listing listing = listingRepository.findById(listingId)
                .orElseThrow(() -> new ResourceNotFoundException("Listing not found with id: " + listingId));

        listing.setListingStatus(newStatus);
        listing = listingRepository.save(listing);

        auditService.log(adminId, "admin", "ADMIN_LISTING_STATUS_CHANGE", "Listing", listingId,
                "Listing status changed to: " + newStatus, clientIp, "SUCCESS");

        return mapToDto(listing);
    }

    public ListingDto mapToDto(Listing l) {
        ListingDto dto = new ListingDto();
        dto.setId(l.getId());
        dto.setSellerId(l.getSeller().getId());
        dto.setSellerName(l.getSeller().getFullName());
        dto.setSellerVerificationStatus(l.getVerificationStatus());

        Double avgRating = reviewRepository.getAverageRatingForUser(l.getSeller().getId());
        dto.setSellerRating(avgRating != null ? Math.round(avgRating * 10.0) / 10.0 : 4.8);
        dto.setSellerReviewsCount(reviewRepository.countReviewsForUser(l.getSeller().getId()));

        if (l.getHarvest() != null) {
            dto.setHarvestId(l.getHarvest().getId());
            dto.setHarvestCropName(l.getHarvest().getCropName());
            dto.setHarvestDate(l.getHarvest().getHarvestDate());
        }

        if (l.getCategory() != null) {
            dto.setCategoryId(l.getCategory().getId());
            dto.setCategoryName(l.getCategory().getName());
            dto.setCategoryType(l.getCategory().getCategoryType());
        }

        dto.setTitle(l.getTitle());
        dto.setProductMaterialName(l.getProductMaterialName());
        dto.setQuantity(l.getQuantity());
        dto.setAvailableQuantity(l.getAvailableQuantity());
        dto.setUnit(l.getUnit());
        dto.setPricePerUnit(l.getPricePerUnit());
        dto.setVillage(l.getVillage());
        dto.setDistrict(l.getDistrict());
        dto.setState(l.getState());
        dto.setLatitude(l.getLatitude());
        dto.setLongitude(l.getLongitude());
        dto.setLotId(l.getLotId());
        dto.setImagesJson(l.getImagesJson());
        dto.setDescription(l.getDescription());
        dto.setSuitableUse(l.getSuitableUse());
        dto.setListingStatus(l.getListingStatus());
        dto.setVerificationStatus(l.getVerificationStatus());
        dto.setViewCount(l.getViewCount());
        dto.setCreatedAt(l.getCreatedAt());
        return dto;
    }
}

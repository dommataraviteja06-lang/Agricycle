package com.agricycle.service;

import com.agricycle.dto.CreateReviewRequest;
import com.agricycle.dto.ReviewDto;
import com.agricycle.entity.*;
import com.agricycle.exception.BadRequestException;
import com.agricycle.exception.ForbiddenException;
import com.agricycle.exception.ResourceNotFoundException;
import com.agricycle.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ReviewService {

    private final ReviewRepository reviewRepository;
    private final OrderRepository orderRepository;
    private final UserRepository userRepository;
    private final AuditService auditService;

    public ReviewService(ReviewRepository reviewRepository,
                         OrderRepository orderRepository,
                         UserRepository userRepository,
                         AuditService auditService) {
        this.reviewRepository = reviewRepository;
        this.orderRepository = orderRepository;
        this.userRepository = userRepository;
        this.auditService = auditService;
    }

    @Transactional
    public ReviewDto createReview(CreateReviewRequest req, Long reviewerUserId, String clientIp) {
        Order order = orderRepository.findById(req.getOrderId())
                .orElseThrow(() -> new ResourceNotFoundException("Order not found"));

        if (order.getStatus() != OrderStatus.COMPLETED && order.getStatus() != OrderStatus.DELIVERED) {
            throw new BadRequestException("Reviews can only be submitted for delivered or completed orders.");
        }

        User reviewer = userRepository.findById(reviewerUserId)
                .orElseThrow(() -> new ResourceNotFoundException("Reviewer not found"));

        User targetUser = userRepository.findById(req.getTargetUserId())
                .orElseThrow(() -> new ResourceNotFoundException("Target user not found"));

        if (reviewerUserId.equals(req.getTargetUserId())) {
            throw new BadRequestException("You cannot rate yourself.");
        }

        // Prevent duplicate review for same order & review type
        if (reviewRepository.existsByOrderIdAndReviewerIdAndReviewType(order.getId(), reviewerUserId, req.getReviewType())) {
            throw new BadRequestException("You have already submitted a review for this order.");
        }

        Review review = new Review();
        review.setOrder(order);
        review.setReviewer(reviewer);
        review.setTargetUser(targetUser);
        review.setReviewType(req.getReviewType());
        review.setRating(req.getRating());
        review.setComment(req.getComment());
        review.setReported(false);

        review = reviewRepository.save(review);

        auditService.log(reviewerUserId, reviewer.getEmail(), "REVIEW_SUBMITTED", "Review", review.getId(),
                "Rated user #" + targetUser.getId() + " with " + review.getRating() + " stars", clientIp, "SUCCESS");

        return mapToDto(review);
    }

    @Transactional(readOnly = true)
    public List<ReviewDto> getUserReviews(Long targetUserId) {
        return reviewRepository.findByTargetUserIdOrderByCreatedAtDesc(targetUserId)
                .stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Transactional
    public void reportReview(Long reviewId, String reason, Long currentUserId, String clientIp) {
        Review review = reviewRepository.findById(reviewId)
                .orElseThrow(() -> new ResourceNotFoundException("Review not found"));
        review.setReported(true);
        review.setReportReason(reason);
        reviewRepository.save(review);

        auditService.log(currentUserId, "user", "REVIEW_REPORTED", "Review", reviewId,
                "Reported review ID: " + reviewId + " Reason: " + reason, clientIp, "SUCCESS");
    }

    @Transactional(readOnly = true)
    public List<ReviewDto> getReportedReviewsForAdmin() {
        return reviewRepository.findByReportedTrue()
                .stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Transactional
    public void deleteReviewByAdmin(Long reviewId, Long adminId, String clientIp) {
        Review review = reviewRepository.findById(reviewId)
                .orElseThrow(() -> new ResourceNotFoundException("Review not found"));
        reviewRepository.delete(review);

        auditService.log(adminId, "admin", "ADMIN_DELETED_REVIEW", "Review", reviewId,
                "Moderated and deleted abusive review ID: " + reviewId, clientIp, "SUCCESS");
    }

    public ReviewDto mapToDto(Review r) {
        ReviewDto dto = new ReviewDto();
        dto.setId(r.getId());
        dto.setOrderId(r.getOrder().getId());
        dto.setReviewerId(r.getReviewer().getId());
        dto.setReviewerName(r.getReviewer().getFullName());
        dto.setTargetUserId(r.getTargetUser().getId());
        dto.setTargetUserName(r.getTargetUser().getFullName());
        dto.setReviewType(r.getReviewType());
        dto.setRating(r.getRating());
        dto.setComment(r.getComment());
        dto.setReported(r.isReported());
        dto.setCreatedAt(r.getCreatedAt());
        return dto;
    }
}

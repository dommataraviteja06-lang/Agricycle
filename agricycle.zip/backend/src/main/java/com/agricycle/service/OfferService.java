package com.agricycle.service;

import com.agricycle.dto.CreateOfferRequest;
import com.agricycle.dto.OrderDto;
import com.agricycle.dto.RequirementOfferDto;
import com.agricycle.entity.*;
import com.agricycle.exception.BadRequestException;
import com.agricycle.exception.ForbiddenException;
import com.agricycle.exception.ResourceNotFoundException;
import com.agricycle.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class OfferService {

    private final RequirementOfferRepository offerRepository;
    private final RequirementRepository requirementRepository;
    private final UserRepository userRepository;
    private final OrderRepository orderRepository;
    private final OrderItemRepository orderItemRepository;
    private final NotificationService notificationService;
    private final AuditService auditService;

    public OfferService(RequirementOfferRepository offerRepository,
                        RequirementRepository requirementRepository,
                        UserRepository userRepository,
                        OrderRepository orderRepository,
                        OrderItemRepository orderItemRepository,
                        NotificationService notificationService,
                        AuditService auditService) {
        this.offerRepository = offerRepository;
        this.requirementRepository = requirementRepository;
        this.userRepository = userRepository;
        this.orderRepository = orderRepository;
        this.orderItemRepository = orderItemRepository;
        this.notificationService = notificationService;
        this.auditService = auditService;
    }

    @Transactional
    public RequirementOfferDto submitOffer(CreateOfferRequest req, Long supplierUserId, String clientIp) {
        User supplier = userRepository.findById(supplierUserId)
                .orElseThrow(() -> new ResourceNotFoundException("Supplier not found"));

        Requirement requirement = requirementRepository.findById(req.getRequirementId())
                .orElseThrow(() -> new ResourceNotFoundException("Requirement not found with id: " + req.getRequirementId()));

        if (requirement.getStatus() == RequirementStatus.CLOSED || requirement.getStatus() == RequirementStatus.FULFILLED) {
            throw new BadRequestException("This requirement is already closed or fulfilled.");
        }

        RequirementOffer offer = new RequirementOffer();
        offer.setRequirement(requirement);
        offer.setSupplier(supplier);
        offer.setOfferedQuantity(req.getOfferedQuantity());
        offer.setPricePerUnit(req.getPricePerUnit());
        offer.setProposedDeliveryDate(req.getProposedDeliveryDate());
        offer.setNotes(req.getNotes());
        offer.setStatus(RequirementOffer.OfferStatus.SUBMITTED);

        offer = offerRepository.save(offer);

        // Notify requirement owner
        notificationService.sendNotification(
                requirement.getUser(),
                "New Supplier Offer Received",
                String.format("%s submitted an offer of %.1f %s at ₹%.2f/%s for %s",
                        supplier.getFullName(), offer.getOfferedQuantity(), requirement.getUnit(),
                        offer.getPricePerUnit(), requirement.getUnit(), requirement.getMaterialName()),
                NotificationType.REQUIREMENT,
                requirement.getId()
        );

        auditService.log(supplier.getId(), supplier.getEmail(), "OFFER_SUBMITTED", "RequirementOffer", offer.getId(),
                "Offer of " + offer.getOfferedQuantity() + " " + requirement.getUnit() + " at ₹" + offer.getPricePerUnit() + " submitted", clientIp, "SUCCESS");

        return mapToDto(offer);
    }

    @Transactional(readOnly = true)
    public List<RequirementOfferDto> getOffersForRequirement(Long requirementId, Long currentUserId) {
        Requirement requirement = requirementRepository.findById(requirementId)
                .orElseThrow(() -> new ResourceNotFoundException("Requirement not found"));

        return offerRepository.findByRequirement_Id(requirementId)
                .stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<RequirementOfferDto> getSupplierOffers(Long supplierUserId) {
        return offerRepository.findBySupplier_IdOrderByCreatedAtDesc(supplierUserId)
                .stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    /**
     * Accept single or multiple supplier offers to fulfill bulk requirement.
     * Specification Item 29: Aggregated supply structure (e.g. Farmer A 2T + Farmer B 3T + Farmer C 5T = 10T).
     */
    @Transactional
    public List<String> acceptOffersAndCreateOrders(Long requirementId, List<Long> offerIds, Long companyUserId, String clientIp) {
        Requirement requirement = requirementRepository.findById(requirementId)
                .orElseThrow(() -> new ResourceNotFoundException("Requirement not found"));

        if (!requirement.getUser().getId().equals(companyUserId)) {
            throw new ForbiddenException("Only the requirement creator can accept offers.");
        }

        List<String> createdOrderNumbers = new ArrayList<>();
        double newlyFulfilled = 0.0;

        for (Long offerId : offerIds) {
            RequirementOffer offer = offerRepository.findById(offerId)
                    .orElseThrow(() -> new ResourceNotFoundException("Offer not found with id: " + offerId));

            if (!offer.getRequirement().getId().equals(requirementId)) {
                continue;
            }

            offer.setStatus(RequirementOffer.OfferStatus.ACCEPTED);
            offerRepository.save(offer);

            // Create individual traceable Order for this farmer
            Order order = new Order();
            String orderNum = "ORD-BULK-" + System.currentTimeMillis() % 1000000 + "-" + offer.getId();
            order.setOrderNumber(orderNum);
            order.setBuyer(requirement.getUser());
            order.setSeller(offer.getSupplier());
            order.setRequirement(requirement);
            order.setTotalAmount(offer.getOfferedQuantity() * offer.getPricePerUnit());
            order.setStatus(OrderStatus.CONFIRMED);
            order.setDeliveryAddress(requirement.getDeliveryRequirement() != null ? requirement.getDeliveryRequirement() : requirement.getDistrict() + ", " + requirement.getState());
            order.setDistrict(requirement.getDistrict());
            order.setState(requirement.getState());
            order.setSpecialInstructions("Aggregated Bulk Supply Contribution: " + offer.getOfferedQuantity() + " " + requirement.getUnit());

            order = orderRepository.save(order);

            // Create OrderItem
            OrderItem item = new OrderItem();
            item.setOrder(order);
            item.setMaterialName(requirement.getMaterialName());
            item.setQuantity(offer.getOfferedQuantity());
            item.setUnit(requirement.getUnit());
            item.setPricePerUnit(offer.getPricePerUnit());
            item.setTotalPrice(order.getTotalAmount());
            orderItemRepository.save(item);

            newlyFulfilled += offer.getOfferedQuantity();
            createdOrderNumbers.add(orderNum);

            // Notify farmer
            notificationService.sendNotification(
                    offer.getSupplier(),
                    "🎉 Bulk Offer Accepted!",
                    String.format("Your offer for %s (%.1f %s) has been accepted by %s. Order %s confirmed.",
                            requirement.getMaterialName(), offer.getOfferedQuantity(), requirement.getUnit(),
                            requirement.getUser().getFullName(), orderNum),
                    NotificationType.ORDER,
                    order.getId()
            );
        }

        requirement.setFulfilledQuantity(requirement.getFulfilledQuantity() + newlyFulfilled);
        if (requirement.getFulfilledQuantity() >= requirement.getQuantityRequired()) {
            requirement.setStatus(RequirementStatus.FULFILLED);
        } else {
            requirement.setStatus(RequirementStatus.MATCHED);
        }
        requirementRepository.save(requirement);

        auditService.log(companyUserId, requirement.getUser().getEmail(), "BULK_OFFERS_ACCEPTED", "Requirement", requirementId,
                "Accepted " + offerIds.size() + " supplier offers aggregating " + newlyFulfilled + " " + requirement.getUnit(), clientIp, "SUCCESS");

        return createdOrderNumbers;
    }

    public RequirementOfferDto mapToDto(RequirementOffer o) {
        RequirementOfferDto dto = new RequirementOfferDto();
        dto.setId(o.getId());
        dto.setRequirementId(o.getRequirement().getId());
        dto.setMaterialName(o.getRequirement().getMaterialName());
        dto.setSupplierId(o.getSupplier().getId());
        dto.setSupplierName(o.getSupplier().getFullName());
        dto.setSupplierMobile(o.getSupplier().getMobile());
        dto.setOfferedQuantity(o.getOfferedQuantity());
        dto.setPricePerUnit(o.getPricePerUnit());
        dto.setProposedDeliveryDate(o.getProposedDeliveryDate());
        dto.setNotes(o.getNotes());
        dto.setStatus(o.getStatus());
        dto.setCreatedAt(o.getCreatedAt());
        return dto;
    }
}

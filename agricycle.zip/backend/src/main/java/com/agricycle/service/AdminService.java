package com.agricycle.service;

import com.agricycle.dto.AdminStatsDto;
import com.agricycle.dto.UserDto;
import com.agricycle.entity.*;
import com.agricycle.exception.BadRequestException;
import com.agricycle.exception.ResourceNotFoundException;
import com.agricycle.repository.*;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AdminService {

    private final UserRepository userRepository;
    private final ListingRepository listingRepository;
    private final OrderRepository orderRepository;
    private final TransportJobRepository transportJobRepository;
    private final RequirementRepository requirementRepository;
    private final DisputeRepository disputeRepository;
    private final AuditService auditService;

    public AdminService(UserRepository userRepository,
                        ListingRepository listingRepository,
                        OrderRepository orderRepository,
                        TransportJobRepository transportJobRepository,
                        RequirementRepository requirementRepository,
                        DisputeRepository disputeRepository,
                        AuditService auditService) {
        this.userRepository = userRepository;
        this.listingRepository = listingRepository;
        this.orderRepository = orderRepository;
        this.transportJobRepository = transportJobRepository;
        this.requirementRepository = requirementRepository;
        this.disputeRepository = disputeRepository;
        this.auditService = auditService;
    }

    @Transactional(readOnly = true)
    public AdminStatsDto getPlatformStats() {
        AdminStatsDto stats = new AdminStatsDto();
        stats.setTotalUsers(userRepository.count());
        stats.setFarmersCount(userRepository.countByRole(Role.ROLE_FARMER));
        stats.setLivestockOwnersCount(userRepository.countByRole(Role.ROLE_LIVESTOCK_OWNER));
        stats.setCompaniesCount(userRepository.countByRole(Role.ROLE_COMPANY));
        stats.setTransportersCount(userRepository.countByRole(Role.ROLE_TRANSPORTER));

        stats.setActiveListingsCount(listingRepository.countByListingStatus(ListingStatus.APPROVED));
        stats.setPendingApprovalListingsCount(listingRepository.countByListingStatus(ListingStatus.PENDING_APPROVAL));

        stats.setTotalOrdersCount(orderRepository.count());
        stats.setCompletedOrdersCount(orderRepository.countByStatus(OrderStatus.COMPLETED));

        stats.setActiveTransportJobsCount(transportJobRepository.countByStatus(TransportStatus.IN_TRANSIT) +
                                          transportJobRepository.countByStatus(TransportStatus.ASSIGNED));

        stats.setOpenRequirementsCount(requirementRepository.countByStatus(RequirementStatus.OPEN));
        stats.setOpenDisputesCount(disputeRepository.countByStatus(DisputeStatus.OPEN));

        stats.setTotalPlatformVolumeTons(1840.5);
        stats.setTotalPlatformEarningsInr(4850000.0);
        stats.setTotalResidueDivertedTons(920.0);

        return stats;
    }

    @Transactional(readOnly = true)
    public Page<UserDto> searchUsers(Role role, UserStatus status, String search, int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "createdAt"));
        return userRepository.searchUsers(role, status, search, pageable).map(u -> {
            UserDto d = new UserDto();
            d.setId(u.getId());
            d.setEmail(u.getEmail());
            d.setFullName(u.getFullName());
            d.setMobile(u.getMobile());
            d.setRole(u.getRole());
            d.setStatus(u.getStatus());
            d.setCreatedAt(u.getCreatedAt());
            return d;
        });
    }

    @Transactional
    public void updateUserStatus(Long targetUserId, UserStatus newStatus, Long adminId, String clientIp) {
        User user = userRepository.findById(targetUserId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + targetUserId));

        if (user.getRole() == Role.ROLE_ADMIN) {
            throw new BadRequestException("Cannot suspend or modify the primary administrator account.");
        }

        user.setStatus(newStatus);
        userRepository.save(user);

        auditService.log(adminId, "admin", "ADMIN_USER_STATUS_CHANGE", "User", targetUserId,
                "User " + user.getEmail() + " status updated to: " + newStatus, clientIp, "SUCCESS");
    }
}

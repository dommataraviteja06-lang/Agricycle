package com.agricycle.service;

import com.agricycle.dto.PaymentDto;
import com.agricycle.dto.ProcessPaymentRequest;
import com.agricycle.entity.*;
import com.agricycle.exception.BadRequestException;
import com.agricycle.exception.ForbiddenException;
import com.agricycle.exception.ResourceNotFoundException;
import com.agricycle.repository.OrderRepository;
import com.agricycle.repository.PaymentRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.UUID;

@Service
public class PaymentService {

    private final PaymentRepository paymentRepository;
    private final OrderRepository orderRepository;
    private final NotificationService notificationService;
    private final AuditService auditService;

    public PaymentService(PaymentRepository paymentRepository,
                          OrderRepository orderRepository,
                          NotificationService notificationService,
                          AuditService auditService) {
        this.paymentRepository = paymentRepository;
        this.orderRepository = orderRepository;
        this.notificationService = notificationService;
        this.auditService = auditService;
    }

    @Transactional
    public PaymentDto processPayment(ProcessPaymentRequest req, Long currentUserId, String clientIp) {
        Order order = orderRepository.findById(req.getOrderId())
                .orElseThrow(() -> new ResourceNotFoundException("Order not found with id: " + req.getOrderId()));

        if (!order.getBuyer().getId().equals(currentUserId)) {
            throw new ForbiddenException("Only the order buyer can authorize payment.");
        }

        Payment payment = paymentRepository.findByOrderId(order.getId())
                .orElseGet(() -> {
                    Payment p = new Payment();
                    p.setOrder(order);
                    p.setAmount(order.getTotalAmount());
                    return p;
                });

        if (payment.getStatus() == PaymentStatus.PAID) {
            throw new BadRequestException("This order is already paid.");
        }

        String txRef = "TXN-AGC-" + System.currentTimeMillis() + "-" + UUID.randomUUID().toString().substring(0, 6).toUpperCase();
        payment.setTransactionReference(txRef);
        payment.setPaymentMethod(req.getPaymentMethod() != null ? req.getPaymentMethod() : "ESCROW_TRANSFER");
        payment.setStatus(PaymentStatus.PAID);
        payment.setPaidAt(LocalDateTime.now());
        payment.setAmount(order.getTotalAmount());

        payment = paymentRepository.save(payment);

        // Notify seller and buyer
        notificationService.sendNotification(
                order.getSeller(),
                "💰 Payment Escrow Secured!",
                String.format("Payment of ₹%.2f secured in escrow for Order #%s [Ref: %s]",
                        order.getTotalAmount(), order.getOrderNumber(), txRef),
                NotificationType.ORDER,
                order.getId()
        );

        auditService.log(currentUserId, order.getBuyer().getEmail(), "PAYMENT_PROCESSED", "Payment", payment.getId(),
                "Escrow payment ₹" + payment.getAmount() + " processed with ref: " + txRef, clientIp, "SUCCESS");

        return mapToDto(payment);
    }

    @Transactional(readOnly = true)
    public PaymentDto getPaymentByOrderId(Long orderId, Long currentUserId) {
        Payment payment = paymentRepository.findByOrderId(orderId)
                .orElseThrow(() -> new ResourceNotFoundException("Payment record not found for order: " + orderId));
        return mapToDto(payment);
    }

    public PaymentDto mapToDto(Payment p) {
        PaymentDto dto = new PaymentDto();
        dto.setId(p.getId());
        dto.setOrderId(p.getOrder().getId());
        dto.setTransactionReference(p.getTransactionReference());
        dto.setAmount(p.getAmount());
        dto.setStatus(p.getStatus());
        dto.setPaymentMethod(p.getPaymentMethod());
        dto.setPaidAt(p.getPaidAt());
        dto.setFailureReason(p.getFailureReason());
        dto.setCreatedAt(p.getCreatedAt());
        return dto;
    }
}

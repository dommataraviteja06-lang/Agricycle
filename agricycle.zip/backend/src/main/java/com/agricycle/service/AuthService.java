package com.agricycle.service;

import com.agricycle.dto.*;
import com.agricycle.entity.*;
import com.agricycle.exception.BadRequestException;
import com.agricycle.exception.UnauthorizedException;
import com.agricycle.repository.*;
import com.agricycle.security.JwtUtils;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
public class AuthService {

    private final UserRepository userRepository;
    private final FarmerProfileRepository farmerProfileRepository;
    private final LivestockProfileRepository livestockProfileRepository;
    private final CompanyProfileRepository companyProfileRepository;
    private final TransportProfileRepository transportProfileRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtils jwtUtils;
    private final AuditService auditService;

    public AuthService(UserRepository userRepository,
                       FarmerProfileRepository farmerProfileRepository,
                       LivestockProfileRepository livestockProfileRepository,
                       CompanyProfileRepository companyProfileRepository,
                       TransportProfileRepository transportProfileRepository,
                       PasswordEncoder passwordEncoder,
                       JwtUtils jwtUtils,
                       AuditService auditService) {
        this.userRepository = userRepository;
        this.farmerProfileRepository = farmerProfileRepository;
        this.livestockProfileRepository = livestockProfileRepository;
        this.companyProfileRepository = companyProfileRepository;
        this.transportProfileRepository = transportProfileRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtUtils = jwtUtils;
        this.auditService = auditService;
    }

    @Transactional
    public AuthResponse register(RegisterRequest req, String clientIp) {
        // Enforce Super Admin restriction
        if (req.getRole() == Role.ROLE_ADMIN) {
            auditService.log(null, req.getEmail(), "SECURITY_ALERT_ILLEGAL_ADMIN_REGISTRATION", "User", null,
                    "Attempted to register with ROLE_ADMIN from IP: " + clientIp, clientIp, "BLOCKED");
            throw new BadRequestException("Registration for administrator role is strictly forbidden through this endpoint.");
        }

        if (userRepository.existsByEmail(req.getEmail())) {
            throw new BadRequestException("An account with this email already exists.");
        }

        User user = new User();
        user.setEmail(req.getEmail().trim().toLowerCase());
        user.setPassword(passwordEncoder.encode(req.getPassword()));
        user.setFullName(req.getFullName().trim());
        user.setMobile(req.getMobile() != null ? req.getMobile().trim() : null);
        user.setRole(req.getRole());
        user.setStatus(UserStatus.ACTIVE);

        user = userRepository.save(user);

        // Create role-specific profile
        Object profileObj = null;
        if (req.getRole() == Role.ROLE_FARMER) {
            FarmerProfile profile = new FarmerProfile();
            profile.setUser(user);
            profile.setVillage(req.getVillage());
            profile.setDistrict(req.getDistrict() != null ? req.getDistrict() : "Nalgonda");
            profile.setState(req.getState() != null ? req.getState() : "Telangana");
            profile.setFarmSizeAcres(req.getFarmSizeAcres() != null ? req.getFarmSizeAcres() : 5.0);
            profile.setMainCrops(req.getMainCrops() != null ? req.getMainCrops() : "Rice, Maize");
            profile.setVerificationStatus(VerificationStatus.VERIFIED);
            profileObj = farmerProfileRepository.save(profile);
        } else if (req.getRole() == Role.ROLE_LIVESTOCK_OWNER) {
            LivestockProfile profile = new LivestockProfile();
            profile.setUser(user);
            profile.setAnimalType(req.getAnimalType() != null ? req.getAnimalType() : "Cattle & Buffalo");
            profile.setNumberOfAnimals(req.getNumberOfAnimals() != null ? req.getNumberOfAnimals() : 10);
            profile.setFeedPreference(req.getFeedPreference() != null ? req.getFeedPreference() : "Dry Fodder");
            profile.setVillage(req.getVillage());
            profile.setDistrict(req.getDistrict() != null ? req.getDistrict() : "Karimnagar");
            profile.setState(req.getState() != null ? req.getState() : "Telangana");
            profile.setVerificationStatus(VerificationStatus.VERIFIED);
            profileObj = livestockProfileRepository.save(profile);
        } else if (req.getRole() == Role.ROLE_COMPANY) {
            CompanyProfile profile = new CompanyProfile();
            profile.setUser(user);
            profile.setCompanyName(req.getCompanyName() != null ? req.getCompanyName() : req.getFullName() + " Biomass Industries");
            profile.setIndustryType(req.getIndustryType() != null ? req.getIndustryType() : "Biomass Energy");
            profile.setGstNumber(req.getGstNumber());
            profile.setDistrict(req.getDistrict() != null ? req.getDistrict() : "Hyderabad");
            profile.setState(req.getState() != null ? req.getState() : "Telangana");
            profile.setVerificationStatus(VerificationStatus.VERIFIED);
            profileObj = companyProfileRepository.save(profile);
        } else if (req.getRole() == Role.ROLE_TRANSPORTER) {
            TransportProfile profile = new TransportProfile();
            profile.setUser(user);
            profile.setVehicleNumber(req.getVehicleNumber() != null ? req.getVehicleNumber() : "TS09-TR-1024");
            profile.setVehicleType(req.getVehicleType() != null ? req.getVehicleType() : "7-Ton Heavy Truck");
            profile.setCapacityTons(req.getCapacityTons() != null ? req.getCapacityTons() : 7.0);
            profile.setServiceArea(req.getDistrict() != null ? req.getDistrict() : "Telangana State");
            profile.setVerificationStatus(VerificationStatus.VERIFIED);
            profileObj = transportProfileRepository.save(profile);
        }

        auditService.log(user.getId(), user.getEmail(), "USER_REGISTERED", "User", user.getId(),
                "Registered with role: " + user.getRole(), clientIp, "SUCCESS");

        String accessToken = jwtUtils.generateAccessToken(user.getEmail(), user.getRole().name(), user.getId());
        String refreshToken = jwtUtils.generateRefreshToken(user.getEmail());

        return new AuthResponse(accessToken, refreshToken, user.getId(), user.getEmail(), user.getFullName(), user.getRole(), user.getStatus(), profileObj);
    }

    @Transactional
    public AuthResponse login(LoginRequest req, String clientIp) {
        String email = req.getEmail().trim().toLowerCase();
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> {
                    auditService.log(null, email, "LOGIN_FAILED", "User", null, "Unknown email attempt", clientIp, "FAILURE");
                    return new UnauthorizedException("Invalid email or password");
                });

        // Check account lock
        if (user.getLockUntil() != null && user.getLockUntil().isAfter(LocalDateTime.now())) {
            auditService.log(user.getId(), email, "LOGIN_BLOCKED_ACCOUNT_LOCKED", "User", user.getId(),
                    "Account locked until: " + user.getLockUntil(), clientIp, "BLOCKED");
            throw new BadRequestException("Account temporarily locked due to multiple failed attempts. Please try again later.");
        }

        if (user.getStatus() == UserStatus.SUSPENDED) {
            auditService.log(user.getId(), email, "LOGIN_REJECTED_SUSPENDED", "User", user.getId(),
                    "Suspended user attempted login", clientIp, "BLOCKED");
            throw new UnauthorizedException("Your account has been suspended by the platform administrator. Contact support.");
        }

        if (!passwordEncoder.matches(req.getPassword(), user.getPassword())) {
            user.setFailedLoginAttempts(user.getFailedLoginAttempts() + 1);
            if (user.getFailedLoginAttempts() >= 5) {
                user.setLockUntil(LocalDateTime.now().plusMinutes(15));
                auditService.log(user.getId(), email, "ACCOUNT_LOCKED_FAILED_ATTEMPTS", "User", user.getId(),
                        "Locked for 15 mins after 5 failed attempts", clientIp, "BLOCKED");
            }
            userRepository.save(user);
            auditService.log(user.getId(), email, "LOGIN_FAILED_BAD_PASSWORD", "User", user.getId(),
                    "Incorrect password", clientIp, "FAILURE");
            throw new UnauthorizedException("Invalid email or password");
        }

        // Reset failed login attempts on successful login
        user.setFailedLoginAttempts(0);
        user.setLockUntil(null);
        userRepository.save(user);

        auditService.log(user.getId(), user.getEmail(), "USER_LOGIN_SUCCESS", "User", user.getId(),
                "Successful login", clientIp, "SUCCESS");

        String accessToken = jwtUtils.generateAccessToken(user.getEmail(), user.getRole().name(), user.getId());
        String refreshToken = jwtUtils.generateRefreshToken(user.getEmail());

        Object profile = getProfileForUser(user);

        return new AuthResponse(accessToken, refreshToken, user.getId(), user.getEmail(), user.getFullName(), user.getRole(), user.getStatus(), profile);
    }

    public AuthResponse refreshToken(RefreshTokenRequest req) {
        String token = req.getRefreshToken();
        if (!jwtUtils.validateToken(token)) {
            throw new UnauthorizedException("Invalid or expired refresh token");
        }

        String email = jwtUtils.getEmailFromToken(token);
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new UnauthorizedException("User not found"));

        if (user.getStatus() == UserStatus.SUSPENDED) {
            throw new UnauthorizedException("Account is suspended");
        }

        String newAccessToken = jwtUtils.generateAccessToken(user.getEmail(), user.getRole().name(), user.getId());
        String newRefreshToken = jwtUtils.generateRefreshToken(user.getEmail());

        return new AuthResponse(newAccessToken, newRefreshToken, user.getId(), user.getEmail(), user.getFullName(), user.getRole(), user.getStatus(), getProfileForUser(user));
    }

    @Transactional
    public void resetPassword(PasswordResetRequest req, String clientIp) {
        User user = userRepository.findByEmail(req.getEmail().trim().toLowerCase())
                .orElseThrow(() -> new BadRequestException("If the email exists, password reset has been processed."));

        user.setPassword(passwordEncoder.encode(req.getNewPassword()));
        user.setFailedLoginAttempts(0);
        user.setLockUntil(null);
        userRepository.save(user);

        auditService.log(user.getId(), user.getEmail(), "PASSWORD_RESET_SUCCESS", "User", user.getId(),
                "Password updated", clientIp, "SUCCESS");
    }

    public Object getProfileForUser(User user) {
        switch (user.getRole()) {
            case ROLE_FARMER:
                return farmerProfileRepository.findByUser_Id(user.getId()).orElse(null);
            case ROLE_LIVESTOCK_OWNER:
                return livestockProfileRepository.findByUser_Id(user.getId()).orElse(null);
            case ROLE_COMPANY:
                return companyProfileRepository.findByUser_Id(user.getId()).orElse(null);
            case ROLE_TRANSPORTER:
                return transportProfileRepository.findByUser_Id(user.getId()).orElse(null);
            default:
                return null;
        }
    }
}

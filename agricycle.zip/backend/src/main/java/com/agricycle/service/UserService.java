package com.agricycle.service;

import com.agricycle.dto.*;
import com.agricycle.entity.*;
import com.agricycle.exception.ResourceNotFoundException;
import com.agricycle.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class UserService {

    private final UserRepository userRepository;
    private final FarmerProfileRepository farmerProfileRepository;
    private final LivestockProfileRepository livestockProfileRepository;
    private final CompanyProfileRepository companyProfileRepository;
    private final TransportProfileRepository transportProfileRepository;
    private final ReviewRepository reviewRepository;

    public UserService(UserRepository userRepository,
                       FarmerProfileRepository farmerProfileRepository,
                       LivestockProfileRepository livestockProfileRepository,
                       CompanyProfileRepository companyProfileRepository,
                       TransportProfileRepository transportProfileRepository,
                       ReviewRepository reviewRepository) {
        this.userRepository = userRepository;
        this.farmerProfileRepository = farmerProfileRepository;
        this.livestockProfileRepository = livestockProfileRepository;
        this.companyProfileRepository = companyProfileRepository;
        this.transportProfileRepository = transportProfileRepository;
        this.reviewRepository = reviewRepository;
    }

    @Transactional(readOnly = true)
    public UserDto getUserSummary(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + userId));

        UserDto dto = new UserDto();
        dto.setId(user.getId());
        dto.setEmail(user.getEmail());
        dto.setFullName(user.getFullName());
        dto.setMobile(user.getMobile());
        dto.setRole(user.getRole());
        dto.setStatus(user.getStatus());
        dto.setCreatedAt(user.getCreatedAt());

        Double avgRating = reviewRepository.getAverageRatingForUser(userId);
        dto.setAverageRating(avgRating != null ? Math.round(avgRating * 10.0) / 10.0 : 5.0);
        dto.setReviewCount(reviewRepository.countReviewsForUser(userId));

        return dto;
    }

    @Transactional(readOnly = true)
    public FarmerProfileDto getFarmerProfile(Long userId) {
        FarmerProfile profile = farmerProfileRepository.findByUser_Id(userId)
                .orElseThrow(() -> new ResourceNotFoundException("Farmer profile not found for user: " + userId));

        FarmerProfileDto dto = new FarmerProfileDto();
        dto.setId(profile.getId());
        dto.setUserId(userId);
        dto.setFullName(profile.getUser().getFullName());
        dto.setMobile(profile.getUser().getMobile());
        dto.setVillage(profile.getVillage());
        dto.setDistrict(profile.getDistrict());
        dto.setState(profile.getState());
        dto.setFarmSizeAcres(profile.getFarmSizeAcres());
        dto.setMainCrops(profile.getMainCrops());
        dto.setPreferredCategories(profile.getPreferredCategories());
        dto.setProfileImage(profile.getProfileImage());
        dto.setVerificationStatus(profile.getVerificationStatus());
        dto.setCreatedAt(profile.getCreatedAt());
        return dto;
    }

    @Transactional(readOnly = true)
    public LivestockProfileDto getLivestockProfile(Long userId) {
        LivestockProfile profile = livestockProfileRepository.findByUser_Id(userId)
                .orElseThrow(() -> new ResourceNotFoundException("Livestock profile not found for user: " + userId));

        LivestockProfileDto dto = new LivestockProfileDto();
        dto.setId(profile.getId());
        dto.setUserId(userId);
        dto.setFullName(profile.getUser().getFullName());
        dto.setMobile(profile.getUser().getMobile());
        dto.setAnimalType(profile.getAnimalType());
        dto.setNumberOfAnimals(profile.getNumberOfAnimals());
        dto.setFeedPreference(profile.getFeedPreference());
        dto.setVillage(profile.getVillage());
        dto.setDistrict(profile.getDistrict());
        dto.setState(profile.getState());
        dto.setRequiredFodderTypes(profile.getRequiredFodderTypes());
        dto.setVerificationStatus(profile.getVerificationStatus());
        dto.setCreatedAt(profile.getCreatedAt());
        return dto;
    }

    @Transactional(readOnly = true)
    public CompanyProfileDto getCompanyProfile(Long userId, boolean isOwnerOrAdmin) {
        CompanyProfile profile = companyProfileRepository.findByUser_Id(userId)
                .orElseThrow(() -> new ResourceNotFoundException("Company profile not found for user: " + userId));

        CompanyProfileDto dto = new CompanyProfileDto();
        dto.setId(profile.getId());
        dto.setUserId(userId);
        dto.setCompanyName(profile.getCompanyName());
        dto.setIndustryType(profile.getIndustryType());
        if (isOwnerOrAdmin) {
            dto.setGstNumberMasked(profile.getGstNumber());
            dto.setAddress(profile.getAddress());
        } else {
            // Mask sensitive identifiers publicly
            dto.setGstNumberMasked(maskGst(profile.getGstNumber()));
            dto.setAddress(profile.getDistrict() + ", " + profile.getState());
        }
        dto.setDistrict(profile.getDistrict());
        dto.setState(profile.getState());
        dto.setContactPerson(profile.getContactPerson());
        dto.setContactPhone(profile.getContactPhone());
        dto.setVerificationStatus(profile.getVerificationStatus());
        dto.setCreatedAt(profile.getCreatedAt());
        return dto;
    }

    @Transactional(readOnly = true)
    public TransportProfileDto getTransportProfile(Long userId) {
        TransportProfile profile = transportProfileRepository.findByUser_Id(userId)
                .orElseThrow(() -> new ResourceNotFoundException("Transport profile not found for user: " + userId));

        TransportProfileDto dto = new TransportProfileDto();
        dto.setId(profile.getId());
        dto.setUserId(userId);
        dto.setTransporterName(profile.getUser().getFullName());
        dto.setMobile(profile.getUser().getMobile());
        dto.setVehicleNumber(profile.getVehicleNumber());
        dto.setVehicleType(profile.getVehicleType());
        dto.setCapacityTons(profile.getCapacityTons());
        dto.setServiceArea(profile.getServiceArea());
        dto.setAvailable(profile.isAvailable());
        dto.setVerificationStatus(profile.getVerificationStatus());
        dto.setCreatedAt(profile.getCreatedAt());
        return dto;
    }

    private String maskGst(String gst) {
        if (gst == null || gst.length() < 6) return "36AA***0001";
        return gst.substring(0, 4) + "****" + gst.substring(gst.length() - 3);
    }
}

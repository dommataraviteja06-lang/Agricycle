package com.agricycle.service;

import com.agricycle.dto.CreateHarvestRequest;
import com.agricycle.dto.HarvestDto;
import com.agricycle.dto.SellableOutputRecommendationDto;
import com.agricycle.entity.*;
import com.agricycle.exception.ForbiddenException;
import com.agricycle.exception.ResourceNotFoundException;
import com.agricycle.repository.CategoryRepository;
import com.agricycle.repository.HarvestRepository;
import com.agricycle.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class HarvestService {

    private final HarvestRepository harvestRepository;
    private final UserRepository userRepository;
    private final CategoryRepository categoryRepository;
    private final AuditService auditService;

    public HarvestService(HarvestRepository harvestRepository,
                          UserRepository userRepository,
                          CategoryRepository categoryRepository,
                          AuditService auditService) {
        this.harvestRepository = harvestRepository;
        this.userRepository = userRepository;
        this.categoryRepository = categoryRepository;
        this.auditService = auditService;
    }

    @Transactional
    public HarvestDto createHarvest(CreateHarvestRequest req, Long farmerUserId, String clientIp) {
        User farmer = userRepository.findById(farmerUserId)
                .orElseThrow(() -> new ResourceNotFoundException("Farmer not found"));

        Harvest harvest = new Harvest();
        harvest.setFarmer(farmer);
        harvest.setCropName(req.getCropName().trim());
        harvest.setCropVariety(req.getCropVariety());
        harvest.setHarvestDate(req.getHarvestDate());
        harvest.setTotalQuantity(req.getTotalQuantity());
        harvest.setUnit(req.getUnit());
        harvest.setVillage(req.getVillage());
        harvest.setDistrict(req.getDistrict());
        harvest.setState(req.getState());
        harvest.setImageUrl(req.getImageUrl());
        harvest.setDescription(req.getDescription());

        harvest = harvestRepository.save(harvest);

        auditService.log(farmer.getId(), farmer.getEmail(), "HARVEST_CREATED", "Harvest", harvest.getId(),
                "Harvest recorded for crop: " + harvest.getCropName() + " (" + harvest.getTotalQuantity() + " " + harvest.getUnit() + ")", clientIp, "SUCCESS");

        return mapToDto(harvest);
    }

    @Transactional(readOnly = true)
    public List<HarvestDto> getFarmerHarvests(Long farmerUserId) {
        return harvestRepository.findByFarmerIdOrderByCreatedAtDesc(farmerUserId)
                .stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public HarvestDto getHarvestById(Long harvestId, Long currentUserId) {
        Harvest harvest = harvestRepository.findById(harvestId)
                .orElseThrow(() -> new ResourceNotFoundException("Harvest not found with id: " + harvestId));

        return mapToDto(harvest);
    }

    @Transactional
    public void deleteHarvest(Long harvestId, Long currentUserId, String clientIp) {
        Harvest harvest = harvestRepository.findById(harvestId)
                .orElseThrow(() -> new ResourceNotFoundException("Harvest not found with id: " + harvestId));

        if (!harvest.getFarmer().getId().equals(currentUserId)) {
            throw new ForbiddenException("You are not authorized to delete another farmer's harvest.");
        }

        harvestRepository.delete(harvest);
        auditService.log(currentUserId, harvest.getFarmer().getEmail(), "HARVEST_DELETED", "Harvest", harvestId,
                "Deleted harvest ID: " + harvestId, clientIp, "SUCCESS");
    }

    public List<SellableOutputRecommendationDto> getRecommendedSellableOutputs(String cropName) {
        List<SellableOutputRecommendationDto> outputs = new ArrayList<>();
        String normalized = cropName != null ? cropName.trim().toLowerCase() : "";

        if (normalized.contains("rice") || normalized.contains("paddy")) {
            outputs.add(new SellableOutputRecommendationDto("Rice Grain (Main Harvest)", null, "Harvest Products", CategoryType.HARVEST_PRODUCT, "Food / Commercial Grain", "Tons", 1.0, 24000.0, "High-grade polished or unpolished paddy grain for mills and retail markets."));
            outputs.add(new SellableOutputRecommendationDto("Rice Straw (Cattle Fodder)", null, "Fodder", CategoryType.FODDER, "Livestock Feed (Cattle / Buffalo)", "Tons", 1.2, 3500.0, "Dry paddy straw bundles ideal for ruminant cattle feeding in dairy clusters."));
            outputs.add(new SellableOutputRecommendationDto("Rice Husk (Biomass & Fuel)", null, "Agricultural Residue", CategoryType.AGRICULTURAL_RESIDUE, "Biomass Energy / Brick Kilns", "Tons", 0.25, 2800.0, "High-calorific bio-residue for industrial boilers, gasifiers, and briquette manufacturing."));
            outputs.add(new SellableOutputRecommendationDto("Rice Bran / Broken Grain", null, "Agricultural Residue", CategoryType.AGRICULTURAL_RESIDUE, "Feed Supplement / Mushroom Beds", "Tons", 0.08, 12000.0, "Rich organic substrate for poultry feed, oil extraction, and mushroom cultivation."));
        } else if (normalized.contains("wheat")) {
            outputs.add(new SellableOutputRecommendationDto("Wheat Grain (Main Harvest)", null, "Harvest Products", CategoryType.HARVEST_PRODUCT, "Food Processing & Flours", "Tons", 1.0, 22500.0, "Grade-A milling wheat for commercial food processors and traders."));
            outputs.add(new SellableOutputRecommendationDto("Wheat Straw / Turi (Golden Fodder)", null, "Fodder", CategoryType.FODDER, "Dairy Cattle Fodder", "Tons", 1.0, 5500.0, "Finely chopped nutritious wheat straw highly sought by dairy farmers."));
            outputs.add(new SellableOutputRecommendationDto("Wheat Husk / Bran", null, "Agricultural Residue", CategoryType.AGRICULTURAL_RESIDUE, "Compost / Mushroom Bedding", "Tons", 0.15, 3200.0, "Bio-packaging raw material and soil enriching organic substrate."));
        } else if (normalized.contains("maize") || normalized.contains("corn")) {
            outputs.add(new SellableOutputRecommendationDto("Maize Grain (Main Harvest)", null, "Harvest Products", CategoryType.HARVEST_PRODUCT, "Starch & Feed Industries", "Tons", 1.0, 21000.0, "Yellow corn grain for poultry feed mills and industrial starch manufacturing."));
            outputs.add(new SellableOutputRecommendationDto("Maize Stalks / Stover (Green / Dry)", null, "Fodder", CategoryType.FODDER, "Livestock Fodder & Silage", "Tons", 1.4, 2800.0, "Palatable green or sun-dried maize stalks for goats, sheep, and cattle."));
            outputs.add(new SellableOutputRecommendationDto("Maize Cob Residue", null, "Agricultural Residue", CategoryType.AGRICULTURAL_RESIDUE, "Biofuel & Biochar", "Tons", 0.3, 2200.0, "Dense biomass residue for charcoal briquettes and metallurgical heating."));
        } else if (normalized.contains("cotton")) {
            outputs.add(new SellableOutputRecommendationDto("Raw Seed Cotton (Main Harvest)", null, "Harvest Products", CategoryType.HARVEST_PRODUCT, "Textile & Ginning Mills", "Quintals", 1.0, 6800.0, "High staple-length cotton for spinning mills."));
            outputs.add(new SellableOutputRecommendationDto("Cotton Stalks / Bio-Residue", null, "Agricultural Residue", CategoryType.AGRICULTURAL_RESIDUE, "Particle Board / Biomass Briquettes", "Tons", 1.8, 2400.0, "Hard woody residue ideal for industrial board production and biomass power stations."));
        } else if (normalized.contains("sugarcane")) {
            outputs.add(new SellableOutputRecommendationDto("Sugarcane Cane (Main Harvest)", null, "Harvest Products", CategoryType.HARVEST_PRODUCT, "Sugar Mills & Jaggery Units", "Tons", 1.0, 3150.0, "Sweet cane for commercial crushing and sugar production."));
            outputs.add(new SellableOutputRecommendationDto("Sugarcane Bagasse", null, "Agricultural Residue", CategoryType.AGRICULTURAL_RESIDUE, "Paper Pulp & Cogeneration Power", "Tons", 0.32, 2600.0, "Fibrous residue for eco-friendly packaging, tableware, and thermal cogeneration."));
            outputs.add(new SellableOutputRecommendationDto("Sugarcane Trash / Leaves", null, "Fodder", CategoryType.FODDER, "Dry Fodder / Soil Mulch", "Tons", 0.15, 1800.0, "High organic mulch and supplemental livestock feed."));
        } else {
            // Generic agricultural crop outputs
            outputs.add(new SellableOutputRecommendationDto(cropName + " (Main Harvest)", null, "Harvest Products", CategoryType.HARVEST_PRODUCT, "Direct Consumption & Wholesale", "Tons", 1.0, 20000.0, "Primary harvest production ready for market."));
            outputs.add(new SellableOutputRecommendationDto(cropName + " Fodder / Stems", null, "Fodder", CategoryType.FODDER, "Animal Feed", "Tons", 0.8, 3000.0, "Foliage and plant stalks suitable for farm animals."));
            outputs.add(new SellableOutputRecommendationDto(cropName + " Crop Residue / Biomass", null, "Agricultural Residue", CategoryType.AGRICULTURAL_RESIDUE, "Biomass Energy / Composting", "Tons", 0.4, 2000.0, "Organic matter for compost or industrial boilers."));
        }

        return outputs;
    }

    public HarvestDto mapToDto(Harvest h) {
        HarvestDto dto = new HarvestDto();
        dto.setId(h.getId());
        dto.setFarmerId(h.getFarmer().getId());
        dto.setFarmerName(h.getFarmer().getFullName());
        dto.setCropName(h.getCropName());
        dto.setCropVariety(h.getCropVariety());
        dto.setHarvestDate(h.getHarvestDate());
        dto.setTotalQuantity(h.getTotalQuantity());
        dto.setUnit(h.getUnit());
        dto.setVillage(h.getVillage());
        dto.setDistrict(h.getDistrict());
        dto.setState(h.getState());
        dto.setImageUrl(h.getImageUrl());
        dto.setDescription(h.getDescription());
        dto.setListingsCount(h.getListings() != null ? h.getListings().size() : 0);
        dto.setCreatedAt(h.getCreatedAt());
        return dto;
    }
}

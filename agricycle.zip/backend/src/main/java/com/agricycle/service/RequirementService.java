package com.agricycle.service;

import com.agricycle.dto.CreateRequirementRequest;
import com.agricycle.dto.RequirementDto;
import com.agricycle.entity.*;
import com.agricycle.exception.ForbiddenException;
import com.agricycle.exception.ResourceNotFoundException;
import com.agricycle.repository.*;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class RequirementService {

    private final RequirementRepository requirementRepository;
    private final UserRepository userRepository;
    private final CategoryRepository categoryRepository;
    private final NotificationService notificationService;
    private final AuditService auditService;

    public RequirementService(RequirementRepository requirementRepository,
                              UserRepository userRepository,
                              CategoryRepository categoryRepository,
                              NotificationService notificationService,
                              AuditService auditService) {
        this.requirementRepository = requirementRepository;
        this.userRepository = userRepository;
        this.categoryRepository = categoryRepository;
        this.notificationService = notificationService;
        this.auditService = auditService;
    }

    @Transactional
    public RequirementDto createRequirement(CreateRequirementRequest req, Long buyerUserId, String clientIp) {
        User buyer = userRepository.findById(buyerUserId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        Category category = null;
        if (req.getCategoryId() != null) {
            category = categoryRepository.findById(req.getCategoryId()).orElse(null);
        }

        Requirement r = new Requirement();
        r.setUser(buyer);
        r.setCategory(category);
        r.setMaterialName(req.getMaterialName().trim());
        r.setQuantityRequired(req.getQuantityRequired());
        r.setFulfilledQuantity(0.0);
        r.setUnit(req.getUnit());
        r.setTargetPrice(req.getTargetPrice());
        r.setVillage(req.getVillage());
        r.setDistrict(req.getDistrict());
        r.setState(req.getState());
        r.setRequiredByDate(req.getRequiredByDate());

        boolean isEmergency = req.getEmergency() != null && req.getEmergency();
        r.setEmergency(isEmergency);
        r.setAnimalType(req.getAnimalType());
        r.setNumberOfAnimals(req.getNumberOfAnimals());
        r.setUrgency(req.getUrgency() != null ? req.getUrgency() : (isEmergency ? UrgencyLevel.HIGH : UrgencyLevel.MEDIUM));
        r.setQualityRequirement(req.getQualityRequirement());
        r.setDescription(req.getDescription());
        r.setDeliveryRequirement(req.getDeliveryRequirement());
        r.setStatus(RequirementStatus.OPEN);

        r = requirementRepository.save(r);

        // If emergency fodder request, notify eligible nearby sellers (farmers in district)
        if (isEmergency) {
            List<User> farmersInDistrict = userRepository.findByRole(Role.ROLE_FARMER);
            for (User farmer : farmersInDistrict) {
                notificationService.sendNotification(
                        farmer,
                        "🚨 Emergency Fodder Alert in " + r.getDistrict(),
                        String.format("Urgent fodder needed for %d %s: %s (%.0f %s required by %s)",
                                r.getNumberOfAnimals() != null ? r.getNumberOfAnimals() : 10,
                                r.getAnimalType() != null ? r.getAnimalType() : "Livestock",
                                r.getMaterialName(),
                                r.getQuantityRequired(),
                                r.getUnit(),
                                r.getDistrict()),
                        NotificationType.EMERGENCY,
                        r.getId()
                );
            }
        }

        auditService.log(buyer.getId(), buyer.getEmail(), "REQUIREMENT_CREATED", "Requirement", r.getId(),
                (isEmergency ? "EMERGENCY FODDER REQUEST" : "COMPANY BULK REQUIREMENT") + ": " + r.getMaterialName() + " (" + r.getQuantityRequired() + " " + r.getUnit() + ")", clientIp, "SUCCESS");

        return mapToDto(r);
    }

    @Transactional(readOnly = true)
    public Page<RequirementDto> searchRequirements(RequirementStatus status, Boolean emergency, UrgencyLevel urgency,
                                                   String district, String keyword, int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "createdAt"));
        return requirementRepository.searchRequirements(status, emergency, urgency, district, keyword, pageable)
                .map(this::mapToDto);
    }

    @Transactional(readOnly = true)
    public List<RequirementDto> getUserRequirements(Long userId) {
        return requirementRepository.findByUser_IdOrderByCreatedAtDesc(userId)
                .stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<RequirementDto> getEmergencyFodderRequests() {
        return requirementRepository.findByEmergencyTrueAndStatusOrderByCreatedAtDesc(RequirementStatus.OPEN)
                .stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public RequirementDto getRequirementDetails(Long id) {
        Requirement r = requirementRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Requirement not found with id: " + id));
        return mapToDto(r);
    }

    @Transactional
    public void closeRequirement(Long id, Long currentUserId, String clientIp) {
        Requirement r = requirementRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Requirement not found with id: " + id));

        if (!r.getUser().getId().equals(currentUserId)) {
            throw new ForbiddenException("Cannot close another user's requirement.");
        }

        r.setStatus(RequirementStatus.CLOSED);
        requirementRepository.save(r);

        auditService.log(currentUserId, r.getUser().getEmail(), "REQUIREMENT_CLOSED", "Requirement", id,
                "Requirement closed by creator", clientIp, "SUCCESS");
    }

    public RequirementDto mapToDto(Requirement r) {
        RequirementDto dto = new RequirementDto();
        dto.setId(r.getId());
        dto.setUserId(r.getUser().getId());
        dto.setUserName(r.getUser().getFullName());
        dto.setUserRole(r.getUser().getRole().name());

        if (r.getCategory() != null) {
            dto.setCategoryId(r.getCategory().getId());
            dto.setCategoryName(r.getCategory().getName());
        }

        dto.setMaterialName(r.getMaterialName());
        dto.setQuantityRequired(r.getQuantityRequired());
        dto.setFulfilledQuantity(r.getFulfilledQuantity());
        dto.setUnit(r.getUnit());
        dto.setTargetPrice(r.getTargetPrice());
        dto.setVillage(r.getVillage());
        dto.setDistrict(r.getDistrict());
        dto.setState(r.getState());
        dto.setRequiredByDate(r.getRequiredByDate());
        dto.setAnimalType(r.getAnimalType());
        dto.setNumberOfAnimals(r.getNumberOfAnimals());
        dto.setEmergency(r.isEmergency());
        dto.setUrgency(r.getUrgency());
        dto.setQualityRequirement(r.getQualityRequirement());
        dto.setDescription(r.getDescription());
        dto.setDeliveryRequirement(r.getDeliveryRequirement());
        dto.setStatus(r.getStatus());
        dto.setOffersCount(r.getOffers() != null ? r.getOffers().size() : 0);
        dto.setCreatedAt(r.getCreatedAt());
        return dto;
    }
}

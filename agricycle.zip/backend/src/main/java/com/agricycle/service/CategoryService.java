package com.agricycle.service;

import com.agricycle.dto.CategoryDto;
import com.agricycle.entity.Category;
import com.agricycle.entity.CategoryType;
import com.agricycle.exception.BadRequestException;
import com.agricycle.exception.ResourceNotFoundException;
import com.agricycle.repository.CategoryRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class CategoryService {

    private final CategoryRepository categoryRepository;

    public CategoryService(CategoryRepository categoryRepository) {
        this.categoryRepository = categoryRepository;
    }

    @Transactional(readOnly = true)
    public List<CategoryDto> getAllActiveCategories() {
        return categoryRepository.findAllByActiveTrueOrderByNameAsc()
                .stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<CategoryDto> getCategoriesByType(CategoryType type) {
        return categoryRepository.findByCategoryTypeAndActiveTrue(type)
                .stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<CategoryDto> getAllCategoriesForAdmin() {
        return categoryRepository.findAll()
                .stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Transactional
    public CategoryDto createCategory(CategoryDto dto) {
        if (categoryRepository.existsByName(dto.getName())) {
            throw new BadRequestException("Category with name '" + dto.getName() + "' already exists");
        }
        Category cat = new Category();
        cat.setName(dto.getName().trim());
        cat.setSlug(dto.getName().trim().toLowerCase().replaceAll("[^a-z0-9]", "-"));
        cat.setCategoryType(dto.getCategoryType());
        cat.setDescription(dto.getDescription());
        cat.setIcon(dto.getIcon());
        cat.setActive(dto.isActive());
        return mapToDto(categoryRepository.save(cat));
    }

    @Transactional
    public CategoryDto updateCategory(Long id, CategoryDto dto) {
        Category cat = categoryRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Category not found with id: " + id));

        cat.setName(dto.getName().trim());
        cat.setCategoryType(dto.getCategoryType());
        cat.setDescription(dto.getDescription());
        cat.setIcon(dto.getIcon());
        cat.setActive(dto.isActive());
        return mapToDto(categoryRepository.save(cat));
    }

    @Transactional
    public void toggleActiveStatus(Long id) {
        Category cat = categoryRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Category not found with id: " + id));
        cat.setActive(!cat.isActive());
        categoryRepository.save(cat);
    }

    public CategoryDto mapToDto(Category c) {
        CategoryDto dto = new CategoryDto();
        dto.setId(c.getId());
        dto.setName(c.getName());
        dto.setSlug(c.getSlug());
        dto.setCategoryType(c.getCategoryType());
        dto.setDescription(c.getDescription());
        dto.setIcon(c.getIcon());
        dto.setActive(c.isActive());
        return dto;
    }
}

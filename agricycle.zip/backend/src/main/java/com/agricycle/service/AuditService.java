package com.agricycle.service;

import com.agricycle.entity.AuditLog;
import com.agricycle.repository.AuditLogRepository;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AuditService {

    private final AuditLogRepository auditLogRepository;

    public AuditService(AuditLogRepository auditLogRepository) {
        this.auditLogRepository = auditLogRepository;
    }

    public void log(Long actorId, String actorEmail, String action, String resourceType, Long resourceId, String details, String ipAddress, String result) {
        AuditLog auditLog = new AuditLog(actorId, actorEmail, action, resourceType, resourceId, details, ipAddress, result);
        auditLogRepository.save(auditLog);
    }

    public List<AuditLog> getRecentLogs() {
        return auditLogRepository.findTop20ByOrderByCreatedAtDesc();
    }
}

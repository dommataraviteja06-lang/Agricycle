package com.agricycle.service;

import com.agricycle.dto.*;
import com.agricycle.entity.*;
import com.agricycle.exception.BadRequestException;
import com.agricycle.exception.ForbiddenException;
import com.agricycle.exception.ResourceNotFoundException;
import com.agricycle.repository.*;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class OrderService {

    private final OrderRepository orderRepository;
    private final OrderItemRepository orderItemRepository;
    private final ListingRepository listingRepository;
    private final UserRepository userRepository;
    private final TransportJobRepository transportJobRepository;
    private final PaymentRepository paymentRepository;
    private final NotificationService notificationService;
    private final AuditService auditService;

    public OrderService(OrderRepository orderRepository,
                        OrderItemRepository orderItemRepository,
                        ListingRepository listingRepository,
                        UserRepository userRepository,
                        TransportJobRepository transportJobRepository,
                        PaymentRepository paymentRepository,
                        NotificationService notificationService,
                        AuditService auditService) {
        this.orderRepository = orderRepository;
        this.orderItemRepository = orderItemRepository;
        this.listingRepository = listingRepository;
        this.userRepository = userRepository;
        this.transportJobRepository = transportJobRepository;
        this.paymentRepository = paymentRepository;
        this.notificationService = notificationService;
        this.auditService = auditService;
    }

    @Transactional
    public OrderDto createOrder(CreateOrderRequest req, Long buyerUserId, String clientIp) {
        User buyer = userRepository.findById(buyerUserId)
                .orElseThrow(() -> new ResourceNotFoundException("Buyer not found"));

        Listing listing = listingRepository.findByIdForUpdate(req.getListingId())
                .orElseThrow(() -> new ResourceNotFoundException("Listing not found with id: " + req.getListingId()));

        if (listing.getSeller().getId().equals(buyerUserId)) {
            throw new BadRequestException("You cannot purchase your own listing.");
        }

        if (req.getQuantity() <= 0) {
            throw new BadRequestException("Quantity must be greater than zero.");
        }

        if (req.getQuantity() > listing.getAvailableQuantity()) {
            throw new BadRequestException("Requested quantity exceeds available quantity (" + listing.getAvailableQuantity() + " " + listing.getUnit() + ").");
        }

        // Deduct available quantity
        listing.setAvailableQuantity(listing.getAvailableQuantity() - req.getQuantity());
        if (listing.getAvailableQuantity() <= 0) {
            listing.setListingStatus(ListingStatus.SOLD);
        }
        listingRepository.save(listing);

        // Create Order
        Order order = new Order();
        String orderNum = String.format("ORD-%s-%s",
                LocalDateTime.now().toString().replaceAll("[^0-9]", "").substring(0, 8),
                UUID.randomUUID().toString().replace("-", ""));
        order.setOrderNumber(orderNum);
        order.setBuyer(buyer);
        order.setSeller(listing.getSeller());
        order.setTotalAmount(req.getQuantity() * listing.getPricePerUnit());
        order.setStatus(OrderStatus.PENDING);
        order.setDeliveryAddress(req.getDeliveryAddress() != null ? req.getDeliveryAddress() : buyer.getFullName() + ", " + listing.getDistrict());
        order.setDistrict(req.getDistrict() != null ? req.getDistrict() : listing.getDistrict());
        order.setState(req.getState() != null ? req.getState() : listing.getState());
        order.setSpecialInstructions(req.getSpecialInstructions());

        order = orderRepository.save(order);

        // Create OrderItem
        OrderItem item = new OrderItem();
        item.setOrder(order);
        item.setListing(listing);
        item.setMaterialName(listing.getProductMaterialName());
        item.setQuantity(req.getQuantity());
        item.setUnit(listing.getUnit());
        item.setPricePerUnit(listing.getPricePerUnit());
        item.setTotalPrice(order.getTotalAmount());
        orderItemRepository.save(item);

        // Notify seller
        notificationService.sendNotification(
                listing.getSeller(),
                "📦 New Order Request!",
                String.format("%s placed an order for %.1f %s of %s (Total: ₹%.2f). Order %s",
                        buyer.getFullName(), req.getQuantity(), listing.getUnit(), listing.getProductMaterialName(),
                        order.getTotalAmount(), order.getOrderNumber()),
                NotificationType.ORDER,
                order.getId()
        );

        auditService.log(buyer.getId(), buyer.getEmail(), "ORDER_PLACED", "Order", order.getId(),
                "Order " + orderNum + " placed for ₹" + order.getTotalAmount(), clientIp, "SUCCESS");

        return mapToDto(order);
    }

    @Transactional
    public OrderDto updateOrderStatus(Long orderId, OrderStatus newStatus, Long currentUserId, String clientIp) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found with id: " + orderId));

        User currentUser = userRepository.findById(currentUserId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        boolean isBuyer = order.getBuyer().getId().equals(currentUserId);
        boolean isSeller = order.getSeller().getId().equals(currentUserId);
        boolean isAdmin = currentUser.getRole() == Role.ROLE_ADMIN;

        if (!isBuyer && !isSeller && !isAdmin) {
            throw new ForbiddenException("You are not authorized to update this order.");
        }

        // Validate state transitions
        validateStateTransition(order.getStatus(), newStatus, isBuyer, isSeller, isAdmin);

        order.setStatus(newStatus);
        order = orderRepository.save(order);

        // Lifecycle hook: When order becomes CONFIRMED, create TransportJob & Payment record
        if (newStatus == OrderStatus.CONFIRMED) {
            if (order.getTransportJob() == null) {
                TransportJob job = new TransportJob();
                job.setOrder(order);
                job.setPickupLocation(order.getSeller().getFullName() + ", " + order.getDistrict());
                job.setPickupDistrict(order.getDistrict());
                job.setDeliveryLocation(order.getDeliveryAddress());
                job.setDeliveryDistrict(order.getDistrict());
                job.setWeightTons(order.getItems().isEmpty() ? 5.0 : order.getItems().get(0).getQuantity());
                job.setAgreedFare(Math.max(1500.0, order.getTotalAmount() * 0.08)); // 8% estimated transport fare
                job.setStatus(TransportStatus.REQUESTED);
                transportJobRepository.save(job);
            }

            if (order.getPayment() == null) {
                Payment payment = new Payment();
                payment.setOrder(order);
                payment.setAmount(order.getTotalAmount());
                payment.setStatus(PaymentStatus.PENDING);
                payment.setPaymentMethod("ESCROW_TRANSFER");
                paymentRepository.save(payment);
            }
        }

        // Send notifications
        User notifyTarget = isSeller ? order.getBuyer() : order.getSeller();
        notificationService.sendNotification(
                notifyTarget,
                "Order Status Update: " + newStatus,
                "Order #" + order.getOrderNumber() + " is now " + newStatus,
                NotificationType.ORDER,
                order.getId()
        );

        auditService.log(currentUserId, currentUser.getEmail(), "ORDER_STATUS_CHANGED", "Order", order.getId(),
                "Order status changed to " + newStatus, clientIp, "SUCCESS");

        return mapToDto(order);
    }

    private void validateStateTransition(OrderStatus current, OrderStatus next, boolean isBuyer, boolean isSeller, boolean isAdmin) {
        if (isAdmin) return; // Super Admin has override power

        if (current == OrderStatus.COMPLETED || current == OrderStatus.CANCELLED || current == OrderStatus.REJECTED) {
            throw new BadRequestException("Cannot change status of an order that is already " + current);
        }

        if (next == OrderStatus.CANCELLED) {
            if (current == OrderStatus.PICKED_UP || current == OrderStatus.IN_TRANSIT || current == OrderStatus.DELIVERED) {
                throw new BadRequestException("Cannot cancel an order that is already in transit or delivered.");
            }
            return;
        }

        if (current == OrderStatus.PENDING) {
            if (next == OrderStatus.ACCEPTED || next == OrderStatus.CONFIRMED || next == OrderStatus.REJECTED || next == OrderStatus.NEGOTIATION) {
                if (!isSeller) throw new ForbiddenException("Only the seller can accept, confirm, reject, or negotiate a pending order.");
                return;
            }
        }

        if (current == OrderStatus.ACCEPTED || current == OrderStatus.NEGOTIATION) {
            if (next == OrderStatus.CONFIRMED) {
                return; // Either party can confirm
            }
        }

        if (current == OrderStatus.DELIVERED) {
            if (next == OrderStatus.COMPLETED) {
                if (!isBuyer) throw new ForbiddenException("Only the buyer can mark delivery completed.");
                return;
            }
        }

        // Normal sequential check for logistics states
        if (next == OrderStatus.TRANSPORT_ASSIGNED || next == OrderStatus.PICKED_UP ||
            next == OrderStatus.IN_TRANSIT || next == OrderStatus.DELIVERED) {
            return;
        }

        throw new BadRequestException("Invalid state transition from " + current + " to " + next);
    }

    @Transactional(readOnly = true)
    public OrderDto getOrderById(Long orderId, Long currentUserId) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found with id: " + orderId));

        User currentUser = userRepository.findById(currentUserId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        boolean isBuyer = order.getBuyer().getId().equals(currentUserId);
        boolean isSeller = order.getSeller().getId().equals(currentUserId);
        boolean isTransporter = order.getTransportJob() != null &&
                order.getTransportJob().getTransporter() != null &&
                order.getTransportJob().getTransporter().getId().equals(currentUserId);
        boolean isAdmin = currentUser.getRole() == Role.ROLE_ADMIN;

        if (!isBuyer && !isSeller && !isTransporter && !isAdmin) {
            throw new ForbiddenException("You are not authorized to view this order.");
        }

        return mapToDto(order);
    }

    @Transactional(readOnly = true)
    public List<OrderDto> getBuyerOrders(Long buyerUserId) {
        return orderRepository.findByBuyer_IdOrderByCreatedAtDesc(buyerUserId)
                .stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<OrderDto> getSellerOrders(Long sellerUserId) {
        return orderRepository.findBySeller_IdOrderByCreatedAtDesc(sellerUserId)
                .stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public Page<OrderDto> searchOrdersForAdmin(OrderStatus status, String search, int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "createdAt"));
        return orderRepository.searchOrders(status, search, pageable).map(this::mapToDto);
    }

    public OrderDto mapToDto(Order o) {
        OrderDto dto = new OrderDto();
        dto.setId(o.getId());
        dto.setOrderNumber(o.getOrderNumber());
        dto.setBuyerId(o.getBuyer().getId());
        dto.setBuyerName(o.getBuyer().getFullName());
        dto.setBuyerRole(o.getBuyer().getRole().name());
        dto.setSellerId(o.getSeller().getId());
        dto.setSellerName(o.getSeller().getFullName());
        dto.setSellerMobile(o.getSeller().getMobile());

        if (o.getRequirement() != null) {
            dto.setRequirementId(o.getRequirement().getId());
        }

        dto.setTotalAmount(o.getTotalAmount());
        dto.setStatus(o.getStatus());
        dto.setDeliveryAddress(o.getDeliveryAddress());
        dto.setDistrict(o.getDistrict());
        dto.setState(o.getState());
        dto.setSpecialInstructions(o.getSpecialInstructions());

        if (o.getItems() != null) {
            dto.setItems(o.getItems().stream().map(item -> {
                OrderItemDto itemDto = new OrderItemDto();
                itemDto.setId(item.getId());
                if (item.getListing() != null) {
                    itemDto.setListingId(item.getListing().getId());
                    itemDto.setLotId(item.getListing().getLotId());
                }
                itemDto.setMaterialName(item.getMaterialName());
                itemDto.setQuantity(item.getQuantity());
                itemDto.setUnit(item.getUnit());
                itemDto.setPricePerUnit(item.getPricePerUnit());
                itemDto.setTotalPrice(item.getTotalPrice());
                return itemDto;
            }).collect(Collectors.toList()));
        }

        if (o.getTransportJob() != null) {
            TransportJob tj = o.getTransportJob();
            TransportJobDto tjDto = new TransportJobDto();
            tjDto.setId(tj.getId());
            tjDto.setOrderId(o.getId());
            tjDto.setOrderNumber(o.getOrderNumber());
            if (tj.getTransporter() != null) {
                tjDto.setTransporterId(tj.getTransporter().getId());
                tjDto.setTransporterName(tj.getTransporter().getFullName());
                tjDto.setTransporterMobile(tj.getTransporter().getMobile());
            }
            tjDto.setPickupLocation(tj.getPickupLocation());
            tjDto.setPickupDistrict(tj.getPickupDistrict());
            tjDto.setDeliveryLocation(tj.getDeliveryLocation());
            tjDto.setDeliveryDistrict(tj.getDeliveryDistrict());
            tjDto.setWeightTons(tj.getWeightTons());
            tjDto.setAgreedFare(tj.getAgreedFare());
            tjDto.setStatus(tj.getStatus());
            tjDto.setSharedTransport(tj.isSharedTransport());
            tjDto.setTrackingNotes(tj.getTrackingNotes());
            tjDto.setAssignedAt(tj.getAssignedAt());
            tjDto.setPickedUpAt(tj.getPickedUpAt());
            tjDto.setDeliveredAt(tj.getDeliveredAt());
            tjDto.setCreatedAt(tj.getCreatedAt());
            dto.setTransportJob(tjDto);
        }

        if (o.getPayment() != null) {
            Payment p = o.getPayment();
            PaymentDto pDto = new PaymentDto();
            pDto.setId(p.getId());
            pDto.setOrderId(o.getId());
            pDto.setTransactionReference(p.getTransactionReference());
            pDto.setAmount(p.getAmount());
            pDto.setStatus(p.getStatus());
            pDto.setPaymentMethod(p.getPaymentMethod());
            pDto.setPaidAt(p.getPaidAt());
            pDto.setFailureReason(p.getFailureReason());
            pDto.setCreatedAt(p.getCreatedAt());
            dto.setPayment(pDto);
        }

        if (o.getNegotiations() != null) {
            dto.setNegotiations(o.getNegotiations().stream().map(n -> {
                OrderNegotiationDto nDto = new OrderNegotiationDto();
                nDto.setId(n.getId());
                nDto.setOrderId(o.getId());
                nDto.setProposedByUserId(n.getProposedByUser().getId());
                nDto.setProposedByUserName(n.getProposedByUser().getFullName());
                nDto.setProposedPrice(n.getProposedPrice());
                nDto.setProposedQuantity(n.getProposedQuantity());
                nDto.setProposedDeliveryDate(n.getProposedDeliveryDate());
                nDto.setNotes(n.getNotes());
                nDto.setStatus(n.getStatus());
                nDto.setCreatedAt(n.getCreatedAt());
                return nDto;
            }).collect(Collectors.toList()));
        }

        dto.setCreatedAt(o.getCreatedAt());
        dto.setUpdatedAt(o.getUpdatedAt());
        return dto;
    }
}

package com.agricycle.repository;

import com.agricycle.entity.TransportJob;
import com.agricycle.entity.TransportStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface TransportJobRepository extends JpaRepository<TransportJob, Long> {

    Optional<TransportJob> findByOrder_Id(Long orderId);

    List<TransportJob> findByTransporter_IdOrderByCreatedAtDesc(Long transporterId);
    Page<TransportJob> findByTransporter_IdOrderByCreatedAtDesc(Long transporterId, Pageable pageable);

    List<TransportJob> findByStatus(TransportStatus status);

    @Query("SELECT j FROM TransportJob j WHERE j.status = 'REQUESTED' AND " +
           "(:district IS NULL OR LOWER(j.pickupDistrict) = LOWER(:district) OR LOWER(j.deliveryDistrict) = LOWER(:district))")
    Page<TransportJob> findAvailableJobs(@Param("district") String district, Pageable pageable);

    @Query("SELECT SUM(j.agreedFare) FROM TransportJob j WHERE j.transporter.id = :transporterId AND j.status = 'COMPLETED'")
    Double sumTransporterEarnings(@Param("transporterId") Long transporterId);

    long countByTransporter_IdAndStatus(Long transporterId, TransportStatus status);
    long countByStatus(TransportStatus status);
}

package com.agricycle.repository;

import com.agricycle.entity.RequirementOffer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RequirementOfferRepository extends JpaRepository<RequirementOffer, Long> {
    List<RequirementOffer> findByRequirement_Id(Long requirementId);
    List<RequirementOffer> findBySupplier_IdOrderByCreatedAtDesc(Long supplierId);
    List<RequirementOffer> findByRequirement_IdAndStatus(Long requirementId, RequirementOffer.OfferStatus status);
}

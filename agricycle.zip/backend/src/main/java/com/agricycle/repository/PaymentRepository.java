package com.agricycle.repository;

import com.agricycle.entity.Payment;
import com.agricycle.entity.PaymentStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface PaymentRepository extends JpaRepository<Payment, Long> {
    Optional<Payment> findByOrder_Id(Long orderId);
    Optional<Payment> findByTransactionReference(String transactionReference);
    long countByStatus(PaymentStatus status);
}

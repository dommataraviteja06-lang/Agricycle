package com.agricycle.repository;

import com.agricycle.entity.Harvest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface HarvestRepository extends JpaRepository<Harvest, Long> {
    List<Harvest> findByFarmer_IdOrderByCreatedAtDesc(Long farmerId);
    Page<Harvest> findByFarmer_IdOrderByCreatedAtDesc(Long farmerId, Pageable pageable);
    long countByFarmer_Id(Long farmerId);
}

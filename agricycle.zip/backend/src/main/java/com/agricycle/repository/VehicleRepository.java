package com.agricycle.repository;

import com.agricycle.entity.Vehicle;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface VehicleRepository extends JpaRepository<Vehicle, Long> {
    List<Vehicle> findByTransporter_Id(Long transporterId);
    List<Vehicle> findByTransporter_IdAndAvailableTrue(Long transporterId);
}

package com.agricycle.repository;

import com.agricycle.entity.Requirement;
import com.agricycle.entity.RequirementStatus;
import com.agricycle.entity.UrgencyLevel;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RequirementRepository extends JpaRepository<Requirement, Long> {

    List<Requirement> findByUser_IdOrderByCreatedAtDesc(Long userId);
    Page<Requirement> findByUser_IdOrderByCreatedAtDesc(Long userId, Pageable pageable);

    List<Requirement> findByStatus(RequirementStatus status);

    List<Requirement> findByEmergencyTrueAndStatusOrderByCreatedAtDesc(RequirementStatus status);

    @Query("SELECT r FROM Requirement r WHERE " +
           "(:status IS NULL OR r.status = :status) AND " +
           "(:emergency IS NULL OR r.emergency = :emergency) AND " +
           "(:urgency IS NULL OR r.urgency = :urgency) AND " +
           "(:district IS NULL OR LOWER(r.district) = LOWER(:district)) AND " +
           "(:keyword IS NULL OR LOWER(r.materialName) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
           " LOWER(r.description) LIKE LOWER(CONCAT('%', :keyword, '%')))")
    Page<Requirement> searchRequirements(@Param("status") RequirementStatus status,
                                         @Param("emergency") Boolean emergency,
                                         @Param("urgency") UrgencyLevel urgency,
                                         @Param("district") String district,
                                         @Param("keyword") String keyword,
                                         Pageable pageable);

    long countByStatus(RequirementStatus status);
    long countByEmergencyTrueAndStatus(RequirementStatus status);
}

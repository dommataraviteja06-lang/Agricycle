package com.agricycle.repository;

import com.agricycle.entity.LivestockProfile;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface LivestockProfileRepository extends JpaRepository<LivestockProfile, Long> {
    Optional<LivestockProfile> findByUser_Id(Long userId);
    boolean existsByUser_Id(Long userId);
}

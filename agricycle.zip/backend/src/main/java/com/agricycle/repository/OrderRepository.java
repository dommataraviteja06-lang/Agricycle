package com.agricycle.repository;

import com.agricycle.entity.Order;
import com.agricycle.entity.OrderStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface OrderRepository extends JpaRepository<Order, Long> {

    Optional<Order> findByOrderNumber(String orderNumber);

    List<Order> findByBuyer_IdOrderByCreatedAtDesc(Long buyerId);
    Page<Order> findByBuyer_IdOrderByCreatedAtDesc(Long buyerId, Pageable pageable);

    List<Order> findBySeller_IdOrderByCreatedAtDesc(Long sellerId);
    Page<Order> findBySeller_IdOrderByCreatedAtDesc(Long sellerId, Pageable pageable);

    List<Order> findByStatus(OrderStatus status);

    long countBySeller_IdAndStatus(Long sellerId, OrderStatus status);
    long countByBuyer_IdAndStatus(Long buyerId, OrderStatus status);
    long countByStatus(OrderStatus status);

    @Query("SELECT SUM(o.totalAmount) FROM Order o WHERE o.seller.id = :sellerId AND o.status = 'COMPLETED'")
    Double sumCompletedEarningsBySellerId(@Param("sellerId") Long sellerId);

    @Query("SELECT o FROM Order o WHERE " +
           "(:status IS NULL OR o.status = :status) AND " +
           "(:search IS NULL OR LOWER(o.orderNumber) LIKE LOWER(CONCAT('%', :search, '%')))")
    Page<Order> searchOrders(@Param("status") OrderStatus status,
                             @Param("search") String search,
                             Pageable pageable);
}

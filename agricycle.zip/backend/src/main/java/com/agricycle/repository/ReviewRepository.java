package com.agricycle.repository;

import com.agricycle.entity.Review;
import com.agricycle.entity.ReviewType;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ReviewRepository extends JpaRepository<Review, Long> {

    List<Review> findByTargetUser_IdOrderByCreatedAtDesc(Long targetUserId);
    Page<Review> findByTargetUser_IdOrderByCreatedAtDesc(Long targetUserId, Pageable pageable);

    boolean existsByOrder_IdAndReviewer_IdAndReviewType(Long orderId, Long reviewerId, ReviewType reviewType);

    List<Review> findByReportedTrue();

    @Query("SELECT AVG(r.rating) FROM Review r WHERE r.targetUser.id = :targetUserId")
    Double getAverageRatingForUser(@Param("targetUserId") Long targetUserId);

    @Query("SELECT COUNT(r) FROM Review r WHERE r.targetUser.id = :targetUserId")
    long countReviewsForUser(@Param("targetUserId") Long targetUserId);
}

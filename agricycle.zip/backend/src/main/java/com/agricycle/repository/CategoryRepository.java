package com.agricycle.repository;

import com.agricycle.entity.Category;
import com.agricycle.entity.CategoryType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CategoryRepository extends JpaRepository<Category, Long> {
    List<Category> findAllByActiveTrueOrderByNameAsc();
    List<Category> findByCategoryTypeAndActiveTrue(CategoryType categoryType);
    Optional<Category> findBySlug(String slug);
    boolean existsByName(String name);
}

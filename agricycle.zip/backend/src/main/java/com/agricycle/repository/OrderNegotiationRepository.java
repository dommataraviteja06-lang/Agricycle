package com.agricycle.repository;

import com.agricycle.entity.OrderNegotiation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface OrderNegotiationRepository extends JpaRepository<OrderNegotiation, Long> {
    List<OrderNegotiation> findByOrder_IdOrderByCreatedAtDesc(Long orderId);
}

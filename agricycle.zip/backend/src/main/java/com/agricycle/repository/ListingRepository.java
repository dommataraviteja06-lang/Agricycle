package com.agricycle.repository;

import com.agricycle.entity.CategoryType;
import com.agricycle.entity.Listing;
import com.agricycle.entity.ListingStatus;
import jakarta.persistence.LockModeType;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ListingRepository extends JpaRepository<Listing, Long> {

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("SELECT l FROM Listing l WHERE l.id = :id")
    Optional<Listing> findByIdForUpdate(@Param("id") Long id);

    Optional<Listing> findByLotId(String lotId);

    List<Listing> findBySeller_IdOrderByCreatedAtDesc(Long sellerId);
    Page<Listing> findBySeller_IdOrderByCreatedAtDesc(Long sellerId, Pageable pageable);

    List<Listing> findByHarvest_Id(Long harvestId);

    long countBySeller_IdAndListingStatus(Long sellerId, ListingStatus status);
    long countByListingStatus(ListingStatus status);

    @Query("SELECT l FROM Listing l WHERE " +
           "(:status IS NULL OR l.listingStatus = :status) AND " +
           "(:categoryId IS NULL OR l.category.id = :categoryId) AND " +
           "(:categoryType IS NULL OR l.category.categoryType = :categoryType) AND " +
           "(:district IS NULL OR LOWER(l.district) = LOWER(:district)) AND " +
           "(:state IS NULL OR LOWER(l.state) = LOWER(:state)) AND " +
           "(:minPrice IS NULL OR l.pricePerUnit >= :minPrice) AND " +
           "(:maxPrice IS NULL OR l.pricePerUnit <= :maxPrice) AND " +
           "(:minQty IS NULL OR l.availableQuantity >= :minQty) AND " +
           "(:keyword IS NULL OR LOWER(l.title) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
           " LOWER(l.productMaterialName) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
           " LOWER(l.description) LIKE LOWER(CONCAT('%', :keyword, '%')))")
    Page<Listing> searchListings(@Param("status") ListingStatus status,
                                 @Param("categoryId") Long categoryId,
                                 @Param("categoryType") CategoryType categoryType,
                                 @Param("district") String district,
                                 @Param("state") String state,
                                 @Param("minPrice") Double minPrice,
                                 @Param("maxPrice") Double maxPrice,
                                 @Param("minQty") Double minQty,
                                 @Param("keyword") String keyword,
                                 Pageable pageable);

    @Query("SELECT l FROM Listing l WHERE l.listingStatus = 'APPROVED' AND l.category.categoryType = 'FODDER' AND " +
           "(:district IS NULL OR LOWER(l.district) = LOWER(:district)) AND " +
           "(:minQty IS NULL OR l.availableQuantity >= :minQty) AND " +
           "(:keyword IS NULL OR LOWER(l.productMaterialName) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
           " LOWER(l.suitableUse) LIKE LOWER(CONCAT('%', :keyword, '%')))")
    Page<Listing> searchFodderListings(@Param("district") String district,
                                       @Param("minQty") Double minQty,
                                       @Param("keyword") String keyword,
                                       Pageable pageable);

    @Query("SELECT l FROM Listing l WHERE l.listingStatus = 'APPROVED' AND l.category.categoryType = 'AGRICULTURAL_RESIDUE' AND " +
           "(:district IS NULL OR LOWER(l.district) = LOWER(:district)) AND " +
           "(:keyword IS NULL OR LOWER(l.productMaterialName) LIKE LOWER(CONCAT('%', :keyword, '%')))")
    Page<Listing> searchResidueListings(@Param("district") String district,
                                        @Param("keyword") String keyword,
                                        Pageable pageable);

    @Query("SELECT DISTINCT l.district FROM Listing l WHERE l.listingStatus = 'APPROVED'")
    List<String> findDistinctDistricts();
}

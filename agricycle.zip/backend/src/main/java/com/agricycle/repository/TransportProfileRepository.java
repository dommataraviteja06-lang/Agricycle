package com.agricycle.repository;

import com.agricycle.entity.TransportProfile;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface TransportProfileRepository extends JpaRepository<TransportProfile, Long> {
    Optional<TransportProfile> findByUser_Id(Long userId);
    boolean existsByUser_Id(Long userId);
}

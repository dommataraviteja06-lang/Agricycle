package com.agricycle.repository;

import com.agricycle.entity.Dispute;
import com.agricycle.entity.DisputeStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DisputeRepository extends JpaRepository<Dispute, Long> {
    List<Dispute> findByStatus(DisputeStatus status);
    Page<Dispute> findByStatus(DisputeStatus status, Pageable pageable);
    List<Dispute> findByRaisedByUser_Id(Long userId);
    List<Dispute> findByOrder_Id(Long orderId);
    long countByStatus(DisputeStatus status);
}

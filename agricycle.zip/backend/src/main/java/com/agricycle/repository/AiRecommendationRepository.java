package com.agricycle.repository;

import com.agricycle.entity.AiRecommendation;
import com.agricycle.entity.RecommendationType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AiRecommendationRepository extends JpaRepository<AiRecommendation, Long> {
    List<AiRecommendation> findByUser_IdOrderByCreatedAtDesc(Long userId);
    List<AiRecommendation> findByHarvest_Id(Long harvestId);
    List<AiRecommendation> findByRecommendationTypeOrderByCreatedAtDesc(RecommendationType type);
}

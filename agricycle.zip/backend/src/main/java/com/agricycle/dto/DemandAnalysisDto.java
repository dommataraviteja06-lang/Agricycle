package com.agricycle.dto;

import java.util.List;
import java.util.Map;

public class DemandAnalysisDto {
    private String materialName;
    private String cropName;
    private String demandLevel; // HIGH DEMAND, MEDIUM DEMAND, LOW DEMAND
    private Double demandScore; // 0 to 100
    private String regionalHotspot;
    private String seasonalPeakSeason;
    private List<MonthlyTrend> monthlyTrends;
    private Map<String, Integer> regionalDemandMap;
    private String summaryText;

    public static class MonthlyTrend {
        private String month;
        private int demandIndex;
        private int supplyIndex;

        public MonthlyTrend() {}

        public MonthlyTrend(String month, int demandIndex, int supplyIndex) {
            this.month = month;
            this.demandIndex = demandIndex;
            this.supplyIndex = supplyIndex;
        }

        public String getMonth() { return month; }
        public void setMonth(String month) { this.month = month; }

        public int getDemandIndex() { return demandIndex; }
        public void setDemandIndex(int demandIndex) { this.demandIndex = demandIndex; }

        public int getSupplyIndex() { return supplyIndex; }
        public void setSupplyIndex(int supplyIndex) { this.supplyIndex = supplyIndex; }
    }

    public DemandAnalysisDto() {}

    public String getMaterialName() { return materialName; }
    public void setMaterialName(String materialName) { this.materialName = materialName; }

    public String getCropName() { return cropName; }
    public void setCropName(String cropName) { this.cropName = cropName; }

    public String getDemandLevel() { return demandLevel; }
    public void setDemandLevel(String demandLevel) { this.demandLevel = demandLevel; }

    public Double getDemandScore() { return demandScore; }
    public void setDemandScore(Double demandScore) { this.demandScore = demandScore; }

    public String getRegionalHotspot() { return regionalHotspot; }
    public void setRegionalHotspot(String regionalHotspot) { this.regionalHotspot = regionalHotspot; }

    public String getSeasonalPeakSeason() { return seasonalPeakSeason; }
    public void setSeasonalPeakSeason(String seasonalPeakSeason) { this.seasonalPeakSeason = seasonalPeakSeason; }

    public List<MonthlyTrend> getMonthlyTrends() { return monthlyTrends; }
    public void setMonthlyTrends(List<MonthlyTrend> monthlyTrends) { this.monthlyTrends = monthlyTrends; }

    public Map<String, Integer> getRegionalDemandMap() { return regionalDemandMap; }
    public void setRegionalDemandMap(Map<String, Integer> regionalDemandMap) { this.regionalDemandMap = regionalDemandMap; }

    public String getSummaryText() { return summaryText; }
    public void setSummaryText(String summaryText) { this.summaryText = summaryText; }
}

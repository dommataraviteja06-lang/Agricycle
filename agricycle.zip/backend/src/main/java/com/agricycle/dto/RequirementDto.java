package com.agricycle.dto;

import com.agricycle.entity.RequirementStatus;
import com.agricycle.entity.UrgencyLevel;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

public class RequirementDto {
    private Long id;
    private Long userId;
    private String userName;
    private String userRole;
    private Long categoryId;
    private String categoryName;
    private String materialName;
    private Double quantityRequired;
    private Double fulfilledQuantity;
    private String unit;
    private Double targetPrice;
    private String village;
    private String district;
    private String state;
    private LocalDate requiredByDate;
    private String animalType;
    private Integer numberOfAnimals;
    private boolean emergency;
    private UrgencyLevel urgency;
    private String qualityRequirement;
    private String description;
    private String deliveryRequirement;
    private RequirementStatus status;
    private int offersCount;
    private List<RequirementOfferDto> offers;
    private LocalDateTime createdAt;

    public RequirementDto() {}

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public String getUserName() { return userName; }
    public void setUserName(String userName) { this.userName = userName; }

    public String getUserRole() { return userRole; }
    public void setUserRole(String userRole) { this.userRole = userRole; }

    public Long getCategoryId() { return categoryId; }
    public void setCategoryId(Long categoryId) { this.categoryId = categoryId; }

    public String getCategoryName() { return categoryName; }
    public void setCategoryName(String categoryName) { this.categoryName = categoryName; }

    public String getMaterialName() { return materialName; }
    public void setMaterialName(String materialName) { this.materialName = materialName; }

    public Double getQuantityRequired() { return quantityRequired; }
    public void setQuantityRequired(Double quantityRequired) { this.quantityRequired = quantityRequired; }

    public Double getFulfilledQuantity() { return fulfilledQuantity; }
    public void setFulfilledQuantity(Double fulfilledQuantity) { this.fulfilledQuantity = fulfilledQuantity; }

    public String getUnit() { return unit; }
    public void setUnit(String unit) { this.unit = unit; }

    public Double getTargetPrice() { return targetPrice; }
    public void setTargetPrice(Double targetPrice) { this.targetPrice = targetPrice; }

    public String getVillage() { return village; }
    public void setVillage(String village) { this.village = village; }

    public String getDistrict() { return district; }
    public void setDistrict(String district) { this.district = district; }

    public String getState() { return state; }
    public void setState(String state) { this.state = state; }

    public LocalDate getRequiredByDate() { return requiredByDate; }
    public void setRequiredByDate(LocalDate requiredByDate) { this.requiredByDate = requiredByDate; }

    public String getAnimalType() { return animalType; }
    public void setAnimalType(String animalType) { this.animalType = animalType; }

    public Integer getNumberOfAnimals() { return numberOfAnimals; }
    public void setNumberOfAnimals(Integer numberOfAnimals) { this.numberOfAnimals = numberOfAnimals; }

    public boolean isEmergency() { return emergency; }
    public void setEmergency(boolean emergency) { this.emergency = emergency; }

    public UrgencyLevel getUrgency() { return urgency; }
    public void setUrgency(UrgencyLevel urgency) { this.urgency = urgency; }

    public String getQualityRequirement() { return qualityRequirement; }
    public void setQualityRequirement(String qualityRequirement) { this.qualityRequirement = qualityRequirement; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getDeliveryRequirement() { return deliveryRequirement; }
    public void setDeliveryRequirement(String deliveryRequirement) { this.deliveryRequirement = deliveryRequirement; }

    public RequirementStatus getStatus() { return status; }
    public void setStatus(RequirementStatus status) { this.status = status; }

    public int getOffersCount() { return offersCount; }
    public void setOffersCount(int offersCount) { this.offersCount = offersCount; }

    public List<RequirementOfferDto> getOffers() { return offers; }
    public void setOffers(List<RequirementOfferDto> offers) { this.offers = offers; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}

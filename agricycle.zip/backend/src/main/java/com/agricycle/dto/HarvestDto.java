package com.agricycle.dto;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

public class HarvestDto {
    private Long id;
    private Long farmerId;
    private String farmerName;
    private String cropName;
    private String cropVariety;
    private LocalDate harvestDate;
    private Double totalQuantity;
    private String unit;
    private String village;
    private String district;
    private String state;
    private String imageUrl;
    private String description;
    private int listingsCount;
    private List<ListingDto> listings;
    private LocalDateTime createdAt;

    public HarvestDto() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getFarmerId() { return farmerId; }
    public void setFarmerId(Long farmerId) { this.farmerId = farmerId; }

    public String getFarmerName() { return farmerName; }
    public void setFarmerName(String farmerName) { this.farmerName = farmerName; }

    public String getCropName() { return cropName; }
    public void setCropName(String cropName) { this.cropName = cropName; }

    public String getCropVariety() { return cropVariety; }
    public void setCropVariety(String cropVariety) { this.cropVariety = cropVariety; }

    public LocalDate getHarvestDate() { return harvestDate; }
    public void setHarvestDate(LocalDate harvestDate) { this.harvestDate = harvestDate; }

    public Double getTotalQuantity() { return totalQuantity; }
    public void setTotalQuantity(Double totalQuantity) { this.totalQuantity = totalQuantity; }

    public String getUnit() { return unit; }
    public void setUnit(String unit) { this.unit = unit; }

    public String getVillage() { return village; }
    public void setVillage(String village) { this.village = village; }

    public String getDistrict() { return district; }
    public void setDistrict(String district) { this.district = district; }

    public String getState() { return state; }
    public void setState(String state) { this.state = state; }

    public String getImageUrl() { return imageUrl; }
    public void setImageUrl(String imageUrl) { this.imageUrl = imageUrl; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public int getListingsCount() { return listingsCount; }
    public void setListingsCount(int listingsCount) { this.listingsCount = listingsCount; }

    public List<ListingDto> getListings() { return listings; }
    public void setListings(List<ListingDto> listings) { this.listings = listings; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}

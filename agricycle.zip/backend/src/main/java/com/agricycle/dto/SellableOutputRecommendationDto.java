package com.agricycle.dto;

import com.agricycle.entity.CategoryType;

public class SellableOutputRecommendationDto {
    private String materialName;
    private Long suggestedCategoryId;
    private String categoryName;
    private CategoryType categoryType;
    private String suitableUse;
    private String unit;
    private Double estimatedYieldRatio; // Ratio relative to main harvest quantity
    private Double estimatedPricePerUnit;
    private String description;

    public SellableOutputRecommendationDto() {}

    public SellableOutputRecommendationDto(String materialName, Long suggestedCategoryId, String categoryName, CategoryType categoryType, String suitableUse, String unit, Double estimatedYieldRatio, Double estimatedPricePerUnit, String description) {
        this.materialName = materialName;
        this.suggestedCategoryId = suggestedCategoryId;
        this.categoryName = categoryName;
        this.categoryType = categoryType;
        this.suitableUse = suitableUse;
        this.unit = unit;
        this.estimatedYieldRatio = estimatedYieldRatio;
        this.estimatedPricePerUnit = estimatedPricePerUnit;
        this.description = description;
    }

    public String getMaterialName() { return materialName; }
    public void setMaterialName(String materialName) { this.materialName = materialName; }

    public Long getSuggestedCategoryId() { return suggestedCategoryId; }
    public void setSuggestedCategoryId(Long suggestedCategoryId) { this.suggestedCategoryId = suggestedCategoryId; }

    public String getCategoryName() { return categoryName; }
    public void setCategoryName(String categoryName) { this.categoryName = categoryName; }

    public CategoryType getCategoryType() { return categoryType; }
    public void setCategoryType(CategoryType categoryType) { this.categoryType = categoryType; }

    public String getSuitableUse() { return suitableUse; }
    public void setSuitableUse(String suitableUse) { this.suitableUse = suitableUse; }

    public String getUnit() { return unit; }
    public void setUnit(String unit) { this.unit = unit; }

    public Double getEstimatedYieldRatio() { return estimatedYieldRatio; }
    public void setEstimatedYieldRatio(Double estimatedYieldRatio) { this.estimatedYieldRatio = estimatedYieldRatio; }

    public Double getEstimatedPricePerUnit() { return estimatedPricePerUnit; }
    public void setEstimatedPricePerUnit(Double estimatedPricePerUnit) { this.estimatedPricePerUnit = estimatedPricePerUnit; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
}

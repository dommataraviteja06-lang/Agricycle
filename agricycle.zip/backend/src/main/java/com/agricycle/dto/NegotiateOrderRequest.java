package com.agricycle.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import java.time.LocalDate;

public class NegotiateOrderRequest {

    @NotNull(message = "Proposed price is required")
    @Positive(message = "Proposed price must be greater than zero")
    private Double proposedPrice;

    @NotNull(message = "Proposed quantity is required")
    @Positive(message = "Proposed quantity must be greater than zero")
    private Double proposedQuantity;

    private LocalDate proposedDeliveryDate;
    private String notes;

    public NegotiateOrderRequest() {}

    public Double getProposedPrice() { return proposedPrice; }
    public void setProposedPrice(Double proposedPrice) { this.proposedPrice = proposedPrice; }

    public Double getProposedQuantity() { return proposedQuantity; }
    public void setProposedQuantity(Double proposedQuantity) { this.proposedQuantity = proposedQuantity; }

    public LocalDate getProposedDeliveryDate() { return proposedDeliveryDate; }
    public void setProposedDeliveryDate(LocalDate proposedDeliveryDate) { this.proposedDeliveryDate = proposedDeliveryDate; }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }
}

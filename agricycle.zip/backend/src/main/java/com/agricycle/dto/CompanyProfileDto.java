package com.agricycle.dto;

import com.agricycle.entity.VerificationStatus;
import java.time.LocalDateTime;

public class CompanyProfileDto {
    private Long id;
    private Long userId;
    private String companyName;
    private String industryType;
    private String gstNumberMasked;
    private String address;
    private String district;
    private String state;
    private String contactPerson;
    private String contactPhone;
    private VerificationStatus verificationStatus;
    private LocalDateTime createdAt;

    public CompanyProfileDto() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public String getCompanyName() { return companyName; }
    public void setCompanyName(String companyName) { this.companyName = companyName; }

    public String getIndustryType() { return industryType; }
    public void setIndustryType(String industryType) { this.industryType = industryType; }

    public String getGstNumberMasked() { return gstNumberMasked; }
    public void setGstNumberMasked(String gstNumberMasked) { this.gstNumberMasked = gstNumberMasked; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    public String getDistrict() { return district; }
    public void setDistrict(String district) { this.district = district; }

    public String getState() { return state; }
    public void setState(String state) { this.state = state; }

    public String getContactPerson() { return contactPerson; }
    public void setContactPerson(String contactPerson) { this.contactPerson = contactPerson; }

    public String getContactPhone() { return contactPhone; }
    public void setContactPhone(String contactPhone) { this.contactPhone = contactPhone; }

    public VerificationStatus getVerificationStatus() { return verificationStatus; }
    public void setVerificationStatus(VerificationStatus verificationStatus) { this.verificationStatus = verificationStatus; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}

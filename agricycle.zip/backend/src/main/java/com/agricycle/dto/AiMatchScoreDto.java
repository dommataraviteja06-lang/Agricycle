package com.agricycle.dto;

import java.util.List;

public class AiMatchScoreDto {
    private Double matchScore; // 0.0 to 100.0%
    private Double materialScore;
    private Double quantityScore;
    private Double distanceScore;
    private Double priceScore;
    private Double urgencyScore;
    private String explanation;
    private List<String> matchHighlights;
    private Long listingId;
    private Long requirementId;

    public AiMatchScoreDto() {}

    public Double getMatchScore() { return matchScore; }
    public void setMatchScore(Double matchScore) { this.matchScore = matchScore; }

    public Double getMaterialScore() { return materialScore; }
    public void setMaterialScore(Double materialScore) { this.materialScore = materialScore; }

    public Double getQuantityScore() { return quantityScore; }
    public void setQuantityScore(Double quantityScore) { this.quantityScore = quantityScore; }

    public Double getDistanceScore() { return distanceScore; }
    public void setDistanceScore(Double distanceScore) { this.distanceScore = distanceScore; }

    public Double getPriceScore() { return priceScore; }
    public void setPriceScore(Double priceScore) { this.priceScore = priceScore; }

    public Double getUrgencyScore() { return urgencyScore; }
    public void setUrgencyScore(Double urgencyScore) { this.urgencyScore = urgencyScore; }

    public String getExplanation() { return explanation; }
    public void setExplanation(String explanation) { this.explanation = explanation; }

    public List<String> getMatchHighlights() { return matchHighlights; }
    public void setMatchHighlights(List<String> matchHighlights) { this.matchHighlights = matchHighlights; }

    public Long getListingId() { return listingId; }
    public void setListingId(Long listingId) { this.listingId = listingId; }

    public Long getRequirementId() { return requirementId; }
    public void setRequirementId(Long requirementId) { this.requirementId = requirementId; }
}

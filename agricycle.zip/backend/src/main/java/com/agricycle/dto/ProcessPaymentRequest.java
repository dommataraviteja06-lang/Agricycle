package com.agricycle.dto;

import jakarta.validation.constraints.NotNull;

public class ProcessPaymentRequest {

    @NotNull(message = "Order ID is required")
    private Long orderId;

    private String paymentMethod = "ESCROW_TRANSFER"; // e.g. ESCROW_TRANSFER, UPI_QR, NET_BANKING, AGRI_CREDIT

    public ProcessPaymentRequest() {}

    public ProcessPaymentRequest(Long orderId, String paymentMethod) {
        this.orderId = orderId;
        this.paymentMethod = paymentMethod;
    }

    public Long getOrderId() { return orderId; }
    public void setOrderId(Long orderId) { this.orderId = orderId; }

    public String getPaymentMethod() { return paymentMethod; }
    public void setPaymentMethod(String paymentMethod) { this.paymentMethod = paymentMethod; }
}

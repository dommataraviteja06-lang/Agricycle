package com.agricycle.dto;

import java.util.List;

public class BestUseRecommendationDto {
    private String materialName;
    private String cropOrigin;
    private List<UsageOption> recommendedUses;
    private List<String> targetBuyerTypes;
    private String disclaimer = "AI recommendations are estimated best practices based on agricultural agronomy and market demand. Not a commercial guarantee.";

    public static class UsageOption {
        private int rank;
        private String application;
        private String description;
        private String targetIndustry;
        private String economicValueTier; // High, Moderate, Standard

        public UsageOption() {}

        public UsageOption(int rank, String application, String description, String targetIndustry, String economicValueTier) {
            this.rank = rank;
            this.application = application;
            this.description = description;
            this.targetIndustry = targetIndustry;
            this.economicValueTier = economicValueTier;
        }

        public int getRank() { return rank; }
        public void setRank(int rank) { this.rank = rank; }

        public String getApplication() { return application; }
        public void setApplication(String application) { this.application = application; }

        public String getDescription() { return description; }
        public void setDescription(String description) { this.description = description; }

        public String getTargetIndustry() { return targetIndustry; }
        public void setTargetIndustry(String targetIndustry) { this.targetIndustry = targetIndustry; }

        public String getEconomicValueTier() { return economicValueTier; }
        public void setEconomicValueTier(String economicValueTier) { this.economicValueTier = economicValueTier; }
    }

    public BestUseRecommendationDto() {}

    public String getMaterialName() { return materialName; }
    public void setMaterialName(String materialName) { this.materialName = materialName; }

    public String getCropOrigin() { return cropOrigin; }
    public void setCropOrigin(String cropOrigin) { this.cropOrigin = cropOrigin; }

    public List<UsageOption> getRecommendedUses() { return recommendedUses; }
    public void setRecommendedUses(List<UsageOption> recommendedUses) { this.recommendedUses = recommendedUses; }

    public List<String> getTargetBuyerTypes() { return targetBuyerTypes; }
    public void setTargetBuyerTypes(List<String> targetBuyerTypes) { this.targetBuyerTypes = targetBuyerTypes; }

    public String getDisclaimer() { return disclaimer; }
    public void setDisclaimer(String disclaimer) { this.disclaimer = disclaimer; }
}

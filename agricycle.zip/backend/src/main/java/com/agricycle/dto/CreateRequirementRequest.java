package com.agricycle.dto;

import com.agricycle.entity.UrgencyLevel;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDate;

public class CreateRequirementRequest {

    private Long categoryId;

    @NotBlank(message = "Material name is required")
    private String materialName;

    @NotNull(message = "Quantity required is required")
    private Double quantityRequired;

    @NotBlank(message = "Unit is required")
    private String unit;

    private Double targetPrice;

    private String village;

    @NotBlank(message = "District is required")
    private String district;

    @NotBlank(message = "State is required")
    private String state;

    private LocalDate requiredByDate;

    // Fodder / Emergency specific
    private String animalType;
    private Integer numberOfAnimals;
    private Boolean emergency;
    private UrgencyLevel urgency;

    private String qualityRequirement;
    private String description;
    private String deliveryRequirement;

    public CreateRequirementRequest() {}

    public Long getCategoryId() { return categoryId; }
    public void setCategoryId(Long categoryId) { this.categoryId = categoryId; }

    public String getMaterialName() { return materialName; }
    public void setMaterialName(String materialName) { this.materialName = materialName; }

    public Double getQuantityRequired() { return quantityRequired; }
    public void setQuantityRequired(Double quantityRequired) { this.quantityRequired = quantityRequired; }

    public String getUnit() { return unit; }
    public void setUnit(String unit) { this.unit = unit; }

    public Double getTargetPrice() { return targetPrice; }
    public void setTargetPrice(Double targetPrice) { this.targetPrice = targetPrice; }

    public String getVillage() { return village; }
    public void setVillage(String village) { this.village = village; }

    public String getDistrict() { return district; }
    public void setDistrict(String district) { this.district = district; }

    public String getState() { return state; }
    public void setState(String state) { this.state = state; }

    public LocalDate getRequiredByDate() { return requiredByDate; }
    public void setRequiredByDate(LocalDate requiredByDate) { this.requiredByDate = requiredByDate; }

    public String getAnimalType() { return animalType; }
    public void setAnimalType(String animalType) { this.animalType = animalType; }

    public Integer getNumberOfAnimals() { return numberOfAnimals; }
    public void setNumberOfAnimals(Integer numberOfAnimals) { this.numberOfAnimals = numberOfAnimals; }

    public Boolean getEmergency() { return emergency; }
    public void setEmergency(Boolean emergency) { this.emergency = emergency; }

    public UrgencyLevel getUrgency() { return urgency; }
    public void setUrgency(UrgencyLevel urgency) { this.urgency = urgency; }

    public String getQualityRequirement() { return qualityRequirement; }
    public void setQualityRequirement(String qualityRequirement) { this.qualityRequirement = qualityRequirement; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getDeliveryRequirement() { return deliveryRequirement; }
    public void setDeliveryRequirement(String deliveryRequirement) { this.deliveryRequirement = deliveryRequirement; }
}

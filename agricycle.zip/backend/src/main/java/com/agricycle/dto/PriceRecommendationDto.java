package com.agricycle.dto;

public class PriceRecommendationDto {
    private String materialName;
    private Double suggestedMinPrice;
    private Double suggestedMaxPrice;
    private Double suggestedAveragePrice;
    private String unit;
    private String confidence; // Low, Medium, High
    private int sampleDataPoints;
    private String basisOfCalculation;
    private String note = "Suggested price based on internal platform transaction data and regional listings.";

    public PriceRecommendationDto() {}

    public PriceRecommendationDto(String materialName, Double suggestedMinPrice, Double suggestedMaxPrice, Double suggestedAveragePrice, String unit, String confidence, int sampleDataPoints, String basisOfCalculation) {
        this.materialName = materialName;
        this.suggestedMinPrice = suggestedMinPrice;
        this.suggestedMaxPrice = suggestedMaxPrice;
        this.suggestedAveragePrice = suggestedAveragePrice;
        this.unit = unit;
        this.confidence = confidence;
        this.sampleDataPoints = sampleDataPoints;
        this.basisOfCalculation = basisOfCalculation;
    }

    public String getMaterialName() { return materialName; }
    public void setMaterialName(String materialName) { this.materialName = materialName; }

    public Double getSuggestedMinPrice() { return suggestedMinPrice; }
    public void setSuggestedMinPrice(Double suggestedMinPrice) { this.suggestedMinPrice = suggestedMinPrice; }

    public Double getSuggestedMaxPrice() { return suggestedMaxPrice; }
    public void setSuggestedMaxPrice(Double suggestedMaxPrice) { this.suggestedMaxPrice = suggestedMaxPrice; }

    public Double getSuggestedAveragePrice() { return suggestedAveragePrice; }
    public void setSuggestedAveragePrice(Double suggestedAveragePrice) { this.suggestedAveragePrice = suggestedAveragePrice; }

    public String getUnit() { return unit; }
    public void setUnit(String unit) { this.unit = unit; }

    public String getConfidence() { return confidence; }
    public void setConfidence(String confidence) { this.confidence = confidence; }

    public int getSampleDataPoints() { return sampleDataPoints; }
    public void setSampleDataPoints(int sampleDataPoints) { this.sampleDataPoints = sampleDataPoints; }

    public String getBasisOfCalculation() { return basisOfCalculation; }
    public void setBasisOfCalculation(String basisOfCalculation) { this.basisOfCalculation = basisOfCalculation; }

    public String getNote() { return note; }
    public void setNote(String note) { this.note = note; }
}

package com.agricycle.dto;

import com.agricycle.entity.TransportStatus;
import jakarta.validation.constraints.NotNull;

public class UpdateTransportStatusRequest {

    @NotNull(message = "Transport status is required")
    private TransportStatus status;

    private String trackingNotes;

    public UpdateTransportStatusRequest() {}

    public UpdateTransportStatusRequest(TransportStatus status, String trackingNotes) {
        this.status = status;
        this.trackingNotes = trackingNotes;
    }

    public TransportStatus getStatus() { return status; }
    public void setStatus(TransportStatus status) { this.status = status; }

    public String getTrackingNotes() { return trackingNotes; }
    public void setTrackingNotes(String trackingNotes) { this.trackingNotes = trackingNotes; }
}

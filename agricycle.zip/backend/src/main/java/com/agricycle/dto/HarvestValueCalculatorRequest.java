package com.agricycle.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class HarvestValueCalculatorRequest {

    @NotBlank(message = "Crop name is required")
    private String cropName;

    @NotNull(message = "Total quantity is required")
    private Double totalQuantity;

    @NotBlank(message = "Unit is required")
    private String unit;

    private String district;

    public HarvestValueCalculatorRequest() {}

    public HarvestValueCalculatorRequest(String cropName, Double totalQuantity, String unit, String district) {
        this.cropName = cropName;
        this.totalQuantity = totalQuantity;
        this.unit = unit;
        this.district = district;
    }

    public String getCropName() { return cropName; }
    public void setCropName(String cropName) { this.cropName = cropName; }

    public Double getTotalQuantity() { return totalQuantity; }
    public void setTotalQuantity(Double totalQuantity) { this.totalQuantity = totalQuantity; }

    public String getUnit() { return unit; }
    public void setUnit(String unit) { this.unit = unit; }

    public String getDistrict() { return district; }
    public void setDistrict(String district) { this.district = district; }
}

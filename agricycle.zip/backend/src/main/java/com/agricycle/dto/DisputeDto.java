package com.agricycle.dto;

import com.agricycle.entity.DisputeStatus;
import java.time.LocalDateTime;

public class DisputeDto {
    private Long id;
    private Long orderId;
    private String orderNumber;
    private Long raisedByUserId;
    private String raisedByUserName;
    private String reason;
    private String description;
    private DisputeStatus status;
    private String resolutionNotes;
    private String resolvedByAdminName;
    private LocalDateTime createdAt;
    private LocalDateTime resolvedAt;

    public DisputeDto() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getOrderId() { return orderId; }
    public void setOrderId(Long orderId) { this.orderId = orderId; }

    public String getOrderNumber() { return orderNumber; }
    public void setOrderNumber(String orderNumber) { this.orderNumber = orderNumber; }

    public Long getRaisedByUserId() { return raisedByUserId; }
    public void setRaisedByUserId(Long raisedByUserId) { this.raisedByUserId = raisedByUserId; }

    public String getRaisedByUserName() { return raisedByUserName; }
    public void setRaisedByUserName(String raisedByUserName) { this.raisedByUserName = raisedByUserName; }

    public String getReason() { return reason; }
    public void setReason(String reason) { this.reason = reason; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public DisputeStatus getStatus() { return status; }
    public void setStatus(DisputeStatus status) { this.status = status; }

    public String getResolutionNotes() { return resolutionNotes; }
    public void setResolutionNotes(String resolutionNotes) { this.resolutionNotes = resolutionNotes; }

    public String getResolvedByAdminName() { return resolvedByAdminName; }
    public void setResolvedByAdminName(String resolvedByAdminName) { this.resolvedByAdminName = resolvedByAdminName; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public LocalDateTime getResolvedAt() { return resolvedAt; }
    public void setResolvedAt(LocalDateTime resolvedAt) { this.resolvedAt = resolvedAt; }
}

package com.agricycle.dto;

import com.agricycle.entity.VerificationStatus;
import java.time.LocalDateTime;

public class LivestockProfileDto {
    private Long id;
    private Long userId;
    private String fullName;
    private String mobile;
    private String animalType;
    private Integer numberOfAnimals;
    private String feedPreference;
    private String village;
    private String district;
    private String state;
    private String requiredFodderTypes;
    private VerificationStatus verificationStatus;
    private LocalDateTime createdAt;

    public LivestockProfileDto() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }

    public String getMobile() { return mobile; }
    public void setMobile(String mobile) { this.mobile = mobile; }

    public String getAnimalType() { return animalType; }
    public void setAnimalType(String animalType) { this.animalType = animalType; }

    public Integer getNumberOfAnimals() { return numberOfAnimals; }
    public void setNumberOfAnimals(Integer numberOfAnimals) { this.numberOfAnimals = numberOfAnimals; }

    public String getFeedPreference() { return feedPreference; }
    public void setFeedPreference(String feedPreference) { this.feedPreference = feedPreference; }

    public String getVillage() { return village; }
    public void setVillage(String village) { this.village = village; }

    public String getDistrict() { return district; }
    public void setDistrict(String district) { this.district = district; }

    public String getState() { return state; }
    public void setState(String state) { this.state = state; }

    public String getRequiredFodderTypes() { return requiredFodderTypes; }
    public void setRequiredFodderTypes(String requiredFodderTypes) { this.requiredFodderTypes = requiredFodderTypes; }

    public VerificationStatus getVerificationStatus() { return verificationStatus; }
    public void setVerificationStatus(VerificationStatus verificationStatus) { this.verificationStatus = verificationStatus; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}

package com.agricycle.dto;

import com.agricycle.entity.OrderNegotiation.NegotiationStatus;
import java.time.LocalDate;
import java.time.LocalDateTime;

public class OrderNegotiationDto {
    private Long id;
    private Long orderId;
    private Long proposedByUserId;
    private String proposedByUserName;
    private Double proposedPrice;
    private Double proposedQuantity;
    private LocalDate proposedDeliveryDate;
    private String notes;
    private NegotiationStatus status;
    private LocalDateTime createdAt;

    public OrderNegotiationDto() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getOrderId() { return orderId; }
    public void setOrderId(Long orderId) { this.orderId = orderId; }

    public Long getProposedByUserId() { return proposedByUserId; }
    public void setProposedByUserId(Long proposedByUserId) { this.proposedByUserId = proposedByUserId; }

    public String getProposedByUserName() { return proposedByUserName; }
    public void setProposedByUserName(String proposedByUserName) { this.proposedByUserName = proposedByUserName; }

    public Double getProposedPrice() { return proposedPrice; }
    public void setProposedPrice(Double proposedPrice) { this.proposedPrice = proposedPrice; }

    public Double getProposedQuantity() { return proposedQuantity; }
    public void setProposedQuantity(Double proposedQuantity) { this.proposedQuantity = proposedQuantity; }

    public LocalDate getProposedDeliveryDate() { return proposedDeliveryDate; }
    public void setProposedDeliveryDate(LocalDate proposedDeliveryDate) { this.proposedDeliveryDate = proposedDeliveryDate; }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }

    public NegotiationStatus getStatus() { return status; }
    public void setStatus(NegotiationStatus status) { this.status = status; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}

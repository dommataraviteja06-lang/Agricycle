package com.agricycle.dto;

public class EnvironmentalImpactDto {
    private Double totalResidueListedTons;
    private Double residueReusedTons;
    private Double fodderDistributedTons;
    private Long farmersBenefited;
    private Long livestockRequestsFulfilled;
    private Double industrialBioMaterialTons;
    private Double estimatedStubbleBurningAvoidedTons;
    private Double estimatedCo2MitigatedTons;
    private String methodologyNote = "Calculations derived from completed transaction volume on platform: 1 ton agricultural residue diverted from open-field burning mitigates ~1.46 tons CO2 equivalent and reduces particulate matter PM2.5/PM10 emission based on ICAR & IPCC stubble combustion emission factors. Values are transparent operational estimates.";

    public EnvironmentalImpactDto() {}

    public Double getTotalResidueListedTons() { return totalResidueListedTons; }
    public void setTotalResidueListedTons(Double totalResidueListedTons) { this.totalResidueListedTons = totalResidueListedTons; }

    public Double getResidueReusedTons() { return residueReusedTons; }
    public void setResidueReusedTons(Double residueReusedTons) { this.residueReusedTons = residueReusedTons; }

    public Double getFodderDistributedTons() { return fodderDistributedTons; }
    public void setFodderDistributedTons(Double fodderDistributedTons) { this.fodderDistributedTons = fodderDistributedTons; }

    public Long getFarmersBenefited() { return farmersBenefited; }
    public void setFarmersBenefited(Long farmersBenefited) { this.farmersBenefited = farmersBenefited; }

    public Long getLivestockRequestsFulfilled() { return livestockRequestsFulfilled; }
    public void setLivestockRequestsFulfilled(Long livestockRequestsFulfilled) { this.livestockRequestsFulfilled = livestockRequestsFulfilled; }

    public Double getIndustrialBioMaterialTons() { return industrialBioMaterialTons; }
    public void setIndustrialBioMaterialTons(Double industrialBioMaterialTons) { this.industrialBioMaterialTons = industrialBioMaterialTons; }

    public Double getEstimatedStubbleBurningAvoidedTons() { return estimatedStubbleBurningAvoidedTons; }
    public void setEstimatedStubbleBurningAvoidedTons(Double estimatedStubbleBurningAvoidedTons) { this.estimatedStubbleBurningAvoidedTons = estimatedStubbleBurningAvoidedTons; }

    public Double getEstimatedCo2MitigatedTons() { return estimatedCo2MitigatedTons; }
    public void setEstimatedCo2MitigatedTons(Double estimatedCo2MitigatedTons) { this.estimatedCo2MitigatedTons = estimatedCo2MitigatedTons; }

    public String getMethodologyNote() { return methodologyNote; }
    public void setMethodologyNote(String methodologyNote) { this.methodologyNote = methodologyNote; }
}

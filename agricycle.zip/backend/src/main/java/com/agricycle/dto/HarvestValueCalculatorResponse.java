package com.agricycle.dto;

public class HarvestValueCalculatorResponse {
    private String cropName;
    private Double totalQuantity;
    private String unit;
    private String district;

    // Component opportunities
    private String mainCropProduct;
    private Double mainCropYield;
    private Double mainCropPricePerUnit;
    private Double mainCropEstimatedValue;

    private String fodderProduct;
    private Double fodderYield;
    private Double fodderPricePerUnit;
    private Double fodderEstimatedValue;

    private String residueProduct;
    private Double residueYield;
    private Double residuePricePerUnit;
    private Double residueEstimatedValue;

    // Totals & uplift
    private Double traditionalSingleSaleValue; // Only main crop
    private Double estimatedTotalRecoveryValue; // Main + Fodder + Residue
    private Double additionalIncomePotential; // Fodder + Residue
    private Double percentageIncomeBoost;

    private String calculationNote = "Estimated value. Actual selling price may vary based on quality, moisture content, local market dynamics, and logistics.";

    public HarvestValueCalculatorResponse() {}

    // Getters and Setters
    public String getCropName() { return cropName; }
    public void setCropName(String cropName) { this.cropName = cropName; }

    public Double getTotalQuantity() { return totalQuantity; }
    public void setTotalQuantity(Double totalQuantity) { this.totalQuantity = totalQuantity; }

    public String getUnit() { return unit; }
    public void setUnit(String unit) { this.unit = unit; }

    public String getDistrict() { return district; }
    public void setDistrict(String district) { this.district = district; }

    public String getMainCropProduct() { return mainCropProduct; }
    public void setMainCropProduct(String mainCropProduct) { this.mainCropProduct = mainCropProduct; }

    public Double getMainCropYield() { return mainCropYield; }
    public void setMainCropYield(Double mainCropYield) { this.mainCropYield = mainCropYield; }

    public Double getMainCropPricePerUnit() { return mainCropPricePerUnit; }
    public void setMainCropPricePerUnit(Double mainCropPricePerUnit) { this.mainCropPricePerUnit = mainCropPricePerUnit; }

    public Double getMainCropEstimatedValue() { return mainCropEstimatedValue; }
    public void setMainCropEstimatedValue(Double mainCropEstimatedValue) { this.mainCropEstimatedValue = mainCropEstimatedValue; }

    public String getFodderProduct() { return fodderProduct; }
    public void setFodderProduct(String fodderProduct) { this.fodderProduct = fodderProduct; }

    public Double getFodderYield() { return fodderYield; }
    public void setFodderYield(Double fodderYield) { this.fodderYield = fodderYield; }

    public Double getFodderPricePerUnit() { return fodderPricePerUnit; }
    public void setFodderPricePerUnit(Double fodderPricePerUnit) { this.fodderPricePerUnit = fodderPricePerUnit; }

    public Double getFodderEstimatedValue() { return fodderEstimatedValue; }
    public void setFodderEstimatedValue(Double fodderEstimatedValue) { this.fodderEstimatedValue = fodderEstimatedValue; }

    public String getResidueProduct() { return residueProduct; }
    public void setResidueProduct(String residueProduct) { this.residueProduct = residueProduct; }

    public Double getResidueYield() { return residueYield; }
    public void setResidueYield(Double residueYield) { this.residueYield = residueYield; }

    public Double getResiduePricePerUnit() { return residuePricePerUnit; }
    public void setResiduePricePerUnit(Double residuePricePerUnit) { this.residuePricePerUnit = residuePricePerUnit; }

    public Double getResidueEstimatedValue() { return residueEstimatedValue; }
    public void setResidueEstimatedValue(Double residueEstimatedValue) { this.residueEstimatedValue = residueEstimatedValue; }

    public Double getTraditionalSingleSaleValue() { return traditionalSingleSaleValue; }
    public void setTraditionalSingleSaleValue(Double traditionalSingleSaleValue) { this.traditionalSingleSaleValue = traditionalSingleSaleValue; }

    public Double getEstimatedTotalRecoveryValue() { return estimatedTotalRecoveryValue; }
    public void setEstimatedTotalRecoveryValue(Double estimatedTotalRecoveryValue) { this.estimatedTotalRecoveryValue = estimatedTotalRecoveryValue; }

    public Double getAdditionalIncomePotential() { return additionalIncomePotential; }
    public void setAdditionalIncomePotential(Double additionalIncomePotential) { this.additionalIncomePotential = additionalIncomePotential; }

    public Double getPercentageIncomeBoost() { return percentageIncomeBoost; }
    public void setPercentageIncomeBoost(Double percentageIncomeBoost) { this.percentageIncomeBoost = percentageIncomeBoost; }

    public String getCalculationNote() { return calculationNote; }
    public void setCalculationNote(String calculationNote) { this.calculationNote = calculationNote; }
}

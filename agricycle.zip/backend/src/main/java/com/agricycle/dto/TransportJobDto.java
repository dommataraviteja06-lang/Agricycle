package com.agricycle.dto;

import com.agricycle.entity.TransportStatus;
import java.time.LocalDateTime;

public class TransportJobDto {
    private Long id;
    private Long orderId;
    private String orderNumber;
    private Long transporterId;
    private String transporterName;
    private String transporterMobile;
    private String pickupLocation;
    private String pickupDistrict;
    private String deliveryLocation;
    private String deliveryDistrict;
    private Double weightTons;
    private String vehicleTypeRequired;
    private Double agreedFare;
    private TransportStatus status;
    private boolean sharedTransport;
    private String trackingNotes;
    private LocalDateTime assignedAt;
    private LocalDateTime pickedUpAt;
    private LocalDateTime deliveredAt;
    private LocalDateTime createdAt;

    public TransportJobDto() {}

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getOrderId() { return orderId; }
    public void setOrderId(Long orderId) { this.orderId = orderId; }

    public String getOrderNumber() { return orderNumber; }
    public void setOrderNumber(String orderNumber) { this.orderNumber = orderNumber; }

    public Long getTransporterId() { return transporterId; }
    public void setTransporterId(Long transporterId) { this.transporterId = transporterId; }

    public String getTransporterName() { return transporterName; }
    public void setTransporterName(String transporterName) { this.transporterName = transporterName; }

    public String getTransporterMobile() { return transporterMobile; }
    public void setTransporterMobile(String transporterMobile) { this.transporterMobile = transporterMobile; }

    public String getPickupLocation() { return pickupLocation; }
    public void setPickupLocation(String pickupLocation) { this.pickupLocation = pickupLocation; }

    public String getPickupDistrict() { return pickupDistrict; }
    public void setPickupDistrict(String pickupDistrict) { this.pickupDistrict = pickupDistrict; }

    public String getDeliveryLocation() { return deliveryLocation; }
    public void setDeliveryLocation(String deliveryLocation) { this.deliveryLocation = deliveryLocation; }

    public String getDeliveryDistrict() { return deliveryDistrict; }
    public void setDeliveryDistrict(String deliveryDistrict) { this.deliveryDistrict = deliveryDistrict; }

    public Double getWeightTons() { return weightTons; }
    public void setWeightTons(Double weightTons) { this.weightTons = weightTons; }

    public String getVehicleTypeRequired() { return vehicleTypeRequired; }
    public void setVehicleTypeRequired(String vehicleTypeRequired) { this.vehicleTypeRequired = vehicleTypeRequired; }

    public Double getAgreedFare() { return agreedFare; }
    public void setAgreedFare(Double agreedFare) { this.agreedFare = agreedFare; }

    public TransportStatus getStatus() { return status; }
    public void setStatus(TransportStatus status) { this.status = status; }

    public boolean isSharedTransport() { return sharedTransport; }
    public void setSharedTransport(boolean sharedTransport) { this.sharedTransport = sharedTransport; }

    public String getTrackingNotes() { return trackingNotes; }
    public void setTrackingNotes(String trackingNotes) { this.trackingNotes = trackingNotes; }

    public LocalDateTime getAssignedAt() { return assignedAt; }
    public void setAssignedAt(LocalDateTime assignedAt) { this.assignedAt = assignedAt; }

    public LocalDateTime getPickedUpAt() { return pickedUpAt; }
    public void setPickedUpAt(LocalDateTime pickedUpAt) { this.pickedUpAt = pickedUpAt; }

    public LocalDateTime getDeliveredAt() { return deliveredAt; }
    public void setDeliveredAt(LocalDateTime deliveredAt) { this.deliveredAt = deliveredAt; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}

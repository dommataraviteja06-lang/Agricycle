package com.agricycle.dto;

import com.agricycle.entity.RequirementOffer.OfferStatus;
import java.time.LocalDate;
import java.time.LocalDateTime;

public class RequirementOfferDto {
    private Long id;
    private Long requirementId;
    private String materialName;
    private Long supplierId;
    private String supplierName;
    private String supplierMobile;
    private Double offeredQuantity;
    private Double pricePerUnit;
    private Double totalPrice;
    private LocalDate proposedDeliveryDate;
    private String notes;
    private OfferStatus status;
    private LocalDateTime createdAt;

    public RequirementOfferDto() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getRequirementId() { return requirementId; }
    public void setRequirementId(Long requirementId) { this.requirementId = requirementId; }

    public String getMaterialName() { return materialName; }
    public void setMaterialName(String materialName) { this.materialName = materialName; }

    public Long getSupplierId() { return supplierId; }
    public void setSupplierId(Long supplierId) { this.supplierId = supplierId; }

    public String getSupplierName() { return supplierName; }
    public void setSupplierName(String supplierName) { this.supplierName = supplierName; }

    public String getSupplierMobile() { return supplierMobile; }
    public void setSupplierMobile(String supplierMobile) { this.supplierMobile = supplierMobile; }

    public Double getOfferedQuantity() { return offeredQuantity; }
    public void setOfferedQuantity(Double offeredQuantity) {
        this.offeredQuantity = offeredQuantity;
        recalculateTotal();
    }

    public Double getPricePerUnit() { return pricePerUnit; }
    public void setPricePerUnit(Double pricePerUnit) {
        this.pricePerUnit = pricePerUnit;
        recalculateTotal();
    }

    public Double getTotalPrice() { return totalPrice; }
    public void setTotalPrice(Double totalPrice) { this.totalPrice = totalPrice; }

    private void recalculateTotal() {
        if (this.offeredQuantity != null && this.pricePerUnit != null) {
            this.totalPrice = this.offeredQuantity * this.pricePerUnit;
        }
    }

    public LocalDate getProposedDeliveryDate() { return proposedDeliveryDate; }
    public void setProposedDeliveryDate(LocalDate proposedDeliveryDate) { this.proposedDeliveryDate = proposedDeliveryDate; }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }

    public OfferStatus getStatus() { return status; }
    public void setStatus(OfferStatus status) { this.status = status; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}

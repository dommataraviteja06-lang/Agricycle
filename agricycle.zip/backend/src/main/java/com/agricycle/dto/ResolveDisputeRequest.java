package com.agricycle.dto;

import com.agricycle.entity.DisputeStatus;
import jakarta.validation.constraints.NotNull;

public class ResolveDisputeRequest {

    @NotNull(message = "Status is required")
    private DisputeStatus status;

    private String resolutionNotes;

    public ResolveDisputeRequest() {}

    public ResolveDisputeRequest(DisputeStatus status, String resolutionNotes) {
        this.status = status;
        this.resolutionNotes = resolutionNotes;
    }

    public DisputeStatus getStatus() { return status; }
    public void setStatus(DisputeStatus status) { this.status = status; }

    public String getResolutionNotes() { return resolutionNotes; }
    public void setResolutionNotes(String resolutionNotes) { this.resolutionNotes = resolutionNotes; }
}

package com.agricycle.dto;

import com.agricycle.entity.CategoryType;
import com.agricycle.entity.ListingStatus;
import com.agricycle.entity.VerificationStatus;
import java.time.LocalDate;
import java.time.LocalDateTime;

public class ListingDto {
    private Long id;
    private Long sellerId;
    private String sellerName;
    private VerificationStatus sellerVerificationStatus;
    private Double sellerRating;
    private Long sellerReviewsCount;
    private Long harvestId;
    private String harvestCropName;
    private LocalDate harvestDate;
    private Long categoryId;
    private String categoryName;
    private CategoryType categoryType;
    private String title;
    private String productMaterialName;
    private Double quantity;
    private Double availableQuantity;
    private String unit;
    private Double pricePerUnit;
    private String village;
    private String district;
    private String state;
    private Double latitude;
    private Double longitude;
    private String lotId;
    private String imagesJson;
    private String description;
    private String suitableUse;
    private ListingStatus listingStatus;
    private VerificationStatus verificationStatus;
    private int viewCount;
    private LocalDateTime createdAt;

    public ListingDto() {}

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getSellerId() { return sellerId; }
    public void setSellerId(Long sellerId) { this.sellerId = sellerId; }

    public String getSellerName() { return sellerName; }
    public void setSellerName(String sellerName) { this.sellerName = sellerName; }

    public VerificationStatus getSellerVerificationStatus() { return sellerVerificationStatus; }
    public void setSellerVerificationStatus(VerificationStatus sellerVerificationStatus) { this.sellerVerificationStatus = sellerVerificationStatus; }

    public Double getSellerRating() { return sellerRating; }
    public void setSellerRating(Double sellerRating) { this.sellerRating = sellerRating; }

    public Long getSellerReviewsCount() { return sellerReviewsCount; }
    public void setSellerReviewsCount(Long sellerReviewsCount) { this.sellerReviewsCount = sellerReviewsCount; }

    public Long getHarvestId() { return harvestId; }
    public void setHarvestId(Long harvestId) { this.harvestId = harvestId; }

    public String getHarvestCropName() { return harvestCropName; }
    public void setHarvestCropName(String harvestCropName) { this.harvestCropName = harvestCropName; }

    public LocalDate getHarvestDate() { return harvestDate; }
    public void setHarvestDate(LocalDate harvestDate) { this.harvestDate = harvestDate; }

    public Long getCategoryId() { return categoryId; }
    public void setCategoryId(Long categoryId) { this.categoryId = categoryId; }

    public String getCategoryName() { return categoryName; }
    public void setCategoryName(String categoryName) { this.categoryName = categoryName; }

    public CategoryType getCategoryType() { return categoryType; }
    public void setCategoryType(CategoryType categoryType) { this.categoryType = categoryType; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getProductMaterialName() { return productMaterialName; }
    public void setProductMaterialName(String productMaterialName) { this.productMaterialName = productMaterialName; }

    public Double getQuantity() { return quantity; }
    public void setQuantity(Double quantity) { this.quantity = quantity; }

    public Double getAvailableQuantity() { return availableQuantity; }
    public void setAvailableQuantity(Double availableQuantity) { this.availableQuantity = availableQuantity; }

    public String getUnit() { return unit; }
    public void setUnit(String unit) { this.unit = unit; }

    public Double getPricePerUnit() { return pricePerUnit; }
    public void setPricePerUnit(Double pricePerUnit) { this.pricePerUnit = pricePerUnit; }

    public String getVillage() { return village; }
    public void setVillage(String village) { this.village = village; }

    public String getDistrict() { return district; }
    public void setDistrict(String district) { this.district = district; }

    public String getState() { return state; }
    public void setState(String state) { this.state = state; }

    public Double getLatitude() { return latitude; }
    public void setLatitude(Double latitude) { this.latitude = latitude; }

    public Double getLongitude() { return longitude; }
    public void setLongitude(Double longitude) { this.longitude = longitude; }

    public String getLotId() { return lotId; }
    public void setLotId(String lotId) { this.lotId = lotId; }

    public String getImagesJson() { return imagesJson; }
    public void setImagesJson(String imagesJson) { this.imagesJson = imagesJson; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getSuitableUse() { return suitableUse; }
    public void setSuitableUse(String suitableUse) { this.suitableUse = suitableUse; }

    public ListingStatus getListingStatus() { return listingStatus; }
    public void setListingStatus(ListingStatus listingStatus) { this.listingStatus = listingStatus; }

    public VerificationStatus getVerificationStatus() { return verificationStatus; }
    public void setVerificationStatus(VerificationStatus verificationStatus) { this.verificationStatus = verificationStatus; }

    public int getViewCount() { return viewCount; }
    public void setViewCount(int viewCount) { this.viewCount = viewCount; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}

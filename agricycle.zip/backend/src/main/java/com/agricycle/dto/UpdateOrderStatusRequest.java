package com.agricycle.dto;

import com.agricycle.entity.OrderStatus;
import jakarta.validation.constraints.NotNull;

public class UpdateOrderStatusRequest {

    @NotNull(message = "Status is required")
    private OrderStatus status;

    private String note;

    public UpdateOrderStatusRequest() {}

    public UpdateOrderStatusRequest(OrderStatus status, String note) {
        this.status = status;
        this.note = note;
    }

    public OrderStatus getStatus() { return status; }
    public void setStatus(OrderStatus status) { this.status = status; }

    public String getNote() { return note; }
    public void setNote(String note) { this.note = note; }
}

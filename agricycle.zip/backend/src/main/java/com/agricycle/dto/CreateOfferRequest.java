package com.agricycle.dto;

import jakarta.validation.constraints.NotNull;
import java.time.LocalDate;

public class CreateOfferRequest {

    @NotNull(message = "Requirement ID is required")
    private Long requirementId;

    @NotNull(message = "Offered quantity is required")
    private Double offeredQuantity;

    @NotNull(message = "Price per unit is required")
    private Double pricePerUnit;

    private LocalDate proposedDeliveryDate;
    private String notes;

    public CreateOfferRequest() {}

    public Long getRequirementId() { return requirementId; }
    public void setRequirementId(Long requirementId) { this.requirementId = requirementId; }

    public Double getOfferedQuantity() { return offeredQuantity; }
    public void setOfferedQuantity(Double offeredQuantity) { this.offeredQuantity = offeredQuantity; }

    public Double getPricePerUnit() { return pricePerUnit; }
    public void setPricePerUnit(Double pricePerUnit) { this.pricePerUnit = pricePerUnit; }

    public LocalDate getProposedDeliveryDate() { return proposedDeliveryDate; }
    public void setProposedDeliveryDate(LocalDate proposedDeliveryDate) { this.proposedDeliveryDate = proposedDeliveryDate; }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }
}

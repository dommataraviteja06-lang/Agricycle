package com.agricycle.dto;

public class AdminStatsDto {
    private long totalUsers;
    private long farmersCount;
    private long livestockOwnersCount;
    private long companiesCount;
    private long transportersCount;
    private long activeListingsCount;
    private long pendingApprovalListingsCount;
    private long totalOrdersCount;
    private long completedOrdersCount;
    private long activeTransportJobsCount;
    private long openRequirementsCount;
    private long openDisputesCount;
    private Double totalPlatformVolumeTons;
    private Double totalPlatformEarningsInr;
    private Double totalResidueDivertedTons;

    public AdminStatsDto() {}

    // Getters and Setters
    public long getTotalUsers() { return totalUsers; }
    public void setTotalUsers(long totalUsers) { this.totalUsers = totalUsers; }

    public long getFarmersCount() { return farmersCount; }
    public void setFarmersCount(long farmersCount) { this.farmersCount = farmersCount; }

    public long getLivestockOwnersCount() { return livestockOwnersCount; }
    public void setLivestockOwnersCount(long livestockOwnersCount) { this.livestockOwnersCount = livestockOwnersCount; }

    public long getCompaniesCount() { return companiesCount; }
    public void setCompaniesCount(long companiesCount) { this.companiesCount = companiesCount; }

    public long getTransportersCount() { return transportersCount; }
    public void setTransportersCount(long transportersCount) { this.transportersCount = transportersCount; }

    public long getActiveListingsCount() { return activeListingsCount; }
    public void setActiveListingsCount(long activeListingsCount) { this.activeListingsCount = activeListingsCount; }

    public long getPendingApprovalListingsCount() { return pendingApprovalListingsCount; }
    public void setPendingApprovalListingsCount(long pendingApprovalListingsCount) { this.pendingApprovalListingsCount = pendingApprovalListingsCount; }

    public long getTotalOrdersCount() { return totalOrdersCount; }
    public void setTotalOrdersCount(long totalOrdersCount) { this.totalOrdersCount = totalOrdersCount; }

    public long getCompletedOrdersCount() { return completedOrdersCount; }
    public void setCompletedOrdersCount(long completedOrdersCount) { this.completedOrdersCount = completedOrdersCount; }

    public long getActiveTransportJobsCount() { return activeTransportJobsCount; }
    public void setActiveTransportJobsCount(long activeTransportJobsCount) { this.activeTransportJobsCount = activeTransportJobsCount; }

    public long getOpenRequirementsCount() { return openRequirementsCount; }
    public void setOpenRequirementsCount(long openRequirementsCount) { this.openRequirementsCount = openRequirementsCount; }

    public long getOpenDisputesCount() { return openDisputesCount; }
    public void setOpenDisputesCount(long openDisputesCount) { this.openDisputesCount = openDisputesCount; }

    public Double getTotalPlatformVolumeTons() { return totalPlatformVolumeTons; }
    public void setTotalPlatformVolumeTons(Double totalPlatformVolumeTons) { this.totalPlatformVolumeTons = totalPlatformVolumeTons; }

    public Double getTotalPlatformEarningsInr() { return totalPlatformEarningsInr; }
    public void setTotalPlatformEarningsInr(Double totalPlatformEarningsInr) { this.totalPlatformEarningsInr = totalPlatformEarningsInr; }

    public Double getTotalResidueDivertedTons() { return totalResidueDivertedTons; }
    public void setTotalResidueDivertedTons(Double totalResidueDivertedTons) { this.totalResidueDivertedTons = totalResidueDivertedTons; }
}

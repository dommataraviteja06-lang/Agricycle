package com.agricycle.config;

import com.agricycle.entity.*;
import com.agricycle.repository.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

@Component
public class DataInitializer implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(DataInitializer.class);

    private final UserRepository userRepository;
    private final FarmerProfileRepository farmerProfileRepository;
    private final LivestockProfileRepository livestockProfileRepository;
    private final CompanyProfileRepository companyProfileRepository;
    private final TransportProfileRepository transportProfileRepository;
    private final VehicleRepository vehicleRepository;
    private final CategoryRepository categoryRepository;
    private final HarvestRepository harvestRepository;
    private final ListingRepository listingRepository;
    private final RequirementRepository requirementRepository;
    private final RequirementOfferRepository requirementOfferRepository;
    private final OrderRepository orderRepository;
    private final OrderItemRepository orderItemRepository;
    private final TransportJobRepository transportJobRepository;
    private final PaymentRepository paymentRepository;
    private final ReviewRepository reviewRepository;
    private final OrderNegotiationRepository orderNegotiationRepository;
    private final PasswordEncoder passwordEncoder;

    @Value("${app.admin.email:admin@agricycle.com}")
    private String adminEmail;

    @Value("${app.admin.password:Admin@AgriCycle2026!}")
    private String adminPassword;

    @Value("${app.admin.full-name:AgriCycle Super Administrator}")
    private String adminFullName;

    @Value("${app.admin.mobile:9876543210}")
    private String adminMobile;

    public DataInitializer(UserRepository userRepository,
                           FarmerProfileRepository farmerProfileRepository,
                           LivestockProfileRepository livestockProfileRepository,
                           CompanyProfileRepository companyProfileRepository,
                           TransportProfileRepository transportProfileRepository,
                           VehicleRepository vehicleRepository,
                           CategoryRepository categoryRepository,
                           HarvestRepository harvestRepository,
                           ListingRepository listingRepository,
                           RequirementRepository requirementRepository,
                           RequirementOfferRepository requirementOfferRepository,
                           OrderRepository orderRepository,
                           OrderItemRepository orderItemRepository,
                           TransportJobRepository transportJobRepository,
                           PaymentRepository paymentRepository,
                           ReviewRepository reviewRepository,
                           OrderNegotiationRepository orderNegotiationRepository,
                           PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.farmerProfileRepository = farmerProfileRepository;
        this.livestockProfileRepository = livestockProfileRepository;
        this.companyProfileRepository = companyProfileRepository;
        this.transportProfileRepository = transportProfileRepository;
        this.vehicleRepository = vehicleRepository;
        this.categoryRepository = categoryRepository;
        this.harvestRepository = harvestRepository;
        this.listingRepository = listingRepository;
        this.requirementRepository = requirementRepository;
        this.requirementOfferRepository = requirementOfferRepository;
        this.orderRepository = orderRepository;
        this.orderItemRepository = orderItemRepository;
        this.transportJobRepository = transportJobRepository;
        this.paymentRepository = paymentRepository;
        this.reviewRepository = reviewRepository;
        this.orderNegotiationRepository = orderNegotiationRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    @Transactional
    public void run(String... args) {
        log.info("Checking AgriCycle database state...");

        // 1. Initialize Super Admin if not present
        bootstrapSuperAdmin();

        // 2. Initialize Categories if not present
        bootstrapCategories();

        // 3. Initialize Sample Data if database is fresh
        if (userRepository.count() <= 1) {
            log.info("Seeding rich realistic sample dataset for Telangana & Andhra Pradesh...");
            bootstrapSampleData();
        } else {
            log.info("Database already contains data ({} users). Skipping sample data seeding.", userRepository.count());
        }
    }

    private void bootstrapSuperAdmin() {
        if (!userRepository.existsByEmail(adminEmail)) {
            User admin = new User(
                    adminEmail,
                    passwordEncoder.encode(adminPassword),
                    adminFullName,
                    adminMobile,
                    Role.ROLE_ADMIN,
                    UserStatus.ACTIVE
            );
            userRepository.save(admin);
            log.info("Super Admin bootstrapped successfully: {}", adminEmail);
        }
    }

    private void bootstrapCategories() {
        if (categoryRepository.count() == 0) {
            List<Category> categories = Arrays.asList(
                    // Harvest Products
                    new Category("Paddy / Rice Grain", "paddy-rice-grain", CategoryType.HARVEST_PRODUCT, "Commercial grade food grain directly from paddy harvest", "bi-grain", true),
                    new Category("Milling Wheat", "milling-wheat", CategoryType.HARVEST_PRODUCT, "Standard milling and durum wheat grain", "bi-basket", true),
                    new Category("Yellow Maize Grain", "yellow-maize-grain", CategoryType.HARVEST_PRODUCT, "Corn grains for human consumption and poultry feed", "bi-flower1", true),
                    new Category("Raw Seed Cotton", "raw-seed-cotton", CategoryType.HARVEST_PRODUCT, "Medium and long staple cotton for textile mills", "bi-cloud", true),
                    new Category("Sugarcane Stalks", "sugarcane-stalks", CategoryType.HARVEST_PRODUCT, "Fresh sugarcane stalks for commercial crushing", "bi-water", true),
                    new Category("Groundnut Pods", "groundnut-pods", CategoryType.HARVEST_PRODUCT, "Oil-rich groundnut kernels and whole pods", "bi-sun", true),
                    new Category("Red Gram / Pulses", "red-gram-pulses", CategoryType.HARVEST_PRODUCT, "High protein dal pulses and legumes", "bi-layers", true),

                    // Fodder
                    new Category("Paddy / Rice Straw", "paddy-rice-straw", CategoryType.FODDER, "Sun-dried nutritious straw bales for cattle and buffaloes", "bi-box-seam", true),
                    new Category("Chopped Wheat Straw (Turi)", "chopped-wheat-straw", CategoryType.FODDER, "Fine golden straw roughage highly preferred by dairy farmers", "bi-brightness-high", true),
                    new Category("Green Maize Stover", "green-maize-stover", CategoryType.FODDER, "Juicy carbohydrate-rich green fodder for livestock", "bi-tree", true),
                    new Category("Hybrid Napier Grass", "hybrid-napier-grass", CategoryType.FODDER, "Perennial green fodder grass with high crude protein", "bi-moisture", true),
                    new Category("Corn Silage (Fermented)", "corn-silage", CategoryType.FODDER, "Nutrient-dense preserved silage in sealed bales/drums", "bi-archive", true),
                    new Category("Sorghum / Jowar Fodder", "sorghum-jowar-fodder", CategoryType.FODDER, "Drought-hardy nutrient-rich fodder for goats and sheep", "bi-wind", true),

                    // Agricultural Residue
                    new Category("Rice Husk (Boiler Biofuel)", "rice-husk", CategoryType.AGRICULTURAL_RESIDUE, "Dense dry hull with high calorific value for industrial boilers", "bi-fire", true),
                    new Category("Sugarcane Bagasse", "sugarcane-bagasse", CategoryType.AGRICULTURAL_RESIDUE, "Fibrous pulp for paper, tableware, and thermal cogeneration", "bi-recycle", true),
                    new Category("Cotton Stalks (Biomass)", "cotton-stalks", CategoryType.AGRICULTURAL_RESIDUE, "Woody agricultural stems for particle boards and bio-briquettes", "bi-tree-fill", true),
                    new Category("Maize Cob Bio-Residue", "maize-cob-bio-residue", CategoryType.AGRICULTURAL_RESIDUE, "Dense biomass cobs for charcoal briquettes and gasifiers", "bi-grid", true),
                    new Category("Groundnut Shells", "groundnut-shells", CategoryType.AGRICULTURAL_RESIDUE, "Lignocellulosic shells for biomass boilers and activated carbon", "bi-circle", true),
                    new Category("Biochar & Carbon Residue", "biochar-carbon-residue", CategoryType.AGRICULTURAL_RESIDUE, "Slow-pyrolysis biochar for soil organic carbon enhancement", "bi-droplet-half", true)
            );
            categoryRepository.saveAll(categories);
            log.info("Saved {} initial database categories.", categories.size());
        }
    }

    private void bootstrapSampleData() {
        String commonPassword = passwordEncoder.encode("Password@123");

        // 1. Create 10 Farmers across Telangana & AP
        String[][] farmerData = {
                {"Ramesh Reddy", "ramesh.farmer@agricycle.com", "9848011221", "Miryalaguda", "Nalgonda", "Telangana", "12.5", "Rice (Paddy), Maize"},
                {"Venkatesh Rao", "venkat.rao@agricycle.com", "9848022332", "Jammikunta", "Karimnagar", "Telangana", "15.0", "Rice, Cotton"},
                {"Srinivas Goud", "srinivas.g@agricycle.com", "9848033443", "Narsampet", "Warangal", "Telangana", "8.0", "Cotton, Maize, Chilli"},
                {"Mallesh Yadav", "mallesh.yadav@agricycle.com", "9848044554", "Madhira", "Khammam", "Telangana", "18.0", "Sugarcane, Rice"},
                {"Anji Reddy", "anji.reddy@agricycle.com", "9848055665", "Kodad", "Suryapet", "Telangana", "10.0", "Rice, Pulses"},
                {"Prabhakar Rao", "prabhakar.p@agricycle.com", "9848066776", "Armoor", "Nizamabad", "Telangana", "14.0", "Rice, Turmeric, Maize"},
                {"Satyanarayana Murthy", "satya.murthy@agricycle.com", "9848077887", "Tenali", "Guntur", "Andhra Pradesh", "20.0", "Rice, Black Gram, Cotton"},
                {"Krishna Mohan", "krishna.m@agricycle.com", "9848088998", "Gudivada", "Krishna", "Andhra Pradesh", "16.5", "Rice, Sugarcane"},
                {"Ramana Reddy", "ramana.r@agricycle.com", "9848099009", "Jadcherla", "Mahbubnagar", "Telangana", "9.0", "Groundnut, Maize, Castor"},
                {"Bhaskar Rao", "bhaskar.rao@agricycle.com", "9848012345", "Siddipet", "Medak", "Telangana", "11.0", "Rice, Wheat, Vegetables"}
        };

        List<User> farmers = new ArrayList<>();
        for (String[] fd : farmerData) {
            User u = new User(fd[1], commonPassword, fd[0], fd[2], Role.ROLE_FARMER, UserStatus.ACTIVE);
            u = userRepository.save(u);
            farmers.add(u);

            FarmerProfile fp = new FarmerProfile();
            fp.setUser(u);
            fp.setVillage(fd[3]);
            fp.setDistrict(fd[4]);
            fp.setState(fd[5]);
            fp.setFarmSizeAcres(Double.parseDouble(fd[6]));
            fp.setMainCrops(fd[7]);
            fp.setPreferredCategories("Harvest Products, Fodder, Crop Residue");
            fp.setVerificationStatus(VerificationStatus.VERIFIED);
            farmerProfileRepository.save(fp);
        }

        // 2. Create 5 Livestock Owners
        String[][] livestockData = {
                {"Gopal Krishna", "gopal.dairy@agricycle.com", "9949011111", "Dairy Cattle & Buffalo", "35", "Dry Straw & Green Fodder", "Nalgonda", "Telangana"},
                {"Lakshmi Devi", "lakshmi.buffalo@agricycle.com", "9949022222", "Murrah Buffaloes", "50", "Paddy Straw & Silage", "Karimnagar", "Telangana"},
                {"Sudhakar Reddy", "sudhakar.reddy@agricycle.com", "9949033333", "Sheep & Boer Goats", "120", "Green Fodder & Stover", "Warangal", "Telangana"},
                {"Suresh Yadav", "suresh.dairy@agricycle.com", "9949044444", "Crossbred HF Cattle", "45", "Wheat Straw & Napier Grass", "Hyderabad", "Telangana"},
                {"Venkat Ramana", "venkat.ramana@agricycle.com", "9949055555", "Buffalo Dairy Herd", "60", "Dry Fodder & Maize Stalks", "Guntur", "Andhra Pradesh"}
        };

        List<User> livestockOwners = new ArrayList<>();
        for (String[] ld : livestockData) {
            User u = new User(ld[1], commonPassword, ld[0], ld[2], Role.ROLE_LIVESTOCK_OWNER, UserStatus.ACTIVE);
            u = userRepository.save(u);
            livestockOwners.add(u);

            LivestockProfile lp = new LivestockProfile();
            lp.setUser(u);
            lp.setAnimalType(ld[3]);
            lp.setNumberOfAnimals(Integer.parseInt(ld[4]));
            lp.setFeedPreference(ld[5]);
            lp.setDistrict(ld[6]);
            lp.setState(ld[7]);
            lp.setVerificationStatus(VerificationStatus.VERIFIED);
            livestockProfileRepository.save(lp);
        }

        // 3. Create 5 Companies
        String[][] companyData = {
                {"GreenEnergy Biomass Power Ltd", "procure@greenenergy.com", "9701011111", "Biomass Power Generation", "36AABCG1234F1Z1", "IDA Nacharam", "Hyderabad", "Telangana", "Rajesh Khurana", "9701011112"},
                {"EcoPulp Paper & Packaging Corp", "purchase@ecopulp.com", "9701022222", "Paper & Moulded Pulp Packaging", "36AABCE5678G1Z2", "Industrial Area", "Khammam", "Telangana", "Vikram Sen", "9701022223"},
                {"BioFuel Innovations India", "orders@biofuelinnovations.com", "9701033333", "Bio-Ethanol & Briquetting", "36AABCZ9012H1Z3", "Subedari Industrial Hub", "Warangal", "Telangana", "Arun Varma", "9701033334"},
                {"Deccan Organic Compost Fertilizers", "supply@deccancompost.com", "9701044444", "Bio-Fertilizer & Soil Nutrition", "36AABCD3456J1Z4", "Miryalaguda Bypass", "Nalgonda", "Telangana", "Pooja Hegde", "9701044445"},
                {"AgroBriquette Renewable Fuels", "fuel@agrobriquette.com", "9701055555", "Solid Biofuel Pellets", "36AABCA7890K1Z5", "Bodhan Road", "Nizamabad", "Telangana", "Karthik Nair", "9701055556"}
        };

        List<User> companies = new ArrayList<>();
        for (String[] cd : companyData) {
            User u = new User(cd[1], commonPassword, cd[0], cd[2], Role.ROLE_COMPANY, UserStatus.ACTIVE);
            u = userRepository.save(u);
            companies.add(u);

            CompanyProfile cp = new CompanyProfile();
            cp.setUser(u);
            cp.setCompanyName(cd[0]);
            cp.setIndustryType(cd[3]);
            cp.setGstNumber(cd[4]);
            cp.setAddress(cd[5]);
            cp.setDistrict(cd[6]);
            cp.setState(cd[7]);
            cp.setContactPerson(cd[8]);
            cp.setContactPhone(cd[9]);
            cp.setVerificationStatus(VerificationStatus.VERIFIED);
            companyProfileRepository.save(cp);
        }

        // 4. Create 5 Transporters
        String[][] transporterData = {
                {"Telangana Agri Logistics", "logistics@telanganatrans.com", "9866011111", "TS05-TA-4521", "10-Ton Heavy Truck", "10.0", "Nalgonda, Suryapet, Hyderabad"},
                {"Kisan Express Freight", "freight@kisanexpress.com", "9866022222", "TS02-KE-7890", "7-Ton Open Body Truck", "7.0", "Karimnagar, Warangal, Medak"},
                {"Sri Rama Rural Transport", "srirama@ruraltransport.com", "9866033333", "TS03-SR-1234", "Tractor Double Trolley", "5.0", "Warangal, Khammam, Mahbubabad"},
                {"Deccan Haulage Services", "haulage@deccanhaul.com", "9866044444", "TS09-DH-9988", "16-Ton Multi-Axle Carrier", "16.0", "Statewide Telangana & AP"},
                {"Godavari Cargo Carriers", "cargo@godavaricargo.com", "9866055555", "AP16-GC-5678", "8-Ton Eicher Cargo", "8.0", "Guntur, Krishna, Vijayawada"}
        };

        List<User> transporters = new ArrayList<>();
        for (String[] td : transporterData) {
            User u = new User(td[1], commonPassword, td[0], td[2], Role.ROLE_TRANSPORTER, UserStatus.ACTIVE);
            u = userRepository.save(u);
            transporters.add(u);

            TransportProfile tp = new TransportProfile();
            tp.setUser(u);
            tp.setVehicleNumber(td[3]);
            tp.setVehicleType(td[4]);
            tp.setCapacityTons(Double.parseDouble(td[5]));
            tp.setServiceArea(td[6]);
            tp.setAvailable(true);
            tp.setVerificationStatus(VerificationStatus.VERIFIED);
            transportProfileRepository.save(tp);

            // Add vehicle to fleet
            Vehicle v = new Vehicle(u, td[3], td[4], Double.parseDouble(td[5]), td[6].split(",")[0].trim());
            vehicleRepository.save(v);
        }

        // 5. Create Harvests for Farmers
        List<Category> allCategories = categoryRepository.findAll();
        Category catPaddy = allCategories.stream().filter(c -> c.getSlug().contains("paddy-rice-grain")).findFirst().orElse(allCategories.get(0));
        Category catStraw = allCategories.stream().filter(c -> c.getSlug().contains("paddy-rice-straw")).findFirst().orElse(allCategories.get(1));
        Category catHusk = allCategories.stream().filter(c -> c.getSlug().contains("rice-husk")).findFirst().orElse(allCategories.get(2));
        Category catMaize = allCategories.stream().filter(c -> c.getSlug().contains("yellow-maize-grain")).findFirst().orElse(allCategories.get(0));
        Category catMaizeFodder = allCategories.stream().filter(c -> c.getSlug().contains("green-maize-stover")).findFirst().orElse(allCategories.get(1));
        Category catCotton = allCategories.stream().filter(c -> c.getSlug().contains("raw-seed-cotton")).findFirst().orElse(allCategories.get(0));
        Category catCottonStalks = allCategories.stream().filter(c -> c.getSlug().contains("cotton-stalks")).findFirst().orElse(allCategories.get(2));
        Category catWheatStraw = allCategories.stream().filter(c -> c.getSlug().contains("chopped-wheat-straw")).findFirst().orElse(allCategories.get(1));
        Category catSugarcane = allCategories.stream().filter(c -> c.getSlug().contains("sugarcane-stalks")).findFirst().orElse(allCategories.get(0));
        Category catBagasse = allCategories.stream().filter(c -> c.getSlug().contains("sugarcane-bagasse")).findFirst().orElse(allCategories.get(2));

        // Farmer 0 (Ramesh Reddy) - Rice Harvest
        Harvest h1 = new Harvest(farmers.get(0), "Rice (Paddy)", "BPT 5204 (Samba Mahsuri)", LocalDate.now().minusDays(15), 25.0, "Tons", "Miryalaguda", "Nalgonda", "Telangana");
        h1.setDescription("Premium quality Samba Mahsuri kharif harvest with low moisture content.");
        h1 = harvestRepository.save(h1);

        // Farmer 1 (Venkatesh Rao) - Rice & Cotton Harvests
        Harvest h2 = new Harvest(farmers.get(1), "Rice (Paddy)", "RNR 15048 (Telangana Sona)", LocalDate.now().minusDays(20), 30.0, "Tons", "Jammikunta", "Karimnagar", "Telangana");
        h2 = harvestRepository.save(h2);

        Harvest h3 = new Harvest(farmers.get(1), "Raw Cotton", "Bt Cotton Hybrid", LocalDate.now().minusDays(10), 12.0, "Tons", "Jammikunta", "Karimnagar", "Telangana");
        h3 = harvestRepository.save(h3);

        // Farmer 2 (Srinivas Goud) - Maize Harvest
        Harvest h4 = new Harvest(farmers.get(2), "Yellow Maize", "Pioneer Hybrid", LocalDate.now().minusDays(8), 18.0, "Tons", "Narsampet", "Warangal", "Telangana");
        h4 = harvestRepository.save(h4);

        // Farmer 3 (Mallesh Yadav) - Sugarcane Harvest
        Harvest h5 = new Harvest(farmers.get(3), "Sugarcane", "Co 86032", LocalDate.now().minusDays(12), 80.0, "Tons", "Madhira", "Khammam", "Telangana");
        h5 = harvestRepository.save(h5);

        // 6. Generate 30+ Marketplace Listings with ONE HARVEST -> MULTIPLE MARKETS
        List<Listing> listings = new ArrayList<>();

        // From Harvest 1 (Rice - Ramesh Reddy): 3 Listings
        Listing l1 = new Listing(farmers.get(0), h1, catPaddy, "Premium BPT 5204 Paddy Grain", "Paddy / Rice Grain", 25.0, "Tons", 24500.0, "Miryalaguda", "Nalgonda", "Telangana");
        l1.setSuitableUse("Direct Milling & Food Consumption");
        l1.setDescription("Grade-A dried paddy grain stored in hygienic warehouse.");
        l1.setLotId("AGC-RICE-TG-2026-000001");
        l1.setLatitude(17.0575); l1.setLongitude(79.2684);
        listings.add(l1);

        Listing l2 = new Listing(farmers.get(0), h1, catStraw, "High-Density Baled Rice Straw Fodder", "Rice Straw", 30.0, "Tons", 3600.0, "Miryalaguda", "Nalgonda", "Telangana");
        l2.setSuitableUse("Livestock Fodder (Cattle & Buffaloes)");
        l2.setDescription("Freshly baled dry paddy straw with high palatability and zero mold.");
        l2.setLotId("AGC-STRA-TG-2026-000002");
        l2.setLatitude(17.0575); l2.setLongitude(79.2684);
        listings.add(l2);

        Listing l3 = new Listing(farmers.get(0), h1, catHusk, "Dry Rice Husk for Boiler Biomass", "Rice Husk", 8.0, "Tons", 2800.0, "Miryalaguda", "Nalgonda", "Telangana");
        l3.setSuitableUse("Industrial Biomass & Brick Kiln Fuel");
        l3.setDescription("Clean dry rice husk residue from milling, high calorific value.");
        l3.setLotId("AGC-HUSK-TG-2026-000003");
        l3.setLatitude(17.0575); l3.setLongitude(79.2684);
        listings.add(l3);

        // From Harvest 2 (Rice - Venkatesh Rao): 3 Listings
        Listing l4 = new Listing(farmers.get(1), h2, catPaddy, "Telangana Sona Low-GI Paddy Grain", "Paddy / Rice Grain", 30.0, "Tons", 25000.0, "Jammikunta", "Karimnagar", "Telangana");
        l4.setSuitableUse("Commercial Food Processing");
        l4.setDescription("Certified RNR 15048 low glycemic index paddy.");
        l4.setLotId("AGC-RICE-TG-2026-000004");
        l4.setLatitude(18.4386); l4.setLongitude(79.1288);
        listings.add(l4);

        Listing l5 = new Listing(farmers.get(1), h2, catStraw, "Dry Paddy Straw Dairy Feed Bales", "Rice Straw", 35.0, "Tons", 3500.0, "Jammikunta", "Karimnagar", "Telangana");
        l5.setSuitableUse("Livestock Fodder");
        l5.setDescription("Golden dry paddy straw bundles loaded directly from tractor.");
        l5.setLotId("AGC-STRA-TG-2026-000005");
        l5.setLatitude(18.4386); l5.setLongitude(79.1288);
        listings.add(l5);

        Listing l6 = new Listing(farmers.get(1), h2, catHusk, "Pure Paddy Husk Bulk Supply", "Rice Husk", 10.0, "Tons", 2750.0, "Jammikunta", "Karimnagar", "Telangana");
        l6.setSuitableUse("Industrial Energy & Briquetting");
        l6.setDescription("Clean husk residue for biomass power plants.");
        l6.setLotId("AGC-HUSK-TG-2026-000006");
        l6.setLatitude(18.4386); l6.setLongitude(79.1288);
        listings.add(l6);

        // From Harvest 3 (Cotton - Venkatesh Rao): 2 Listings
        Listing l7 = new Listing(farmers.get(1), h3, catCotton, "Long Staple Raw Seed Cotton", "Raw Seed Cotton", 12.0, "Tons", 68000.0, "Jammikunta", "Karimnagar", "Telangana");
        l7.setSuitableUse("Textile & Ginning Mills");
        l7.setDescription("High purity white cotton bolls.");
        l7.setLotId("AGC-COTT-TG-2026-000007");
        l7.setLatitude(18.4386); l7.setLongitude(79.1288);
        listings.add(l7);

        Listing l8 = new Listing(farmers.get(1), h3, catCottonStalks, "Dry Cotton Stalks for Particle Board", "Cotton Stalks", 22.0, "Tons", 2300.0, "Jammikunta", "Karimnagar", "Telangana");
        l8.setSuitableUse("Particle Board & Biomass Fuel");
        l8.setDescription("Hard woody stalks uprooted and bundled, avoiding field burning.");
        l8.setLotId("AGC-STAL-TG-2026-000008");
        l8.setLatitude(18.4386); l8.setLongitude(79.1288);
        listings.add(l8);

        // From Harvest 4 (Maize - Srinivas Goud): 3 Listings
        Listing l9 = new Listing(farmers.get(2), h4, catMaize, "High Starch Yellow Maize Grain", "Yellow Maize Grain", 18.0, "Tons", 21500.0, "Narsampet", "Warangal", "Telangana");
        l9.setSuitableUse("Poultry Feed & Starch Manufacturing");
        l9.setDescription("Bright yellow dry corn kernels.");
        l9.setLotId("AGC-MAIZ-TG-2026-000009");
        l9.setLatitude(17.9689); l9.setLongitude(79.5941);
        listings.add(l9);

        Listing l10 = new Listing(farmers.get(2), h4, catMaizeFodder, "Nutritious Green Maize Stover Fodder", "Green Maize Stover", 24.0, "Tons", 2900.0, "Narsampet", "Warangal", "Telangana");
        l10.setSuitableUse("Livestock Fodder (Cows, Goats, Sheep)");
        l10.setDescription("Freshly chopped green maize stalks rich in sweetness.");
        l10.setLotId("AGC-MAIZ-TG-2026-000010");
        l10.setLatitude(17.9689); l10.setLongitude(79.5941);
        listings.add(l10);

        Listing l11 = new Listing(farmers.get(2), h4, catBagasse, "Dry Maize Cob Biomass Residue", "Maize Cob Bio-Residue", 6.0, "Tons", 2100.0, "Narsampet", "Warangal", "Telangana");
        l11.setSuitableUse("Bio-Briquettes & Biochar");
        l11.setDescription("Dry stripped maize cobs ready for industrial carbonization.");
        l11.setLotId("AGC-COBS-TG-2026-000011");
        l11.setLatitude(17.9689); l11.setLongitude(79.5941);
        listings.add(l11);

        // From Harvest 5 (Sugarcane - Mallesh Yadav): 2 Listings
        Listing l12 = new Listing(farmers.get(3), h5, catSugarcane, "Fresh Sweet Sugarcane Cane", "Sugarcane Stalks", 80.0, "Tons", 3200.0, "Madhira", "Khammam", "Telangana");
        l12.setSuitableUse("Sugar Mills & Jaggery Production");
        l12.setDescription("High brix sugar content cane ready for crushing.");
        l12.setLotId("AGC-CANE-TG-2026-000012");
        l12.setLatitude(17.2473); l12.setLongitude(80.1514);
        listings.add(l12);

        Listing l13 = new Listing(farmers.get(3), h5, catBagasse, "Fibrous Sugarcane Bagasse Pulp", "Sugarcane Bagasse", 26.0, "Tons", 2550.0, "Madhira", "Khammam", "Telangana");
        l13.setSuitableUse("Eco-Packaging Paper & Cogeneration");
        l13.setDescription("Moisture-pressed fibrous bagasse for pulp making and energy.");
        l13.setLotId("AGC-BAGS-TG-2026-000013");
        l13.setLatitude(17.2473); l13.setLongitude(80.1514);
        listings.add(l13);

        // Add additional realistic listings across other farmers (total 30+ listings)
        String[][] additionalListings = {
                {"Paddy Straw Bales", "Rice Straw", "40.0", "3400.0", "Kodad", "Suryapet", "Telangana", "AGC-STRA-TG-2026-000014", "FODDER"},
                {"Organic Wheat Straw Turi", "Chopped Wheat Straw", "25.0", "5200.0", "Armoor", "Nizamabad", "Telangana", "AGC-TURI-TG-2026-000015", "FODDER"},
                {"Tenali Rice Husk Residue", "Rice Husk", "15.0", "2900.0", "Tenali", "Guntur", "Andhra Pradesh", "AGC-HUSK-AP-2026-000016", "AGRICULTURAL_RESIDUE"},
                {"Guntur Dry Paddy Straw", "Rice Straw", "50.0", "3300.0", "Tenali", "Guntur", "Andhra Pradesh", "AGC-STRA-AP-2026-000017", "FODDER"},
                {"Krishna District Paddy Grain", "Paddy / Rice Grain", "35.0", "24800.0", "Gudivada", "Krishna", "Andhra Pradesh", "AGC-RICE-AP-2026-000018", "HARVEST_PRODUCT"},
                {"Sugarcane Bagasse Biomass", "Sugarcane Bagasse", "30.0", "2600.0", "Gudivada", "Krishna", "Andhra Pradesh", "AGC-BAGS-AP-2026-000019", "AGRICULTURAL_RESIDUE"},
                {"Groundnut Pods Unhusked", "Groundnut Pods", "10.0", "62000.0", "Jadcherla", "Mahbubnagar", "Telangana", "AGC-GNUT-TG-2026-000020", "HARVEST_PRODUCT"},
                {"Groundnut Shells Residue", "Groundnut Shells", "12.0", "2100.0", "Jadcherla", "Mahbubnagar", "Telangana", "AGC-GSHE-TG-2026-000021", "AGRICULTURAL_RESIDUE"},
                {"Maize Stover Green Fodder", "Green Maize Stover", "20.0", "2800.0", "Jadcherla", "Mahbubnagar", "Telangana", "AGC-MAIZ-TG-2026-000022", "FODDER"},
                {"Siddipet Paddy Straw", "Rice Straw", "28.0", "3650.0", "Siddipet", "Medak", "Telangana", "AGC-STRA-TG-2026-000023", "FODDER"},
                {"Milling Wheat Whole Grain", "Milling Wheat", "15.0", "23000.0", "Siddipet", "Medak", "Telangana", "AGC-WHTG-TG-2026-000024", "HARVEST_PRODUCT"},
                {"Chopped Wheat Fodder", "Chopped Wheat Straw", "18.0", "5400.0", "Siddipet", "Medak", "Telangana", "AGC-TURI-TG-2026-000025", "FODDER"},
                {"Cotton Stalks for Fuel", "Cotton Stalks", "30.0", "2250.0", "Narsampet", "Warangal", "Telangana", "AGC-STAL-TG-2026-000026", "AGRICULTURAL_RESIDUE"},
                {"Red Gram Stalk Fodder", "Dry Crop Residue", "14.0", "2700.0", "Kodad", "Suryapet", "Telangana", "AGC-PULS-TG-2026-000027", "FODDER"},
                {"Rice Bran & Broken Grain", "Rice Bran", "6.0", "14000.0", "Miryalaguda", "Nalgonda", "Telangana", "AGC-BRAN-TG-2026-000028", "AGRICULTURAL_RESIDUE"},
                {"Turmeric Crop Foliage", "Agricultural Residue", "8.0", "1900.0", "Armoor", "Nizamabad", "Telangana", "AGC-TURM-TG-2026-000029", "AGRICULTURAL_RESIDUE"},
                {"Napier Hybrid Green Grass", "Hybrid Napier Grass", "16.0", "2600.0", "Madhira", "Khammam", "Telangana", "AGC-NAPI-TG-2026-000030", "FODDER"},
                {"Corn Silage Sealed Drums", "Corn Silage", "12.0", "4800.0", "Tenali", "Guntur", "Andhra Pradesh", "AGC-SILA-AP-2026-000031", "FODDER"}
        };

        int fIdx = 4;
        for (String[] al : additionalListings) {
            User s = farmers.get(fIdx % farmers.size());
            Category cat = al[8].equals("FODDER") ? catStraw : (al[8].equals("AGRICULTURAL_RESIDUE") ? catHusk : catPaddy);
            Listing l = new Listing(s, null, cat, al[0], al[1], Double.parseDouble(al[2]), "Tons", Double.parseDouble(al[3]), al[4], al[5], al[6]);
            l.setLotId(al[7]);
            l.setSuitableUse(al[8].equals("FODDER") ? "Animal Feed & Dairy" : "Industrial Biomass");
            l.setDescription("Verified farm listing with quality harvest standards.");
            l.setLatitude(17.3850); l.setLongitude(78.4867);
            listings.add(l);
            fIdx++;
        }

        listingRepository.saveAll(listings);
        log.info("Saved {} marketplace listings with Digital Lot IDs.", listings.size());

        // 7. Create 10 Requirements (Company bulk requirements & Emergency fodder requests)
        List<Requirement> reqs = new ArrayList<>();

        // Emergency Fodder Request 1 (Gopal Krishna - Nalgonda)
        Requirement r1 = new Requirement();
        r1.setUser(livestockOwners.get(0));
        r1.setCategory(catStraw);
        r1.setMaterialName("Dry Paddy Straw Fodder");
        r1.setQuantityRequired(15.0);
        r1.setUnit("Tons");
        r1.setTargetPrice(3400.0);
        r1.setVillage("Miryalaguda");
        r1.setDistrict("Nalgonda");
        r1.setState("Telangana");
        r1.setRequiredByDate(LocalDate.now().plusDays(3));
        r1.setEmergency(true);
        r1.setUrgency(UrgencyLevel.HIGH);
        r1.setAnimalType("Buffalo & Cow Dairy");
        r1.setNumberOfAnimals(35);
        r1.setDescription("URGENT FODDER REQUEST: Immediate dry straw feed required for dairy milking herd due to dry spell.");
        r1.setStatus(RequirementStatus.OPEN);
        reqs.add(r1);

        // Emergency Fodder Request 2 (Lakshmi Devi - Karimnagar)
        Requirement r2 = new Requirement();
        r2.setUser(livestockOwners.get(1));
        r2.setCategory(catStraw);
        r2.setMaterialName("Wheat Straw / Paddy Straw");
        r2.setQuantityRequired(20.0);
        r2.setUnit("Tons");
        r2.setTargetPrice(3500.0);
        r2.setDistrict("Karimnagar");
        r2.setState("Telangana");
        r2.setRequiredByDate(LocalDate.now().plusDays(2));
        r2.setEmergency(true);
        r2.setUrgency(UrgencyLevel.URGENT);
        r2.setAnimalType("Murrah Buffaloes");
        r2.setNumberOfAnimals(50);
        r2.setDescription("High urgency fodder required for commercial dairy farm.");
        r2.setStatus(RequirementStatus.OPEN);
        reqs.add(r2);

        // Company Bulk Requirement 3 (GreenEnergy Biomass - Hyderabad)
        Requirement r3 = new Requirement();
        r3.setUser(companies.get(0));
        r3.setCategory(catHusk);
        r3.setMaterialName("Rice Husk");
        r3.setQuantityRequired(50.0);
        r3.setUnit("Tons");
        r3.setTargetPrice(2700.0);
        r3.setDistrict("Hyderabad");
        r3.setState("Telangana");
        r3.setRequiredByDate(LocalDate.now().plusDays(15));
        r3.setQualityRequirement("Moisture < 12%, calorific value > 3000 kcal/kg");
        r3.setDescription("Industrial biomass requirement for 10MW renewable power plant.");
        r3.setDeliveryRequirement("Unloaded at IDA Nacharam power facility");
        r3.setStatus(RequirementStatus.OPEN);
        reqs.add(r3);

        // Company Bulk Requirement 4 (EcoPulp Paper - Khammam)
        Requirement r4 = new Requirement();
        r4.setUser(companies.get(1));
        r4.setCategory(catBagasse);
        r4.setMaterialName("Sugarcane Bagasse");
        r4.setQuantityRequired(40.0);
        r4.setUnit("Tons");
        r4.setTargetPrice(2500.0);
        r4.setDistrict("Khammam");
        r4.setState("Telangana");
        r4.setRequiredByDate(LocalDate.now().plusDays(20));
        r4.setQualityRequirement("Fiber length > 1.2mm, clean from stones and sand");
        r4.setDescription("Moulded pulp packaging production line input.");
        r4.setStatus(RequirementStatus.OPEN);
        reqs.add(r4);

        // Company Bulk Requirement 5 (BioFuel Innovations - Warangal)
        Requirement r5 = new Requirement();
        r5.setUser(companies.get(2));
        r5.setCategory(catCottonStalks);
        r5.setMaterialName("Cotton Stalks (Biomass)");
        r5.setQuantityRequired(30.0);
        r5.setUnit("Tons");
        r5.setTargetPrice(2200.0);
        r5.setDistrict("Warangal");
        r5.setState("Telangana");
        r5.setRequiredByDate(LocalDate.now().plusDays(10));
        r5.setDescription("Aggregated supply needed for bio-briquette factory.");
        r5.setStatus(RequirementStatus.OPEN);
        reqs.add(r5);

        // Add 5 more requirements
        String[][] moreReqs = {
                {"Paddy Straw Fodder", "25.0", "Tons", "3300.0", "Warangal", "Telangana", "Sheep & Goat", "120", "true"},
                {"Green Maize Fodder", "18.0", "Tons", "2800.0", "Hyderabad", "Telangana", "Dairy Cows", "40", "false"},
                {"Maize Cob Residue", "35.0", "Tons", "2100.0", "Nizamabad", "Telangana", null, null, "false"},
                {"Groundnut Shells", "20.0", "Tons", "2000.0", "Hyderabad", "Telangana", null, null, "false"},
                {"Dry Paddy Straw", "30.0", "Tons", "3200.0", "Guntur", "Andhra Pradesh", "Dairy Buffaloes", "60", "true"}
        };

        for (int i = 0; i < moreReqs.length; i++) {
            String[] mr = moreReqs[i];
            Requirement r = new Requirement();
            r.setUser(i % 2 == 0 ? livestockOwners.get(i % livestockOwners.size()) : companies.get(i % companies.size()));
            r.setMaterialName(mr[0]);
            r.setQuantityRequired(Double.parseDouble(mr[1]));
            r.setUnit(mr[2]);
            r.setTargetPrice(Double.parseDouble(mr[3]));
            r.setDistrict(mr[4]);
            r.setState(mr[5]);
            r.setRequiredByDate(LocalDate.now().plusDays(12));
            boolean em = Boolean.parseBoolean(mr[8]);
            r.setEmergency(em);
            r.setUrgency(em ? UrgencyLevel.HIGH : UrgencyLevel.MEDIUM);
            r.setAnimalType(mr[6]);
            if (mr[7] != null) r.setNumberOfAnimals(Integer.parseInt(mr[7]));
            r.setDescription("Market requirement for " + mr[0]);
            r.setStatus(RequirementStatus.OPEN);
            reqs.add(r);
        }

        requirementRepository.saveAll(reqs);
        log.info("Saved {} requirements (commercial & emergency fodder).", reqs.size());

        // 8. Create 20 Orders across various lifecycle stages
        OrderStatus[] statuses = {
                OrderStatus.COMPLETED, OrderStatus.COMPLETED, OrderStatus.DELIVERED, OrderStatus.IN_TRANSIT,
                OrderStatus.PICKED_UP, OrderStatus.TRANSPORT_ASSIGNED, OrderStatus.CONFIRMED, OrderStatus.ACCEPTED,
                OrderStatus.PENDING, OrderStatus.COMPLETED, OrderStatus.COMPLETED, OrderStatus.DELIVERED,
                OrderStatus.IN_TRANSIT, OrderStatus.CONFIRMED, OrderStatus.ACCEPTED, OrderStatus.PENDING,
                OrderStatus.COMPLETED, OrderStatus.DELIVERED, OrderStatus.CONFIRMED, OrderStatus.COMPLETED
        };

        List<Order> orders = new ArrayList<>();
        for (int i = 0; i < 20; i++) {
            Listing targetListing = listings.get(i % listings.size());
            User buyer = (i % 2 == 0) ? livestockOwners.get(i % livestockOwners.size()) : companies.get(i % companies.size());
            User seller = targetListing.getSeller();

            Order order = new Order();
            String orderNum = String.format("ORD-20261005-%04d", 1000 + i);
            order.setOrderNumber(orderNum);
            order.setBuyer(buyer);
            order.setSeller(seller);
            double qty = Math.min(5.0 + (i % 4), targetListing.getQuantity());
            order.setTotalAmount(qty * targetListing.getPricePerUnit());
            order.setStatus(statuses[i]);
            order.setDeliveryAddress(buyer.getFullName() + " Depot, " + targetListing.getDistrict() + ", " + targetListing.getState());
            order.setDistrict(targetListing.getDistrict());
            order.setState(targetListing.getState());
            order.setSpecialInstructions("Standard agricultural handling and moisture protection.");
            order = orderRepository.save(order);

            OrderItem item = new OrderItem(order, targetListing, targetListing.getProductMaterialName(), qty, targetListing.getUnit(), targetListing.getPricePerUnit(), order.getTotalAmount());
            orderItemRepository.save(item);

            // Transport Job
            TransportJob job = new TransportJob();
            job.setOrder(order);
            job.setPickupLocation(seller.getFullName() + " Farm, " + targetListing.getVillage());
            job.setPickupDistrict(targetListing.getDistrict());
            job.setDeliveryLocation(order.getDeliveryAddress());
            job.setDeliveryDistrict(order.getDistrict());
            job.setWeightTons(qty);
            job.setAgreedFare(Math.max(1500.0, order.getTotalAmount() * 0.08));

            if (order.getStatus() == OrderStatus.COMPLETED || order.getStatus() == OrderStatus.DELIVERED) {
                job.setStatus(TransportStatus.DELIVERED);
                job.setTransporter(transporters.get(i % transporters.size()));
                job.setDeliveredAt(LocalDateTime.now().minusDays(1));
            } else if (order.getStatus() == OrderStatus.IN_TRANSIT) {
                job.setStatus(TransportStatus.IN_TRANSIT);
                job.setTransporter(transporters.get(i % transporters.size()));
                job.setPickedUpAt(LocalDateTime.now().minusHours(4));
            } else if (order.getStatus() == OrderStatus.PICKED_UP) {
                job.setStatus(TransportStatus.PICKED_UP);
                job.setTransporter(transporters.get(i % transporters.size()));
            } else if (order.getStatus() == OrderStatus.TRANSPORT_ASSIGNED) {
                job.setStatus(TransportStatus.ASSIGNED);
                job.setTransporter(transporters.get(i % transporters.size()));
            } else {
                job.setStatus(TransportStatus.REQUESTED);
            }
            transportJobRepository.save(job);

            // Payment
            Payment pay = new Payment();
            pay.setOrder(order);
            pay.setAmount(order.getTotalAmount());
            pay.setTransactionReference("TXN-AGC-20261005-" + (90000 + i));
            pay.setPaymentMethod("ESCROW_TRANSFER");
            if (order.getStatus() == OrderStatus.COMPLETED || order.getStatus() == OrderStatus.DELIVERED || order.getStatus() == OrderStatus.IN_TRANSIT) {
                pay.setStatus(PaymentStatus.PAID);
                pay.setPaidAt(LocalDateTime.now().minusDays(2));
            } else {
                pay.setStatus(PaymentStatus.PENDING);
            }
            paymentRepository.save(pay);

            // Reviews for completed orders
            if (order.getStatus() == OrderStatus.COMPLETED && i < 10) {
                Review r = new Review(order, buyer, seller, ReviewType.BUYER_TO_SELLER, (i % 2 == 0 ? 5 : 4), "Excellent quality agricultural material, timely dispatch, and transparent transaction.");
                reviewRepository.save(r);
            }

            orders.add(order);
        }

        log.info("Saved {} orders, transport jobs, payments, and reviews.", orders.size());
    }
}

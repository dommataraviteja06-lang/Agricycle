package com.agricycle.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.nio.file.Path;
import java.nio.file.Paths;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Value("${app.upload.dir:uploads}")
    private String uploadDir;

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        Path uploadPath = Paths.get(uploadDir).toAbsolutePath().normalize();
        registry.addResourceHandler("/uploads/**")
                .addResourceLocations("file:" + uploadPath.toString() + "/");

        // Serve static frontend assets directly
        Path frontendPath = Paths.get("frontend").toAbsolutePath().normalize();
        if (!java.nio.file.Files.exists(frontendPath)) {
            frontendPath = Paths.get("../frontend").toAbsolutePath().normalize();
        }
        registry.addResourceHandler("/**")
                .addResourceLocations("file:" + frontendPath.toString() + "/", "classpath:/static/");
    }
}

package com.agricycle;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;

@SpringBootApplication
@EnableAsync
public class AgriCycleApplication {

    public static void main(String[] args) {
        SpringApplication.run(AgriCycleApplication.class, args);
    }
}

package com.agricycle.controller;

import com.agricycle.dto.ApiResponse;
import com.agricycle.dto.CreateOfferRequest;
import com.agricycle.dto.CreateRequirementRequest;
import com.agricycle.dto.RequirementDto;
import com.agricycle.dto.RequirementOfferDto;
import com.agricycle.entity.RequirementStatus;
import com.agricycle.entity.UrgencyLevel;
import com.agricycle.security.UserDetailsImpl;
import com.agricycle.service.OfferService;
import com.agricycle.service.RequirementService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/requirements")
@Tag(name = "Requirements", description = "Company material requirements, emergency fodder alerts, and supplier offers")
public class RequirementController {

    private final RequirementService requirementService;
    private final OfferService offerService;

    public RequirementController(RequirementService requirementService, OfferService offerService) {
        this.requirementService = requirementService;
        this.offerService = offerService;
    }

    @PostMapping
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Post a material requirement (Company) or Emergency Fodder request (Livestock Owner)")
    public ResponseEntity<ApiResponse<RequirementDto>> createRequirement(@Valid @RequestBody CreateRequirementRequest req,
                                                                         @AuthenticationPrincipal UserDetailsImpl userDetails,
                                                                         HttpServletRequest request) {
        RequirementDto dto = requirementService.createRequirement(req, userDetails.getId(), request.getRemoteAddr());
        return ResponseEntity.ok(ApiResponse.ok("Requirement posted successfully", dto));
    }

    @GetMapping("/public")
    @Operation(summary = "Search company requirements and fodder requests")
    public ResponseEntity<ApiResponse<Page<RequirementDto>>> searchRequirements(
            @RequestParam(required = false) RequirementStatus status,
            @RequestParam(required = false) Boolean emergency,
            @RequestParam(required = false) UrgencyLevel urgency,
            @RequestParam(required = false) String district,
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false, defaultValue = "0") int page,
            @RequestParam(required = false, defaultValue = "10") int size) {
        return ResponseEntity.ok(ApiResponse.ok(requirementService.searchRequirements(status, emergency, urgency, district, keyword, page, size)));
    }

    @GetMapping("/emergency")
    @Operation(summary = "Get active Emergency Fodder Requests")
    public ResponseEntity<ApiResponse<List<RequirementDto>>> getEmergencyFodderRequests() {
        return ResponseEntity.ok(ApiResponse.ok(requirementService.getEmergencyFodderRequests()));
    }

    @GetMapping("/my")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Get current user's posted requirements")
    public ResponseEntity<ApiResponse<List<RequirementDto>>> getMyRequirements(@AuthenticationPrincipal UserDetailsImpl userDetails) {
        return ResponseEntity.ok(ApiResponse.ok(requirementService.getUserRequirements(userDetails.getId())));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get requirement details")
    public ResponseEntity<ApiResponse<RequirementDto>> getRequirementDetails(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.ok(requirementService.getRequirementDetails(id)));
    }

    @PatchMapping("/{id}/close")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Close a requirement (Owner only)")
    public ResponseEntity<ApiResponse<Void>> closeRequirement(@PathVariable Long id,
                                                              @AuthenticationPrincipal UserDetailsImpl userDetails,
                                                              HttpServletRequest request) {
        requirementService.closeRequirement(id, userDetails.getId(), request.getRemoteAddr());
        return ResponseEntity.ok(ApiResponse.ok("Requirement closed successfully", null));
    }

    // Offers endpoints
    @PostMapping("/{id}/offers")
    @PreAuthorize("hasAuthority('ROLE_FARMER')")
    @Operation(summary = "Submit a supplier proposal / offer to a requirement (Farmer)")
    public ResponseEntity<ApiResponse<RequirementOfferDto>> submitOffer(@PathVariable Long id,
                                                                        @Valid @RequestBody CreateOfferRequest req,
                                                                        @AuthenticationPrincipal UserDetailsImpl userDetails,
                                                                        HttpServletRequest request) {
        req.setRequirementId(id);
        RequirementOfferDto dto = offerService.submitOffer(req, userDetails.getId(), request.getRemoteAddr());
        return ResponseEntity.ok(ApiResponse.ok("Offer submitted successfully", dto));
    }

    @GetMapping("/{id}/offers")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "View offers submitted for a requirement")
    public ResponseEntity<ApiResponse<List<RequirementOfferDto>>> getOffersForRequirement(@PathVariable Long id,
                                                                                           @AuthenticationPrincipal UserDetailsImpl userDetails) {
        return ResponseEntity.ok(ApiResponse.ok(offerService.getOffersForRequirement(id, userDetails.getId())));
    }

    @PostMapping("/{id}/accept-offers")
    @PreAuthorize("hasAuthority('ROLE_COMPANY') or hasAuthority('ROLE_LIVESTOCK_OWNER')")
    @Operation(summary = "Accept selected offers and create aggregated bulk orders (traceable farmer supply)")
    public ResponseEntity<ApiResponse<List<String>>> acceptOffers(@PathVariable Long id,
                                                                  @RequestBody List<Long> offerIds,
                                                                  @AuthenticationPrincipal UserDetailsImpl userDetails,
                                                                  HttpServletRequest request) {
        List<String> orderNumbers = offerService.acceptOffersAndCreateOrders(id, offerIds, userDetails.getId(), request.getRemoteAddr());
        return ResponseEntity.ok(ApiResponse.ok("Offers accepted and orders created successfully", orderNumbers));
    }

    @GetMapping("/my-offers")
    @PreAuthorize("hasAuthority('ROLE_FARMER')")
    @Operation(summary = "Get farmer's submitted offers")
    public ResponseEntity<ApiResponse<List<RequirementOfferDto>>> getMyOffers(@AuthenticationPrincipal UserDetailsImpl userDetails) {
        return ResponseEntity.ok(ApiResponse.ok(offerService.getSupplierOffers(userDetails.getId())));
    }
}

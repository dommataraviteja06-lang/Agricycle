package com.agricycle.controller;

import com.agricycle.dto.ApiResponse;
import com.agricycle.dto.CreateDisputeRequest;
import com.agricycle.dto.DisputeDto;
import com.agricycle.dto.ResolveDisputeRequest;
import com.agricycle.entity.DisputeStatus;
import com.agricycle.security.UserDetailsImpl;
import com.agricycle.service.DisputeService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/disputes")
@Tag(name = "Disputes", description = "Dispute resolution and complaint management")
public class DisputeController {

    private final DisputeService disputeService;

    public DisputeController(DisputeService disputeService) {
        this.disputeService = disputeService;
    }

    @PostMapping
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Raise a dispute or formal complaint on an order")
    public ResponseEntity<ApiResponse<DisputeDto>> raiseDispute(@Valid @RequestBody CreateDisputeRequest req,
                                                                @AuthenticationPrincipal UserDetailsImpl userDetails,
                                                                HttpServletRequest request) {
        DisputeDto dto = disputeService.raiseDispute(req, userDetails.getId(), request.getRemoteAddr());
        return ResponseEntity.ok(ApiResponse.ok("Dispute registered and forwarded to platform mediation", dto));
    }

    @GetMapping("/my")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Get current user's filed disputes")
    public ResponseEntity<ApiResponse<List<DisputeDto>>> getMyDisputes(@AuthenticationPrincipal UserDetailsImpl userDetails) {
        return ResponseEntity.ok(ApiResponse.ok(disputeService.getUserDisputes(userDetails.getId())));
    }

    @GetMapping("/admin")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    @Operation(summary = "Admin: View all disputes across platform")
    public ResponseEntity<ApiResponse<Page<DisputeDto>>> getDisputesForAdmin(
            @RequestParam(required = false) DisputeStatus status,
            @RequestParam(required = false, defaultValue = "0") int page,
            @RequestParam(required = false, defaultValue = "10") int size) {
        return ResponseEntity.ok(ApiResponse.ok(disputeService.getDisputesForAdmin(status, page, size)));
    }

    @PatchMapping("/admin/{id}/resolve")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    @Operation(summary = "Admin: Resolve dispute and record resolution notes")
    public ResponseEntity<ApiResponse<DisputeDto>> resolveDispute(@PathVariable Long id,
                                                                  @Valid @RequestBody ResolveDisputeRequest req,
                                                                  @AuthenticationPrincipal UserDetailsImpl userDetails,
                                                                  HttpServletRequest request) {
        DisputeDto dto = disputeService.resolveDispute(id, req, userDetails.getId(), request.getRemoteAddr());
        return ResponseEntity.ok(ApiResponse.ok("Dispute resolved", dto));
    }
}

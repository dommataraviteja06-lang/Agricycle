package com.agricycle.controller;

import com.agricycle.dto.ApiResponse;
import com.agricycle.dto.CreateReviewRequest;
import com.agricycle.dto.ReviewDto;
import com.agricycle.security.UserDetailsImpl;
import com.agricycle.service.ReviewService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/reviews")
@Tag(name = "Reviews", description = "Trust, ratings, feedback, and moderation")
public class ReviewController {

    private final ReviewService reviewService;

    public ReviewController(ReviewService reviewService) {
        this.reviewService = reviewService;
    }

    @PostMapping
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Submit an order review (Buyer to Seller, Seller to Buyer, or Buyer to Transporter)")
    public ResponseEntity<ApiResponse<ReviewDto>> createReview(@Valid @RequestBody CreateReviewRequest req,
                                                               @AuthenticationPrincipal UserDetailsImpl userDetails,
                                                               HttpServletRequest request) {
        ReviewDto dto = reviewService.createReview(req, userDetails.getId(), request.getRemoteAddr());
        return ResponseEntity.ok(ApiResponse.ok("Review submitted successfully", dto));
    }

    @GetMapping("/user/{userId}")
    @Operation(summary = "Get reviews and ratings received by a user")
    public ResponseEntity<ApiResponse<List<ReviewDto>>> getUserReviews(@PathVariable Long userId) {
        return ResponseEntity.ok(ApiResponse.ok(reviewService.getUserReviews(userId)));
    }

    @PostMapping("/{id}/report")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Report an abusive or fraudulent review to admin")
    public ResponseEntity<ApiResponse<Void>> reportReview(@PathVariable Long id,
                                                          @RequestParam String reason,
                                                          @AuthenticationPrincipal UserDetailsImpl userDetails,
                                                          HttpServletRequest request) {
        reviewService.reportReview(id, reason, userDetails.getId(), request.getRemoteAddr());
        return ResponseEntity.ok(ApiResponse.ok("Review reported for moderation", null));
    }
}

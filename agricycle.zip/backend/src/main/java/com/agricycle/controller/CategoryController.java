package com.agricycle.controller;

import com.agricycle.dto.ApiResponse;
import com.agricycle.dto.CategoryDto;
import com.agricycle.entity.CategoryType;
import com.agricycle.service.CategoryService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/categories")
@Tag(name = "Categories", description = "Marketplace categories (Harvest Products, Fodder, Crop Residue)")
public class CategoryController {

    private final CategoryService categoryService;

    public CategoryController(CategoryService categoryService) {
        this.categoryService = categoryService;
    }

    @GetMapping
    @Operation(summary = "Get all active marketplace categories")
    public ResponseEntity<ApiResponse<List<CategoryDto>>> getAllCategories() {
        return ResponseEntity.ok(ApiResponse.ok(categoryService.getAllActiveCategories()));
    }

    @GetMapping("/type/{type}")
    @Operation(summary = "Get categories by type (HARVEST_PRODUCT, FODDER, AGRICULTURAL_RESIDUE)")
    public ResponseEntity<ApiResponse<List<CategoryDto>>> getCategoriesByType(@PathVariable CategoryType type) {
        return ResponseEntity.ok(ApiResponse.ok(categoryService.getCategoriesByType(type)));
    }
}

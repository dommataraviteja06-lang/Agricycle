package com.agricycle.controller;

import com.agricycle.dto.ApiResponse;
import com.agricycle.dto.TransportJobDto;
import com.agricycle.dto.UpdateTransportStatusRequest;
import com.agricycle.dto.VehicleDto;
import com.agricycle.security.UserDetailsImpl;
import com.agricycle.service.TransportService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/transport")
@Tag(name = "Transport", description = "Logistics job matching, status tracking, vehicles, and earnings")
public class TransportController {

    private final TransportService transportService;

    public TransportController(TransportService transportService) {
        this.transportService = transportService;
    }

    @GetMapping("/available-jobs")
    @PreAuthorize("hasAuthority('ROLE_TRANSPORTER') or hasAuthority('ROLE_ADMIN')")
    @Operation(summary = "Find available transport delivery jobs in region")
    public ResponseEntity<ApiResponse<Page<TransportJobDto>>> getAvailableJobs(
            @RequestParam(required = false) String district,
            @RequestParam(required = false, defaultValue = "0") int page,
            @RequestParam(required = false, defaultValue = "10") int size) {
        return ResponseEntity.ok(ApiResponse.ok(transportService.getAvailableJobs(district, page, size)));
    }

    @PostMapping("/jobs/{id}/accept")
    @PreAuthorize("hasAuthority('ROLE_TRANSPORTER')")
    @Operation(summary = "Accept an available delivery job (Transporter)")
    public ResponseEntity<ApiResponse<TransportJobDto>> acceptJob(@PathVariable Long id,
                                                                 @AuthenticationPrincipal UserDetailsImpl userDetails,
                                                                 HttpServletRequest request) {
        TransportJobDto dto = transportService.acceptJob(id, userDetails.getId(), request.getRemoteAddr());
        return ResponseEntity.ok(ApiResponse.ok("Transport job accepted", dto));
    }

    @PatchMapping("/jobs/{id}/status")
    @PreAuthorize("hasAuthority('ROLE_TRANSPORTER') or hasAuthority('ROLE_ADMIN')")
    @Operation(summary = "Update transport delivery status (ASSIGNED, PICKED_UP, IN_TRANSIT, DELIVERED, COMPLETED)")
    public ResponseEntity<ApiResponse<TransportJobDto>> updateJobStatus(@PathVariable Long id,
                                                                       @Valid @RequestBody UpdateTransportStatusRequest req,
                                                                       @AuthenticationPrincipal UserDetailsImpl userDetails,
                                                                       HttpServletRequest request) {
        TransportJobDto dto = transportService.updateJobStatus(id, req, userDetails.getId(), request.getRemoteAddr());
        return ResponseEntity.ok(ApiResponse.ok("Transport status updated", dto));
    }

    @GetMapping("/my-jobs")
    @PreAuthorize("hasAuthority('ROLE_TRANSPORTER')")
    @Operation(summary = "Get current transporter's assigned and completed delivery jobs")
    public ResponseEntity<ApiResponse<List<TransportJobDto>>> getMyJobs(@AuthenticationPrincipal UserDetailsImpl userDetails) {
        return ResponseEntity.ok(ApiResponse.ok(transportService.getTransporterJobs(userDetails.getId())));
    }

    @GetMapping("/earnings")
    @PreAuthorize("hasAuthority('ROLE_TRANSPORTER')")
    @Operation(summary = "Get total completed delivery earnings")
    public ResponseEntity<ApiResponse<Double>> getMyEarnings(@AuthenticationPrincipal UserDetailsImpl userDetails) {
        return ResponseEntity.ok(ApiResponse.ok(transportService.getTransporterEarnings(userDetails.getId())));
    }

    @PostMapping("/vehicles")
    @PreAuthorize("hasAuthority('ROLE_TRANSPORTER')")
    @Operation(summary = "Register a new vehicle in transporter fleet")
    public ResponseEntity<ApiResponse<VehicleDto>> addVehicle(@Valid @RequestBody VehicleDto dto,
                                                             @AuthenticationPrincipal UserDetailsImpl userDetails) {
        return ResponseEntity.ok(ApiResponse.ok("Vehicle added", transportService.addVehicle(dto, userDetails.getId())));
    }

    @GetMapping("/vehicles")
    @PreAuthorize("hasAuthority('ROLE_TRANSPORTER')")
    @Operation(summary = "Get transporter's registered fleet of vehicles")
    public ResponseEntity<ApiResponse<List<VehicleDto>>> getMyVehicles(@AuthenticationPrincipal UserDetailsImpl userDetails) {
        return ResponseEntity.ok(ApiResponse.ok(transportService.getTransporterVehicles(userDetails.getId())));
    }
}

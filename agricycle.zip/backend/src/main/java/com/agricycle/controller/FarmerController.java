package com.agricycle.controller;

import com.agricycle.dto.ApiResponse;
import com.agricycle.entity.OrderStatus;
import com.agricycle.repository.HarvestRepository;
import com.agricycle.repository.ListingRepository;
import com.agricycle.repository.OrderRepository;
import com.agricycle.security.UserDetailsImpl;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/farmers")
@PreAuthorize("hasAuthority('ROLE_FARMER')")
@Tag(name = "Farmer Dashboard", description = "Farmer operational center, earnings, metrics, and active sales")
public class FarmerController {

    private final HarvestRepository harvestRepository;
    private final ListingRepository listingRepository;
    private final OrderRepository orderRepository;

    public FarmerController(HarvestRepository harvestRepository,
                            ListingRepository listingRepository,
                            OrderRepository orderRepository) {
        this.harvestRepository = harvestRepository;
        this.listingRepository = listingRepository;
        this.orderRepository = orderRepository;
    }

    @GetMapping("/dashboard")
    @Operation(summary = "Get Farmer dashboard analytics and operational summary")
    public ResponseEntity<ApiResponse<Map<String, Object>>> getFarmerDashboard(@AuthenticationPrincipal UserDetailsImpl userDetails) {
        Long farmerId = userDetails.getId();
        Map<String, Object> stats = new HashMap<>();

        stats.put("totalHarvests", harvestRepository.countByFarmer_Id(farmerId));
        stats.put("totalListings", listingRepository.findBySeller_IdOrderByCreatedAtDesc(farmerId).size());
        stats.put("pendingOrders", orderRepository.countBySeller_IdAndStatus(farmerId, OrderStatus.PENDING));
        stats.put("activeOrders", orderRepository.countBySeller_IdAndStatus(farmerId, OrderStatus.CONFIRMED) +
                                  orderRepository.countBySeller_IdAndStatus(farmerId, OrderStatus.TRANSPORT_ASSIGNED) +
                                  orderRepository.countBySeller_IdAndStatus(farmerId, OrderStatus.IN_TRANSIT));
        stats.put("completedOrders", orderRepository.countBySeller_IdAndStatus(farmerId, OrderStatus.COMPLETED));

        Double earnings = orderRepository.sumCompletedEarningsBySellerId(farmerId);
        stats.put("totalEarnings", earnings != null ? earnings : 0.0);

        return ResponseEntity.ok(ApiResponse.ok(stats));
    }
}

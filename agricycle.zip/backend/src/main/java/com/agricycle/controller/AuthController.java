package com.agricycle.controller;

import com.agricycle.dto.*;
import com.agricycle.security.UserDetailsImpl;
import com.agricycle.service.AuthService;
import com.agricycle.service.UserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/auth")
@Tag(name = "Authentication", description = "Secure authentication, registration, JWT tokens, and password reset")
public class AuthController {

    private final AuthService authService;
    private final UserService userService;

    public AuthController(AuthService authService, UserService userService) {
        this.authService = authService;
        this.userService = userService;
    }

    @PostMapping("/register")
    @Operation(summary = "Register a new user (Farmer, Livestock Owner, Company, Transporter)")
    public ResponseEntity<ApiResponse<AuthResponse>> register(@Valid @RequestBody RegisterRequest req, HttpServletRequest request) {
        String clientIp = request.getRemoteAddr();
        AuthResponse res = authService.register(req, clientIp);
        return ResponseEntity.ok(ApiResponse.ok("Registration successful", res));
    }

    @PostMapping("/login")
    @Operation(summary = "User login with JWT authentication")
    public ResponseEntity<ApiResponse<AuthResponse>> login(@Valid @RequestBody LoginRequest req, HttpServletRequest request) {
        String clientIp = request.getRemoteAddr();
        AuthResponse res = authService.login(req, clientIp);
        return ResponseEntity.ok(ApiResponse.ok("Login successful", res));
    }

    @PostMapping("/refresh")
    @Operation(summary = "Refresh expired JWT access token")
    public ResponseEntity<ApiResponse<AuthResponse>> refreshToken(@Valid @RequestBody RefreshTokenRequest req) {
        AuthResponse res = authService.refreshToken(req);
        return ResponseEntity.ok(ApiResponse.ok("Token refreshed successfully", res));
    }

    @PostMapping("/reset-password")
    @Operation(summary = "Reset account password")
    public ResponseEntity<ApiResponse<String>> resetPassword(@Valid @RequestBody PasswordResetRequest req, HttpServletRequest request) {
        String clientIp = request.getRemoteAddr();
        authService.resetPassword(req, clientIp);
        return ResponseEntity.ok(ApiResponse.ok("Password reset successfully", null));
    }

    @GetMapping("/me")
    @Operation(summary = "Get current authenticated user profile summary")
    public ResponseEntity<ApiResponse<UserDto>> getCurrentUser(@AuthenticationPrincipal UserDetailsImpl userDetails) {
        if (userDetails == null) {
            return ResponseEntity.ok(ApiResponse.error("Unauthenticated"));
        }
        UserDto dto = userService.getUserSummary(userDetails.getId());
        return ResponseEntity.ok(ApiResponse.ok(dto));
    }
}

package com.agricycle.controller;

import com.agricycle.dto.ApiResponse;
import com.agricycle.entity.TransportStatus;
import com.agricycle.repository.TransportJobRepository;
import com.agricycle.security.UserDetailsImpl;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/transporters")
@PreAuthorize("hasAuthority('ROLE_TRANSPORTER')")
@Tag(name = "Transporter Dashboard", description = "Transporter logistics control, active dispatches, and delivery revenue")
public class TransporterController {

    private final TransportJobRepository transportJobRepository;

    public TransporterController(TransportJobRepository transportJobRepository) {
        this.transportJobRepository = transportJobRepository;
    }

    @GetMapping("/dashboard")
    @Operation(summary = "Get Transporter dashboard operational summary")
    public ResponseEntity<ApiResponse<Map<String, Object>>> getTransporterDashboard(@AuthenticationPrincipal UserDetailsImpl userDetails) {
        Long transporterId = userDetails.getId();
        Map<String, Object> stats = new HashMap<>();

        stats.put("availableJobs", transportJobRepository.findByStatus(TransportStatus.REQUESTED).size());
        stats.put("activeDeliveries", transportJobRepository.countByTransporter_IdAndStatus(transporterId, TransportStatus.ASSIGNED) +
                                      transportJobRepository.countByTransporter_IdAndStatus(transporterId, TransportStatus.PICKED_UP) +
                                      transportJobRepository.countByTransporter_IdAndStatus(transporterId, TransportStatus.IN_TRANSIT));
        stats.put("completedDeliveries", transportJobRepository.countByTransporter_IdAndStatus(transporterId, TransportStatus.COMPLETED) +
                                         transportJobRepository.countByTransporter_IdAndStatus(transporterId, TransportStatus.DELIVERED));

        Double earnings = transportJobRepository.sumTransporterEarnings(transporterId);
        stats.put("totalEarnings", earnings != null ? earnings : 0.0);

        return ResponseEntity.ok(ApiResponse.ok(stats));
    }
}

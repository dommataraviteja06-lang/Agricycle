package com.agricycle.controller;

import com.agricycle.dto.ApiResponse;
import com.agricycle.entity.OrderStatus;
import com.agricycle.repository.OrderRepository;
import com.agricycle.repository.RequirementRepository;
import com.agricycle.security.UserDetailsImpl;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/companies")
@PreAuthorize("hasAuthority('ROLE_COMPANY')")
@Tag(name = "Company Dashboard", description = "Company dashboard, material procurement, bulk requirements, and supplier offers")
public class CompanyController {

    private final RequirementRepository requirementRepository;
    private final OrderRepository orderRepository;

    public CompanyController(RequirementRepository requirementRepository,
                             OrderRepository orderRepository) {
        this.requirementRepository = requirementRepository;
        this.orderRepository = orderRepository;
    }

    @GetMapping("/dashboard")
    @Operation(summary = "Get Company dashboard operational metrics")
    public ResponseEntity<ApiResponse<Map<String, Object>>> getCompanyDashboard(@AuthenticationPrincipal UserDetailsImpl userDetails) {
        Long userId = userDetails.getId();
        Map<String, Object> stats = new HashMap<>();

        stats.put("myRequirements", requirementRepository.findByUser_IdOrderByCreatedAtDesc(userId).size());
        stats.put("activeOrders", orderRepository.countByBuyer_IdAndStatus(userId, OrderStatus.CONFIRMED) +
                                  orderRepository.countByBuyer_IdAndStatus(userId, OrderStatus.TRANSPORT_ASSIGNED) +
                                  orderRepository.countByBuyer_IdAndStatus(userId, OrderStatus.IN_TRANSIT));
        stats.put("completedOrders", orderRepository.countByBuyer_IdAndStatus(userId, OrderStatus.COMPLETED));

        return ResponseEntity.ok(ApiResponse.ok(stats));
    }
}

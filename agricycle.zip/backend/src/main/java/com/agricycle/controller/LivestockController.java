package com.agricycle.controller;

import com.agricycle.dto.ApiResponse;
import com.agricycle.entity.OrderStatus;
import com.agricycle.entity.RequirementStatus;
import com.agricycle.repository.OrderRepository;
import com.agricycle.repository.RequirementRepository;
import com.agricycle.security.UserDetailsImpl;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/livestock")
@PreAuthorize("hasAuthority('ROLE_LIVESTOCK_OWNER')")
@Tag(name = "Livestock Dashboard", description = "Livestock owner dashboard, fodder orders, and urgent feed requests")
public class LivestockController {

    private final OrderRepository orderRepository;
    private final RequirementRepository requirementRepository;

    public LivestockController(OrderRepository orderRepository,
                               RequirementRepository requirementRepository) {
        this.orderRepository = orderRepository;
        this.requirementRepository = requirementRepository;
    }

    @GetMapping("/dashboard")
    @Operation(summary = "Get Livestock Owner dashboard summary")
    public ResponseEntity<ApiResponse<Map<String, Object>>> getLivestockDashboard(@AuthenticationPrincipal UserDetailsImpl userDetails) {
        Long userId = userDetails.getId();
        Map<String, Object> stats = new HashMap<>();

        stats.put("activeOrders", orderRepository.countByBuyerIdAndStatus(userId, OrderStatus.CONFIRMED) +
                                  orderRepository.countByBuyerIdAndStatus(userId, OrderStatus.TRANSPORT_ASSIGNED) +
                                  orderRepository.countByBuyerIdAndStatus(userId, OrderStatus.IN_TRANSIT));
        stats.put("completedOrders", orderRepository.countByBuyerIdAndStatus(userId, OrderStatus.COMPLETED));
        stats.put("pendingOrders", orderRepository.countByBuyerIdAndStatus(userId, OrderStatus.PENDING));
        stats.put("openEmergencyRequests", requirementRepository.countByEmergencyTrueAndStatus(RequirementStatus.OPEN));

        return ResponseEntity.ok(ApiResponse.ok(stats));
    }
}

package com.agricycle.controller;

import com.agricycle.dto.ApiResponse;
import com.agricycle.dto.CreateHarvestRequest;
import com.agricycle.dto.HarvestDto;
import com.agricycle.dto.SellableOutputRecommendationDto;
import com.agricycle.security.UserDetailsImpl;
import com.agricycle.service.HarvestService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/harvests")
@Tag(name = "Harvests", description = "Farmer harvest management and multi-stream sellable outputs")
public class HarvestController {

    private final HarvestService harvestService;

    public HarvestController(HarvestService harvestService) {
        this.harvestService = harvestService;
    }

    @PostMapping
    @PreAuthorize("hasAuthority('ROLE_FARMER')")
    @Operation(summary = "Record a new harvest (Farmer only)")
    public ResponseEntity<ApiResponse<HarvestDto>> createHarvest(@Valid @RequestBody CreateHarvestRequest req,
                                                                 @AuthenticationPrincipal UserDetailsImpl userDetails,
                                                                 HttpServletRequest request) {
        HarvestDto dto = harvestService.createHarvest(req, userDetails.getId(), request.getRemoteAddr());
        return ResponseEntity.ok(ApiResponse.ok("Harvest recorded successfully", dto));
    }

    @GetMapping("/my")
    @PreAuthorize("hasAuthority('ROLE_FARMER')")
    @Operation(summary = "Get current farmer's recorded harvests")
    public ResponseEntity<ApiResponse<List<HarvestDto>>> getMyHarvests(@AuthenticationPrincipal UserDetailsImpl userDetails) {
        return ResponseEntity.ok(ApiResponse.ok(harvestService.getFarmerHarvests(userDetails.getId())));
    }

    @GetMapping("/{id}")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Get harvest details by ID")
    public ResponseEntity<ApiResponse<HarvestDto>> getHarvestById(@PathVariable Long id,
                                                                 @AuthenticationPrincipal UserDetailsImpl userDetails) {
        return ResponseEntity.ok(ApiResponse.ok(harvestService.getHarvestById(id, userDetails.getId())));
    }

    @GetMapping("/recommended-outputs")
    @Operation(summary = "Get multi-market sellable outputs for a crop (e.g. Rice -> Rice Grain, Straw, Husk)")
    public ResponseEntity<ApiResponse<List<SellableOutputRecommendationDto>>> getRecommendedOutputs(@RequestParam String cropName) {
        return ResponseEntity.ok(ApiResponse.ok(harvestService.getRecommendedSellableOutputs(cropName)));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAuthority('ROLE_FARMER')")
    @Operation(summary = "Delete harvest (Owner only)")
    public ResponseEntity<ApiResponse<Void>> deleteHarvest(@PathVariable Long id,
                                                           @AuthenticationPrincipal UserDetailsImpl userDetails,
                                                           HttpServletRequest request) {
        harvestService.deleteHarvest(id, userDetails.getId(), request.getRemoteAddr());
        return ResponseEntity.ok(ApiResponse.ok("Harvest deleted successfully", null));
    }
}

package com.agricycle.controller;

import com.agricycle.dto.*;
import com.agricycle.service.AiService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/ai")
@Tag(name = "AI Engine", description = "AI Matching Engine, Best-Use Suggestions, Price Estimation, Demand Analytics, Harvest Recovery Calculator, and Environmental Impact")
public class AiController {

    private final AiService aiService;

    public AiController(AiService aiService) {
        this.aiService = aiService;
    }

    @GetMapping("/match")
    @Operation(summary = "AI Match Engine: Calculate multi-factor match score between Listing and Requirement")
    public ResponseEntity<ApiResponse<AiMatchScoreDto>> computeMatch(@RequestParam Long listingId,
                                                                     @RequestParam Long requirementId) {
        return ResponseEntity.ok(ApiResponse.ok(aiService.computeMatch(listingId, requirementId)));
    }

    @GetMapping("/best-use/{materialName}")
    @Operation(summary = "AI Best-Use: Recommend optimal buyer categories and downstream applications for a crop residue or fodder")
    public ResponseEntity<ApiResponse<BestUseRecommendationDto>> getBestUse(@PathVariable String materialName) {
        return ResponseEntity.ok(ApiResponse.ok(aiService.getBestUseRecommendations(materialName)));
    }

    @GetMapping("/suggested-price")
    @Operation(summary = "AI Suggested Price: Internal market transactions and regional listing pricing engine")
    public ResponseEntity<ApiResponse<PriceRecommendationDto>> getSuggestedPrice(@RequestParam String materialName,
                                                                                 @RequestParam(required = false, defaultValue = "Tons") String unit) {
        return ResponseEntity.ok(ApiResponse.ok(aiService.getSuggestedPrice(materialName, unit)));
    }

    @GetMapping("/demand-analysis/{materialName}")
    @Operation(summary = "AI Demand Analysis: Trend appetite index, regional hotspots, and monthly chart data")
    public ResponseEntity<ApiResponse<DemandAnalysisDto>> getDemandAnalysis(@PathVariable String materialName) {
        return ResponseEntity.ok(ApiResponse.ok(aiService.getDemandAnalysis(materialName)));
    }

    @PostMapping("/harvest-calculator")
    @Operation(summary = "Harvest Value Calculator: Multi-market recovery calculator (Main Harvest + Fodder + Residue = Total Recovery Value)")
    public ResponseEntity<ApiResponse<HarvestValueCalculatorResponse>> calculateHarvestValue(@Valid @RequestBody HarvestValueCalculatorRequest req) {
        return ResponseEntity.ok(ApiResponse.ok(aiService.calculateHarvestValue(req)));
    }

    @GetMapping("/environmental-impact")
    @Operation(summary = "Environmental Impact Dashboard: Quantified residue diverted, stubble burning avoided, and CO2 mitigation estimates")
    public ResponseEntity<ApiResponse<EnvironmentalImpactDto>> getEnvironmentalImpact() {
        return ResponseEntity.ok(ApiResponse.ok(aiService.getEnvironmentalImpact()));
    }

    @GetMapping("/market-demand-trends")
    @Operation(summary = "Get high-level market demand trends across key crops")
    public ResponseEntity<ApiResponse<java.util.List<java.util.Map<String, Object>>>> getMarketDemandTrends() {
        return ResponseEntity.ok(ApiResponse.ok(aiService.getMarketDemandTrends()));
    }
}

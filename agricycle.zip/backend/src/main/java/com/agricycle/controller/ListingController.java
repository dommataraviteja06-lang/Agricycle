package com.agricycle.controller;

import com.agricycle.dto.ApiResponse;
import com.agricycle.dto.CreateListingRequest;
import com.agricycle.dto.ListingDto;
import com.agricycle.entity.CategoryType;
import com.agricycle.security.UserDetailsImpl;
import com.agricycle.service.ListingService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/listings")
@Tag(name = "Listings", description = "Marketplace listings, search, Digital Lot IDs, and filters")
public class ListingController {

    private final ListingService listingService;

    public ListingController(ListingService listingService) {
        this.listingService = listingService;
    }

    @PostMapping
    @PreAuthorize("hasAuthority('ROLE_FARMER')")
    @Operation(summary = "Create a marketplace listing from a harvest or standalone (Farmer)")
    public ResponseEntity<ApiResponse<ListingDto>> createListing(@Valid @RequestBody CreateListingRequest req,
                                                                @AuthenticationPrincipal UserDetailsImpl userDetails,
                                                                HttpServletRequest request) {
        ListingDto dto = listingService.createListing(req, userDetails.getId(), request.getRemoteAddr());
        return ResponseEntity.ok(ApiResponse.ok("Marketplace listing created successfully", dto));
    }

    @GetMapping({"/public", "/search"})
    @Operation(summary = "Search marketplace listings with multi-filter and sorting")
    public ResponseEntity<ApiResponse<Page<ListingDto>>> searchMarketplace(
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) Long categoryId,
            @RequestParam(required = false) CategoryType categoryType,
            @RequestParam(required = false) String district,
            @RequestParam(required = false) String state,
            @RequestParam(required = false) Double minPrice,
            @RequestParam(required = false) Double maxPrice,
            @RequestParam(required = false) Double minQty,
            @RequestParam(required = false, defaultValue = "recent") String sortBy,
            @RequestParam(required = false, defaultValue = "0") int page,
            @RequestParam(required = false, defaultValue = "12") int size) {
        Page<ListingDto> results = listingService.searchMarketplace(keyword, categoryId, categoryType, district, state, minPrice, maxPrice, minQty, sortBy, page, size);
        return ResponseEntity.ok(ApiResponse.ok(results));
    }

    @GetMapping("/fodder")
    @Operation(summary = "Dedicated Find Fodder search for livestock owners")
    public ResponseEntity<ApiResponse<Page<ListingDto>>> searchFodder(
            @RequestParam(required = false) String district,
            @RequestParam(required = false) Double minQty,
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false, defaultValue = "0") int page,
            @RequestParam(required = false, defaultValue = "12") int size) {
        return ResponseEntity.ok(ApiResponse.ok(listingService.searchFodder(district, minQty, keyword, page, size)));
    }

    @GetMapping("/residue")
    @Operation(summary = "Search agricultural residue and biomass for industrial buyers")
    public ResponseEntity<ApiResponse<Page<ListingDto>>> searchResidue(
            @RequestParam(required = false) String district,
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false, defaultValue = "0") int page,
            @RequestParam(required = false, defaultValue = "12") int size) {
        return ResponseEntity.ok(ApiResponse.ok(listingService.searchResidue(district, keyword, page, size)));
    }

    @GetMapping({"/{id}", "/public/{id}"})
    @Operation(summary = "Get listing details by ID")
    public ResponseEntity<ApiResponse<ListingDto>> getListingDetails(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.ok(listingService.getListingDetails(id)));
    }

    @GetMapping("/lot/{lotId}")
    @Operation(summary = "Lookup listing by unique Digital Lot ID (e.g. AGC-RICE-TG-2026-000145)")
    public ResponseEntity<ApiResponse<ListingDto>> getListingByLotId(@PathVariable String lotId) {
        return ResponseEntity.ok(ApiResponse.ok(listingService.getListingByLotId(lotId)));
    }

    @GetMapping("/my")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Get current user's listings")
    public ResponseEntity<ApiResponse<List<ListingDto>>> getMyListings(@AuthenticationPrincipal UserDetailsImpl userDetails) {
        return ResponseEntity.ok(ApiResponse.ok(listingService.getSellerListings(userDetails.getId())));
    }

    @GetMapping("/harvest/{harvestId}")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Get all sellable listings generated from a specific harvest")
    public ResponseEntity<ApiResponse<List<ListingDto>>> getHarvestListings(@PathVariable Long harvestId) {
        return ResponseEntity.ok(ApiResponse.ok(listingService.getHarvestListings(harvestId)));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Delete listing (Owner only)")
    public ResponseEntity<ApiResponse<Void>> deleteListing(@PathVariable Long id,
                                                           @AuthenticationPrincipal UserDetailsImpl userDetails,
                                                           HttpServletRequest request) {
        listingService.deleteListing(id, userDetails.getId(), request.getRemoteAddr());
        return ResponseEntity.ok(ApiResponse.ok("Listing deleted successfully", null));
    }
}

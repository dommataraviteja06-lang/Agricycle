package com.agricycle.controller;

import com.agricycle.dto.*;
import com.agricycle.security.UserDetailsImpl;
import com.agricycle.service.FileStorageService;
import com.agricycle.service.UserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api/v1/users")
@Tag(name = "Users", description = "User profiles and media upload")
public class UserController {

    private final UserService userService;
    private final FileStorageService fileStorageService;

    public UserController(UserService userService, FileStorageService fileStorageService) {
        this.userService = userService;
        this.fileStorageService = fileStorageService;
    }

    @GetMapping("/{id}/summary")
    @Operation(summary = "Get public summary and ratings for any user")
    public ResponseEntity<ApiResponse<UserDto>> getUserSummary(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.ok(userService.getUserSummary(id)));
    }

    @GetMapping("/farmer-profile")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Get farmer profile details")
    public ResponseEntity<ApiResponse<FarmerProfileDto>> getFarmerProfile(
            @RequestParam(required = false) Long userId,
            @AuthenticationPrincipal UserDetailsImpl userDetails) {
        Long targetId = userId != null ? userId : userDetails.getId();
        return ResponseEntity.ok(ApiResponse.ok(userService.getFarmerProfile(targetId)));
    }

    @GetMapping("/livestock-profile")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Get livestock owner profile details")
    public ResponseEntity<ApiResponse<LivestockProfileDto>> getLivestockProfile(
            @RequestParam(required = false) Long userId,
            @AuthenticationPrincipal UserDetailsImpl userDetails) {
        Long targetId = userId != null ? userId : userDetails.getId();
        return ResponseEntity.ok(ApiResponse.ok(userService.getLivestockProfile(targetId)));
    }

    @GetMapping("/company-profile")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Get company profile details")
    public ResponseEntity<ApiResponse<CompanyProfileDto>> getCompanyProfile(
            @RequestParam(required = false) Long userId,
            @AuthenticationPrincipal UserDetailsImpl userDetails) {
        Long targetId = userId != null ? userId : userDetails.getId();
        boolean isOwnerOrAdmin = targetId.equals(userDetails.getId()) || userDetails.getRole().name().equals("ROLE_ADMIN");
        return ResponseEntity.ok(ApiResponse.ok(userService.getCompanyProfile(targetId, isOwnerOrAdmin)));
    }

    @GetMapping("/transport-profile")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Get transport provider profile details")
    public ResponseEntity<ApiResponse<TransportProfileDto>> getTransportProfile(
            @RequestParam(required = false) Long userId,
            @AuthenticationPrincipal UserDetailsImpl userDetails) {
        Long targetId = userId != null ? userId : userDetails.getId();
        return ResponseEntity.ok(ApiResponse.ok(userService.getTransportProfile(targetId)));
    }

    @PostMapping(value = "/upload-image", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Securely upload an image (product, harvest, or profile) with MIME and size verification")
    public ResponseEntity<ApiResponse<String>> uploadImage(@RequestParam("file") MultipartFile file,
                                                           @RequestParam(defaultValue = "listings") String folder) {
        String savedPath = fileStorageService.storeFile(file, folder);
        return ResponseEntity.ok(ApiResponse.ok("File uploaded successfully", savedPath));
    }
}

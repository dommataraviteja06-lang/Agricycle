package com.agricycle.controller;

import com.agricycle.dto.ApiResponse;
import com.agricycle.dto.PaymentDto;
import com.agricycle.dto.ProcessPaymentRequest;
import com.agricycle.security.UserDetailsImpl;
import com.agricycle.service.PaymentService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/payments")
@Tag(name = "Payments", description = "Escrow payment simulation, references, and verification")
public class PaymentController {

    private final PaymentService paymentService;

    public PaymentController(PaymentService paymentService) {
        this.paymentService = paymentService;
    }

    @PostMapping("/process")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Authorize escrow payment for an order")
    public ResponseEntity<ApiResponse<PaymentDto>> processPayment(@Valid @RequestBody ProcessPaymentRequest req,
                                                                  @AuthenticationPrincipal UserDetailsImpl userDetails,
                                                                  HttpServletRequest request) {
        PaymentDto dto = paymentService.processPayment(req, userDetails.getId(), request.getRemoteAddr());
        return ResponseEntity.ok(ApiResponse.ok("Payment authorized and held securely in escrow", dto));
    }

    @GetMapping("/order/{orderId}")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Get payment receipt by order ID")
    public ResponseEntity<ApiResponse<PaymentDto>> getPaymentByOrder(@PathVariable Long orderId,
                                                                     @AuthenticationPrincipal UserDetailsImpl userDetails) {
        return ResponseEntity.ok(ApiResponse.ok(paymentService.getPaymentByOrderId(orderId, userDetails.getId())));
    }
}

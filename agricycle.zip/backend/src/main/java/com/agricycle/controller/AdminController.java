package com.agricycle.controller;

import com.agricycle.dto.*;
import com.agricycle.entity.ListingStatus;
import com.agricycle.entity.Role;
import com.agricycle.entity.UserStatus;
import com.agricycle.security.UserDetailsImpl;
import com.agricycle.service.*;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/admin")
@PreAuthorize("hasAuthority('ROLE_ADMIN')")
@Tag(name = "Super Admin", description = "Administrative dashboard, platform security, user moderation, audit logs, and system controls")
public class AdminController {

    private final AdminService adminService;
    private final ListingService listingService;
    private final CategoryService categoryService;
    private final ReviewService reviewService;
    private final AuditService auditService;

    public AdminController(AdminService adminService,
                           ListingService listingService,
                           CategoryService categoryService,
                           ReviewService reviewService,
                           AuditService auditService) {
        this.adminService = adminService;
        this.listingService = listingService;
        this.categoryService = categoryService;
        this.reviewService = reviewService;
        this.auditService = auditService;
    }

    @GetMapping("/stats")
    @Operation(summary = "Super Admin Dashboard: High-level platform metrics and operational volume")
    public ResponseEntity<ApiResponse<AdminStatsDto>> getPlatformStats() {
        return ResponseEntity.ok(ApiResponse.ok(adminService.getPlatformStats()));
    }

    @GetMapping("/users")
    @Operation(summary = "Admin: Search, filter, and inspect registered users")
    public ResponseEntity<ApiResponse<Page<UserDto>>> searchUsers(
            @RequestParam(required = false) Role role,
            @RequestParam(required = false) UserStatus status,
            @RequestParam(required = false) String search,
            @RequestParam(required = false, defaultValue = "0") int page,
            @RequestParam(required = false, defaultValue = "15") int size) {
        return ResponseEntity.ok(ApiResponse.ok(adminService.searchUsers(role, status, search, page, size)));
    }

    @PatchMapping("/users/{id}/status")
    @Operation(summary = "Admin: Suspend, reactivate, or verify user accounts")
    public ResponseEntity<ApiResponse<Void>> updateUserStatus(
            @PathVariable Long id,
            @RequestParam UserStatus status,
            @AuthenticationPrincipal UserDetailsImpl adminDetails,
            HttpServletRequest request) {
        adminService.updateUserStatus(id, status, adminDetails.getId(), request.getRemoteAddr());
        return ResponseEntity.ok(ApiResponse.ok("User status updated to: " + status, null));
    }

    @PatchMapping("/listings/{id}/status")
    @Operation(summary = "Admin: Approve, reject, or suspend marketplace listings")
    public ResponseEntity<ApiResponse<ListingDto>> updateListingStatus(
            @PathVariable Long id,
            @RequestParam ListingStatus status,
            @AuthenticationPrincipal UserDetailsImpl adminDetails,
            HttpServletRequest request) {
        ListingDto dto = listingService.updateStatusByAdmin(id, status, adminDetails.getId(), request.getRemoteAddr());
        return ResponseEntity.ok(ApiResponse.ok("Listing status updated", dto));
    }

    @GetMapping("/audit-logs")
    @Operation(summary = "Admin: View immutable audit logs of security, login, and business operations")
    public ResponseEntity<ApiResponse<List<com.agricycle.entity.AuditLog>>> getAuditLogs() {
        return ResponseEntity.ok(ApiResponse.ok(auditService.getRecentLogs()));
    }

    @GetMapping("/reported-reviews")
    @Operation(summary = "Admin: View flagged/reported user reviews for moderation")
    public ResponseEntity<ApiResponse<List<ReviewDto>>> getReportedReviews() {
        return ResponseEntity.ok(ApiResponse.ok(reviewService.getReportedReviewsForAdmin()));
    }

    @DeleteMapping("/reviews/{id}")
    @Operation(summary = "Admin: Moderate and delete abusive review")
    public ResponseEntity<ApiResponse<Void>> deleteReview(
            @PathVariable Long id,
            @AuthenticationPrincipal UserDetailsImpl adminDetails,
            HttpServletRequest request) {
        reviewService.deleteReviewByAdmin(id, adminDetails.getId(), request.getRemoteAddr());
        return ResponseEntity.ok(ApiResponse.ok("Review removed", null));
    }

    // Category administration
    @GetMapping("/categories")
    @Operation(summary = "Admin: List all categories including inactive ones")
    public ResponseEntity<ApiResponse<List<CategoryDto>>> getAllCategories() {
        return ResponseEntity.ok(ApiResponse.ok(categoryService.getAllCategoriesForAdmin()));
    }

    @PostMapping("/categories")
    @Operation(summary = "Admin: Create a new marketplace category")
    public ResponseEntity<ApiResponse<CategoryDto>> createCategory(@Valid @RequestBody CategoryDto dto) {
        return ResponseEntity.ok(ApiResponse.ok("Category created", categoryService.createCategory(dto)));
    }

    @PutMapping("/categories/{id}")
    @Operation(summary = "Admin: Edit an existing category")
    public ResponseEntity<ApiResponse<CategoryDto>> updateCategory(@PathVariable Long id, @Valid @RequestBody CategoryDto dto) {
        return ResponseEntity.ok(ApiResponse.ok("Category updated", categoryService.updateCategory(id, dto)));
    }

    @PatchMapping("/categories/{id}/toggle")
    @Operation(summary = "Admin: Activate or deactivate a category")
    public ResponseEntity<ApiResponse<Void>> toggleCategory(@PathVariable Long id) {
        categoryService.toggleActiveStatus(id);
        return ResponseEntity.ok(ApiResponse.ok("Category status toggled", null));
    }
}

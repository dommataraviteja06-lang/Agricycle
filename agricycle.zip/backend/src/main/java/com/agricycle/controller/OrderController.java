package com.agricycle.controller;

import com.agricycle.dto.*;
import com.agricycle.security.UserDetailsImpl;
import com.agricycle.service.NegotiationService;
import com.agricycle.service.OrderService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/orders")
@Tag(name = "Orders", description = "Order management, lifecycle transitions, and price/quantity negotiations")
public class OrderController {

    private final OrderService orderService;
    private final NegotiationService negotiationService;

    public OrderController(OrderService orderService, NegotiationService negotiationService) {
        this.orderService = orderService;
        this.negotiationService = negotiationService;
    }

    @PostMapping
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Place an order for a marketplace listing")
    public ResponseEntity<ApiResponse<OrderDto>> createOrder(@Valid @RequestBody CreateOrderRequest req,
                                                             @AuthenticationPrincipal UserDetailsImpl userDetails,
                                                             HttpServletRequest request) {
        OrderDto dto = orderService.createOrder(req, userDetails.getId(), request.getRemoteAddr());
        return ResponseEntity.ok(ApiResponse.ok("Order placed successfully", dto));
    }

    @GetMapping("/buyer")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Get current user's purchased orders")
    public ResponseEntity<ApiResponse<List<OrderDto>>> getBuyerOrders(@AuthenticationPrincipal UserDetailsImpl userDetails) {
        return ResponseEntity.ok(ApiResponse.ok(orderService.getBuyerOrders(userDetails.getId())));
    }

    @GetMapping("/seller")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Get current user's received seller orders")
    public ResponseEntity<ApiResponse<List<OrderDto>>> getSellerOrders(@AuthenticationPrincipal UserDetailsImpl userDetails) {
        return ResponseEntity.ok(ApiResponse.ok(orderService.getSellerOrders(userDetails.getId())));
    }

    @GetMapping("/{id}")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Get order details by ID")
    public ResponseEntity<ApiResponse<OrderDto>> getOrderById(@PathVariable Long id,
                                                             @AuthenticationPrincipal UserDetailsImpl userDetails) {
        return ResponseEntity.ok(ApiResponse.ok(orderService.getOrderById(id, userDetails.getId())));
    }

    @PatchMapping("/{id}/status")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Update order lifecycle status (with RBAC transition validation)")
    public ResponseEntity<ApiResponse<OrderDto>> updateOrderStatus(@PathVariable Long id,
                                                                   @Valid @RequestBody UpdateOrderStatusRequest req,
                                                                   @AuthenticationPrincipal UserDetailsImpl userDetails,
                                                                   HttpServletRequest request) {
        OrderDto dto = orderService.updateOrderStatus(id, req.getStatus(), userDetails.getId(), request.getRemoteAddr());
        return ResponseEntity.ok(ApiResponse.ok("Order status updated", dto));
    }

    // Negotiation
    @PostMapping("/{id}/negotiate")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Submit negotiation proposal / counter-offer on price, quantity, or delivery date")
    public ResponseEntity<ApiResponse<OrderNegotiationDto>> proposeNegotiation(@PathVariable Long id,
                                                                               @Valid @RequestBody NegotiateOrderRequest req,
                                                                               @AuthenticationPrincipal UserDetailsImpl userDetails,
                                                                               HttpServletRequest request) {
        OrderNegotiationDto dto = negotiationService.proposeNegotiation(id, req, userDetails.getId(), request.getRemoteAddr());
        return ResponseEntity.ok(ApiResponse.ok("Negotiation counter-offer submitted", dto));
    }

    @PostMapping("/negotiations/{negotiationId}/accept")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Accept negotiated terms and lock order updates")
    public ResponseEntity<ApiResponse<OrderNegotiationDto>> acceptNegotiation(@PathVariable Long negotiationId,
                                                                              @AuthenticationPrincipal UserDetailsImpl userDetails,
                                                                              HttpServletRequest request) {
        OrderNegotiationDto dto = negotiationService.acceptNegotiation(negotiationId, userDetails.getId(), request.getRemoteAddr());
        return ResponseEntity.ok(ApiResponse.ok("Negotiated terms accepted and updated on order", dto));
    }

    @GetMapping("/{id}/negotiations")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Get negotiation history for an order")
    public ResponseEntity<ApiResponse<List<OrderNegotiationDto>>> getNegotiationHistory(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.ok(negotiationService.getNegotiationHistory(id)));
    }
}

package com.agricycle.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "order_negotiations", indexes = {
    @Index(name = "idx_negotiation_order", columnList = "order_id")
})
public class OrderNegotiation {

    public enum NegotiationStatus {
        PROPOSED,
        COUNTERED,
        ACCEPTED,
        REJECTED
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "order_id", nullable = false)
    private Order order;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "proposed_by_user_id", nullable = false)
    private User proposedByUser;

    @NotNull
    @Column(name = "proposed_price", nullable = false)
    private Double proposedPrice;

    @NotNull
    @Column(name = "proposed_quantity", nullable = false)
    private Double proposedQuantity;

    @Column(name = "proposed_delivery_date")
    private LocalDate proposedDeliveryDate;

    @Column(length = 500)
    private String notes;

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 30)
    private NegotiationStatus status = NegotiationStatus.PROPOSED;

    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
    }

    public OrderNegotiation() {}

    public OrderNegotiation(Order order, User proposedByUser, Double proposedPrice, Double proposedQuantity, LocalDate proposedDeliveryDate, String notes) {
        this.order = order;
        this.proposedByUser = proposedByUser;
        this.proposedPrice = proposedPrice;
        this.proposedQuantity = proposedQuantity;
        this.proposedDeliveryDate = proposedDeliveryDate;
        this.notes = notes;
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Order getOrder() { return order; }
    public void setOrder(Order order) { this.order = order; }

    public User getProposedByUser() { return proposedByUser; }
    public void setProposedByUser(User proposedByUser) { this.proposedByUser = proposedByUser; }

    public Double getProposedPrice() { return proposedPrice; }
    public void setProposedPrice(Double proposedPrice) { this.proposedPrice = proposedPrice; }

    public Double getProposedQuantity() { return proposedQuantity; }
    public void setProposedQuantity(Double proposedQuantity) { this.proposedQuantity = proposedQuantity; }

    public LocalDate getProposedDeliveryDate() { return proposedDeliveryDate; }
    public void setProposedDeliveryDate(LocalDate proposedDeliveryDate) { this.proposedDeliveryDate = proposedDeliveryDate; }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }

    public NegotiationStatus getStatus() { return status; }
    public void setStatus(NegotiationStatus status) { this.status = status; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}

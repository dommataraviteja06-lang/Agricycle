package com.agricycle.entity;

public enum UserStatus {
    ACTIVE,
    PENDING_VERIFICATION,
    SUSPENDED
}

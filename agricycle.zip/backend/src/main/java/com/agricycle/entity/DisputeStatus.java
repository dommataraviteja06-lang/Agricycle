package com.agricycle.entity;

public enum DisputeStatus {
    OPEN,
    UNDER_REVIEW,
    RESOLVED,
    DISMISSED
}

package com.agricycle.entity;

public enum RequirementStatus {
    OPEN,
    MATCHED,
    FULFILLED,
    CLOSED
}

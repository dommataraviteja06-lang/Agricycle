package com.agricycle.entity;

public enum UrgencyLevel {
    LOW,
    MEDIUM,
    HIGH,
    URGENT
}

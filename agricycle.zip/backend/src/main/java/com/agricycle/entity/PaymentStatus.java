package com.agricycle.entity;

public enum PaymentStatus {
    PENDING,
    PAID,
    FAILED,
    REFUNDED
}

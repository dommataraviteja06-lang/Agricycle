package com.agricycle.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDateTime;

@Entity
@Table(name = "listings", indexes = {
    @Index(name = "idx_listing_seller", columnList = "seller_id"),
    @Index(name = "idx_listing_harvest", columnList = "harvest_id"),
    @Index(name = "idx_listing_category", columnList = "category_id"),
    @Index(name = "idx_listing_lot_id", columnList = "lot_id", unique = true),
    @Index(name = "idx_listing_status", columnList = "listing_status"),
    @Index(name = "idx_listing_district", columnList = "district"),
    @Index(name = "idx_listing_state", columnList = "state"),
    @Index(name = "idx_listing_created", columnList = "created_at")
})
public class Listing {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "seller_id", nullable = false)
    private User seller;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "harvest_id")
    private Harvest harvest;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "category_id", nullable = false)
    private Category category;

    @NotBlank
    @Column(nullable = false, length = 150)
    private String title;

    @NotBlank
    @Column(name = "product_material_name", nullable = false, length = 100)
    private String productMaterialName; // e.g. Rice Grain, Rice Straw, Rice Husk

    @NotNull
    @Column(nullable = false)
    private Double quantity;

    @NotNull
    @Column(name = "available_quantity", nullable = false)
    private Double availableQuantity;

    @NotBlank
    @Column(nullable = false, length = 30)
    private String unit; // Tons, Quintals, Bales, Bags, Kg

    @NotNull
    @Column(name = "price_per_unit", nullable = false)
    private Double pricePerUnit;

    @Column(length = 100)
    private String village;

    @NotBlank
    @Column(nullable = false, length = 100)
    private String district;

    @NotBlank
    @Column(nullable = false, length = 100)
    private String state;

    @Column
    private Double latitude;

    @Column
    private Double longitude;

    @Column(name = "lot_id", unique = true, length = 50)
    private String lotId; // e.g. AGC-RICE-TG-2026-000145

    @Column(name = "images_json", length = 1000)
    private String imagesJson;

    @Column(length = 2000)
    private String description;

    @Column(name = "suitable_use", length = 255)
    private String suitableUse; // e.g. Cattle Fodder, Biomass Energy, Paper Pulp, Direct Consumption

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "listing_status", nullable = false, length = 30)
    private ListingStatus listingStatus = ListingStatus.APPROVED;

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "verification_status", nullable = false, length = 30)
    private VerificationStatus verificationStatus = VerificationStatus.VERIFIED;

    @Column(name = "view_count")
    private int viewCount = 0;

    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
        if (this.availableQuantity == null) {
            this.availableQuantity = this.quantity;
        }
    }

    @PreUpdate
    protected void onUpdate() {
        this.updatedAt = LocalDateTime.now();
    }

    public Listing() {}

    public Listing(User seller, Harvest harvest, Category category, String title, String productMaterialName, Double quantity, String unit, Double pricePerUnit, String village, String district, String state) {
        this.seller = seller;
        this.harvest = harvest;
        this.category = category;
        this.title = title;
        this.productMaterialName = productMaterialName;
        this.quantity = quantity;
        this.availableQuantity = quantity;
        this.unit = unit;
        this.pricePerUnit = pricePerUnit;
        this.village = village;
        this.district = district;
        this.state = state;
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public User getSeller() { return seller; }
    public void setSeller(User seller) { this.seller = seller; }

    public Harvest getHarvest() { return harvest; }
    public void setHarvest(Harvest harvest) { this.harvest = harvest; }

    public Category getCategory() { return category; }
    public void setCategory(Category category) { this.category = category; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getProductMaterialName() { return productMaterialName; }
    public void setProductMaterialName(String productMaterialName) { this.productMaterialName = productMaterialName; }

    public Double getQuantity() { return quantity; }
    public void setQuantity(Double quantity) { this.quantity = quantity; }

    public Double getAvailableQuantity() { return availableQuantity; }
    public void setAvailableQuantity(Double availableQuantity) { this.availableQuantity = availableQuantity; }

    public String getUnit() { return unit; }
    public void setUnit(String unit) { this.unit = unit; }

    public Double getPricePerUnit() { return pricePerUnit; }
    public void setPricePerUnit(Double pricePerUnit) { this.pricePerUnit = pricePerUnit; }

    public String getVillage() { return village; }
    public void setVillage(String village) { this.village = village; }

    public String getDistrict() { return district; }
    public void setDistrict(String district) { this.district = district; }

    public String getState() { return state; }
    public void setState(String state) { this.state = state; }

    public Double getLatitude() { return latitude; }
    public void setLatitude(Double latitude) { this.latitude = latitude; }

    public Double getLongitude() { return longitude; }
    public void setLongitude(Double longitude) { this.longitude = longitude; }

    public String getLotId() { return lotId; }
    public void setLotId(String lotId) { this.lotId = lotId; }

    public String getImagesJson() { return imagesJson; }
    public void setImagesJson(String imagesJson) { this.imagesJson = imagesJson; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getSuitableUse() { return suitableUse; }
    public void setSuitableUse(String suitableUse) { this.suitableUse = suitableUse; }

    public ListingStatus getListingStatus() { return listingStatus; }
    public void setListingStatus(ListingStatus listingStatus) { this.listingStatus = listingStatus; }

    public VerificationStatus getVerificationStatus() { return verificationStatus; }
    public void setVerificationStatus(VerificationStatus verificationStatus) { this.verificationStatus = verificationStatus; }

    public int getViewCount() { return viewCount; }
    public void setViewCount(int viewCount) { this.viewCount = viewCount; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }
}

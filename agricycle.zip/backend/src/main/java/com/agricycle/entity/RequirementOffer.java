package com.agricycle.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "requirement_offers", indexes = {
    @Index(name = "idx_offer_requirement", columnList = "requirement_id"),
    @Index(name = "idx_offer_supplier", columnList = "supplier_id"),
    @Index(name = "idx_offer_status", columnList = "status")
})
public class RequirementOffer {

    public enum OfferStatus {
        SUBMITTED,
        ACCEPTED,
        REJECTED,
        AGGREGATED
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "requirement_id", nullable = false)
    private Requirement requirement;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "supplier_id", nullable = false)
    private User supplier; // Farmer or Supplier

    @NotNull
    @Column(name = "offered_quantity", nullable = false)
    private Double offeredQuantity;

    @NotNull
    @Column(name = "price_per_unit", nullable = false)
    private Double pricePerUnit;

    @Column(name = "proposed_delivery_date")
    private LocalDate proposedDeliveryDate;

    @Column(length = 500)
    private String notes;

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 30)
    private OfferStatus status = OfferStatus.SUBMITTED;

    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
    }

    public RequirementOffer() {}

    public RequirementOffer(Requirement requirement, User supplier, Double offeredQuantity, Double pricePerUnit, LocalDate proposedDeliveryDate, String notes) {
        this.requirement = requirement;
        this.supplier = supplier;
        this.offeredQuantity = offeredQuantity;
        this.pricePerUnit = pricePerUnit;
        this.proposedDeliveryDate = proposedDeliveryDate;
        this.notes = notes;
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Requirement getRequirement() { return requirement; }
    public void setRequirement(Requirement requirement) { this.requirement = requirement; }

    public User getSupplier() { return supplier; }
    public void setSupplier(User supplier) { this.supplier = supplier; }

    public Double getOfferedQuantity() { return offeredQuantity; }
    public void setOfferedQuantity(Double offeredQuantity) { this.offeredQuantity = offeredQuantity; }

    public Double getPricePerUnit() { return pricePerUnit; }
    public void setPricePerUnit(Double pricePerUnit) { this.pricePerUnit = pricePerUnit; }

    public LocalDate getProposedDeliveryDate() { return proposedDeliveryDate; }
    public void setProposedDeliveryDate(LocalDate proposedDeliveryDate) { this.proposedDeliveryDate = proposedDeliveryDate; }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }

    public OfferStatus getStatus() { return status; }
    public void setStatus(OfferStatus status) { this.status = status; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}

package com.agricycle.entity;

public enum VerificationStatus {
    PENDING,
    VERIFIED,
    REJECTED
}

package com.agricycle.entity;

public enum RecommendationType {
    BEST_USE,
    PRICE_ESTIMATE,
    DEMAND_TREND,
    MATCHING
}

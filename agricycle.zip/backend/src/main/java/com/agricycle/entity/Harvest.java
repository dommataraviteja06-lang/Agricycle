package com.agricycle.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "harvests", indexes = {
    @Index(name = "idx_harvest_farmer", columnList = "farmer_id"),
    @Index(name = "idx_harvest_crop", columnList = "crop_name"),
    @Index(name = "idx_harvest_district", columnList = "district"),
    @Index(name = "idx_harvest_state", columnList = "state")
})
public class Harvest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "farmer_id", nullable = false)
    private User farmer;

    @NotBlank
    @Column(name = "crop_name", nullable = false, length = 100)
    private String cropName; // e.g. Rice, Wheat, Maize, Cotton, Groundnut, Sugarcane

    @Column(name = "crop_variety", length = 100)
    private String cropVariety; // e.g. Sona Masoori, BPT 5204, Shriram, HD-2967

    @NotNull
    @Column(name = "harvest_date", nullable = false)
    private LocalDate harvestDate;

    @NotNull
    @Column(name = "total_quantity", nullable = false)
    private Double totalQuantity;

    @NotBlank
    @Column(nullable = false, length = 30)
    private String unit; // e.g. Tons, Quintals, Kg

    @Column(length = 100)
    private String village;

    @NotBlank
    @Column(nullable = false, length = 100)
    private String district;

    @NotBlank
    @Column(nullable = false, length = 100)
    private String state;

    @Column(name = "image_url", length = 500)
    private String imageUrl;

    @Column(length = 1000)
    private String description;

    @OneToMany(mappedBy = "harvest", cascade = CascadeType.ALL, orphanRemoval = false)
    private List<Listing> listings = new ArrayList<>();

    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        this.updatedAt = LocalDateTime.now();
    }

    public Harvest() {}

    public Harvest(User farmer, String cropName, String cropVariety, LocalDate harvestDate, Double totalQuantity, String unit, String village, String district, String state) {
        this.farmer = farmer;
        this.cropName = cropName;
        this.cropVariety = cropVariety;
        this.harvestDate = harvestDate;
        this.totalQuantity = totalQuantity;
        this.unit = unit;
        this.village = village;
        this.district = district;
        this.state = state;
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public User getFarmer() { return farmer; }
    public void setFarmer(User farmer) { this.farmer = farmer; }

    public String getCropName() { return cropName; }
    public void setCropName(String cropName) { this.cropName = cropName; }

    public String getCropVariety() { return cropVariety; }
    public void setCropVariety(String cropVariety) { this.cropVariety = cropVariety; }

    public LocalDate getHarvestDate() { return harvestDate; }
    public void setHarvestDate(LocalDate harvestDate) { this.harvestDate = harvestDate; }

    public Double getTotalQuantity() { return totalQuantity; }
    public void setTotalQuantity(Double totalQuantity) { this.totalQuantity = totalQuantity; }

    public String getUnit() { return unit; }
    public void setUnit(String unit) { this.unit = unit; }

    public String getVillage() { return village; }
    public void setVillage(String village) { this.village = village; }

    public String getDistrict() { return district; }
    public void setDistrict(String district) { this.district = district; }

    public String getState() { return state; }
    public void setState(String state) { this.state = state; }

    public String getImageUrl() { return imageUrl; }
    public void setImageUrl(String imageUrl) { this.imageUrl = imageUrl; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public List<Listing> getListings() { return listings; }
    public void setListings(List<Listing> listings) { this.listings = listings; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }
}

package com.agricycle.entity;

public enum CategoryType {
    HARVEST_PRODUCT,
    FODDER,
    AGRICULTURAL_RESIDUE
}

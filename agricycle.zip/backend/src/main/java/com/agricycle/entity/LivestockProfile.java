package com.agricycle.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDateTime;

@Entity
@Table(name = "livestock_profiles", indexes = {
    @Index(name = "idx_livestock_district", columnList = "district"),
    @Index(name = "idx_livestock_state", columnList = "state")
})
public class LivestockProfile {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false, unique = true)
    private User user;

    @Column(name = "animal_type", length = 100)
    private String animalType; // e.g. Cow, Buffalo, Goat, Sheep

    @Column(name = "number_of_animals")
    private Integer numberOfAnimals;

    @Column(name = "feed_preference", length = 100)
    private String feedPreference; // e.g. Dry fodder, Green fodder, Silage

    @Column(length = 100)
    private String village;

    @Column(nullable = false, length = 100)
    private String district;

    @Column(nullable = false, length = 100)
    private String state;

    @Column(name = "required_fodder_types", length = 255)
    private String requiredFodderTypes; // e.g. Rice straw, Maize stalks

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "verification_status", nullable = false, length = 30)
    private VerificationStatus verificationStatus = VerificationStatus.PENDING;

    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
    }

    public LivestockProfile() {}

    public LivestockProfile(User user, String animalType, Integer numberOfAnimals, String feedPreference, String district, String state) {
        this.user = user;
        this.animalType = animalType;
        this.numberOfAnimals = numberOfAnimals;
        this.feedPreference = feedPreference;
        this.district = district;
        this.state = state;
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }

    public String getAnimalType() { return animalType; }
    public void setAnimalType(String animalType) { this.animalType = animalType; }

    public Integer getNumberOfAnimals() { return numberOfAnimals; }
    public void setNumberOfAnimals(Integer numberOfAnimals) { this.numberOfAnimals = numberOfAnimals; }

    public String getFeedPreference() { return feedPreference; }
    public void setFeedPreference(String feedPreference) { this.feedPreference = feedPreference; }

    public String getVillage() { return village; }
    public void setVillage(String village) { this.village = village; }

    public String getDistrict() { return district; }
    public void setDistrict(String district) { this.district = district; }

    public String getState() { return state; }
    public void setState(String state) { this.state = state; }

    public String getRequiredFodderTypes() { return requiredFodderTypes; }
    public void setRequiredFodderTypes(String requiredFodderTypes) { this.requiredFodderTypes = requiredFodderTypes; }

    public VerificationStatus getVerificationStatus() { return verificationStatus; }
    public void setVerificationStatus(VerificationStatus verificationStatus) { this.verificationStatus = verificationStatus; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}

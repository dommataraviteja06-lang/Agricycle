package com.agricycle.entity;

public enum Role {
    ROLE_FARMER,
    ROLE_LIVESTOCK_OWNER,
    ROLE_COMPANY,
    ROLE_TRANSPORTER,
    ROLE_ADMIN
}

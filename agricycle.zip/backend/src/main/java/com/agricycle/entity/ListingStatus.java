package com.agricycle.entity;

public enum ListingStatus {
    DRAFT,
    PENDING_APPROVAL,
    APPROVED,
    REJECTED,
    SOLD,
    EXPIRED,
    SUSPENDED
}

package com.agricycle.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "requirements", indexes = {
    @Index(name = "idx_requirement_user", columnList = "user_id"),
    @Index(name = "idx_requirement_category", columnList = "category_id"),
    @Index(name = "idx_requirement_status", columnList = "status"),
    @Index(name = "idx_requirement_urgency", columnList = "urgency"),
    @Index(name = "idx_requirement_district", columnList = "district"),
    @Index(name = "idx_requirement_created", columnList = "created_at")
})
public class Requirement {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user; // Company or Livestock Owner

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "category_id")
    private Category category;

    @NotBlank
    @Column(name = "material_name", nullable = false, length = 100)
    private String materialName; // e.g. Rice Husk, Dry Fodder, Wheat Straw

    @NotNull
    @Column(name = "quantity_required", nullable = false)
    private Double quantityRequired;

    @Column(name = "fulfilled_quantity")
    private Double fulfilledQuantity = 0.0;

    @NotBlank
    @Column(nullable = false, length = 30)
    private String unit; // Tons, Quintals, Kg

    @Column(name = "target_price")
    private Double targetPrice; // per unit target price

    @Column(length = 100)
    private String village;

    @NotBlank
    @Column(nullable = false, length = 100)
    private String district;

    @NotBlank
    @Column(nullable = false, length = 100)
    private String state;

    @Column(name = "required_by_date")
    private LocalDate requiredByDate;

    // Emergency Fodder specific fields
    @Column(name = "animal_type", length = 100)
    private String animalType; // Cow, Buffalo, Goat, etc.

    @Column(name = "number_of_animals")
    private Integer numberOfAnimals;

    @Column(name = "is_emergency", nullable = false)
    private boolean emergency = false;

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 30)
    private UrgencyLevel urgency = UrgencyLevel.MEDIUM;

    @Column(name = "quality_requirement", length = 500)
    private String qualityRequirement;

    @Column(length = 1500)
    private String description;

    @Column(name = "delivery_requirement", length = 500)
    private String deliveryRequirement;

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 30)
    private RequirementStatus status = RequirementStatus.OPEN;

    @OneToMany(mappedBy = "requirement", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<RequirementOffer> offers = new ArrayList<>();

    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
        if (this.fulfilledQuantity == null) {
            this.fulfilledQuantity = 0.0;
        }
    }

    @PreUpdate
    protected void onUpdate() {
        this.updatedAt = LocalDateTime.now();
    }

    public Requirement() {}

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }

    public Category getCategory() { return category; }
    public void setCategory(Category category) { this.category = category; }

    public String getMaterialName() { return materialName; }
    public void setMaterialName(String materialName) { this.materialName = materialName; }

    public Double getQuantityRequired() { return quantityRequired; }
    public void setQuantityRequired(Double quantityRequired) { this.quantityRequired = quantityRequired; }

    public Double getFulfilledQuantity() { return fulfilledQuantity; }
    public void setFulfilledQuantity(Double fulfilledQuantity) { this.fulfilledQuantity = fulfilledQuantity; }

    public String getUnit() { return unit; }
    public void setUnit(String unit) { this.unit = unit; }

    public Double getTargetPrice() { return targetPrice; }
    public void setTargetPrice(Double targetPrice) { this.targetPrice = targetPrice; }

    public String getVillage() { return village; }
    public void setVillage(String village) { this.village = village; }

    public String getDistrict() { return district; }
    public void setDistrict(String district) { this.district = district; }

    public String getState() { return state; }
    public void setState(String state) { this.state = state; }

    public LocalDate getRequiredByDate() { return requiredByDate; }
    public void setRequiredByDate(LocalDate requiredByDate) { this.requiredByDate = requiredByDate; }

    public String getAnimalType() { return animalType; }
    public void setAnimalType(String animalType) { this.animalType = animalType; }

    public Integer getNumberOfAnimals() { return numberOfAnimals; }
    public void setNumberOfAnimals(Integer numberOfAnimals) { this.numberOfAnimals = numberOfAnimals; }

    public boolean isEmergency() { return emergency; }
    public void setEmergency(boolean emergency) { this.emergency = emergency; }

    public UrgencyLevel getUrgency() { return urgency; }
    public void setUrgency(UrgencyLevel urgency) { this.urgency = urgency; }

    public String getQualityRequirement() { return qualityRequirement; }
    public void setQualityRequirement(String qualityRequirement) { this.qualityRequirement = qualityRequirement; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getDeliveryRequirement() { return deliveryRequirement; }
    public void setDeliveryRequirement(String deliveryRequirement) { this.deliveryRequirement = deliveryRequirement; }

    public RequirementStatus getStatus() { return status; }
    public void setStatus(RequirementStatus status) { this.status = status; }

    public List<RequirementOffer> getOffers() { return offers; }
    public void setOffers(List<RequirementOffer> offers) { this.offers = offers; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }
}

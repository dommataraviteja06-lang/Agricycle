package com.agricycle.entity;

public enum OrderStatus {
    PENDING,
    ACCEPTED,
    NEGOTIATION,
    CONFIRMED,
    TRANSPORT_ASSIGNED,
    PICKED_UP,
    IN_TRANSIT,
    DELIVERED,
    COMPLETED,
    CANCELLED,
    REJECTED,
    DISPUTED
}

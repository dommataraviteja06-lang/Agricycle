package com.agricycle.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDateTime;

@Entity
@Table(name = "transport_jobs", indexes = {
    @Index(name = "idx_transport_order", columnList = "order_id"),
    @Index(name = "idx_transport_transporter", columnList = "transporter_id"),
    @Index(name = "idx_transport_status", columnList = "status"),
    @Index(name = "idx_transport_pickup_district", columnList = "pickup_district"),
    @Index(name = "idx_transport_delivery_district", columnList = "delivery_district")
})
public class TransportJob {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "order_id", nullable = false, unique = true)
    private Order order;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "transporter_id")
    private User transporter;

    @Column(name = "pickup_location", length = 255)
    private String pickupLocation;

    @Column(name = "pickup_district", length = 100)
    private String pickupDistrict;

    @Column(name = "delivery_location", length = 255)
    private String deliveryLocation;

    @Column(name = "delivery_district", length = 100)
    private String deliveryDistrict;

    @Column(name = "weight_tons")
    private Double weightTons;

    @Column(name = "vehicle_type_required", length = 100)
    private String vehicleTypeRequired;

    @Column(name = "agreed_fare")
    private Double agreedFare;

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 30)
    private TransportStatus status = TransportStatus.REQUESTED;

    @Column(name = "is_shared_transport", nullable = false)
    private boolean sharedTransport = false;

    @Column(name = "tracking_notes", length = 1000)
    private String trackingNotes;

    @Column(name = "assigned_at")
    private LocalDateTime assignedAt;

    @Column(name = "picked_up_at")
    private LocalDateTime pickedUpAt;

    @Column(name = "delivered_at")
    private LocalDateTime deliveredAt;

    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        this.updatedAt = LocalDateTime.now();
    }

    public TransportJob() {}

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Order getOrder() { return order; }
    public void setOrder(Order order) { this.order = order; }

    public User getTransporter() { return transporter; }
    public void setTransporter(User transporter) { this.transporter = transporter; }

    public String getPickupLocation() { return pickupLocation; }
    public void setPickupLocation(String pickupLocation) { this.pickupLocation = pickupLocation; }

    public String getPickupDistrict() { return pickupDistrict; }
    public void setPickupDistrict(String pickupDistrict) { this.pickupDistrict = pickupDistrict; }

    public String getDeliveryLocation() { return deliveryLocation; }
    public void setDeliveryLocation(String deliveryLocation) { this.deliveryLocation = deliveryLocation; }

    public String getDeliveryDistrict() { return deliveryDistrict; }
    public void setDeliveryDistrict(String deliveryDistrict) { this.deliveryDistrict = deliveryDistrict; }

    public Double getWeightTons() { return weightTons; }
    public void setWeightTons(Double weightTons) { this.weightTons = weightTons; }

    public String getVehicleTypeRequired() { return vehicleTypeRequired; }
    public void setVehicleTypeRequired(String vehicleTypeRequired) { this.vehicleTypeRequired = vehicleTypeRequired; }

    public Double getAgreedFare() { return agreedFare; }
    public void setAgreedFare(Double agreedFare) { this.agreedFare = agreedFare; }

    public TransportStatus getStatus() { return status; }
    public void setStatus(TransportStatus status) { this.status = status; }

    public boolean isSharedTransport() { return sharedTransport; }
    public void setSharedTransport(boolean sharedTransport) { this.sharedTransport = sharedTransport; }

    public String getTrackingNotes() { return trackingNotes; }
    public void setTrackingNotes(String trackingNotes) { this.trackingNotes = trackingNotes; }

    public LocalDateTime getAssignedAt() { return assignedAt; }
    public void setAssignedAt(LocalDateTime assignedAt) { this.assignedAt = assignedAt; }

    public LocalDateTime getPickedUpAt() { return pickedUpAt; }
    public void setPickedUpAt(LocalDateTime pickedUpAt) { this.pickedUpAt = pickedUpAt; }

    public LocalDateTime getDeliveredAt() { return deliveredAt; }
    public void setDeliveredAt(LocalDateTime deliveredAt) { this.deliveredAt = deliveredAt; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }
}

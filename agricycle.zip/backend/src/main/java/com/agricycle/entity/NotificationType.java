package com.agricycle.entity;

public enum NotificationType {
    ORDER,
    REQUIREMENT,
    EMERGENCY,
    TRANSPORT,
    NEGOTIATION,
    SYSTEM
}

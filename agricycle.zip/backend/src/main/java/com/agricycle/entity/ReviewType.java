package com.agricycle.entity;

public enum ReviewType {
    BUYER_TO_SELLER,
    SELLER_TO_BUYER,
    BUYER_TO_TRANSPORTER
}

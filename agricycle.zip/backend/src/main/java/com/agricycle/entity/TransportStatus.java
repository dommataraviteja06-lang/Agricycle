package com.agricycle.entity;

public enum TransportStatus {
    REQUESTED,
    ASSIGNED,
    PICKED_UP,
    IN_TRANSIT,
    DELIVERED,
    COMPLETED,
    CANCELLED
}

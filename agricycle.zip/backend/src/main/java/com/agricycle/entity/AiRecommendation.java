package com.agricycle.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDateTime;

@Entity
@Table(name = "ai_recommendations", indexes = {
    @Index(name = "idx_ai_user", columnList = "user_id"),
    @Index(name = "idx_ai_material", columnList = "material_name"),
    @Index(name = "idx_ai_type", columnList = "recommendation_type")
})
public class AiRecommendation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id")
    private User user;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "harvest_id")
    private Harvest harvest;

    @Column(name = "material_name", length = 100)
    private String materialName;

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "recommendation_type", nullable = false, length = 50)
    private RecommendationType recommendationType; // BEST_USE, PRICE_ESTIMATE, DEMAND_TREND, MATCHING

    @Column(name = "match_score")
    private Double score; // e.g. 92.5 %

    @Column(name = "details_json", length = 3000)
    private String detailsJson;

    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
    }

    public AiRecommendation() {}

    public AiRecommendation(User user, Harvest harvest, String materialName, RecommendationType recommendationType, Double score, String detailsJson) {
        this.user = user;
        this.harvest = harvest;
        this.materialName = materialName;
        this.recommendationType = recommendationType;
        this.score = score;
        this.detailsJson = detailsJson;
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }

    public Harvest getHarvest() { return harvest; }
    public void setHarvest(Harvest harvest) { this.harvest = harvest; }

    public String getMaterialName() { return materialName; }
    public void setMaterialName(String materialName) { this.materialName = materialName; }

    public RecommendationType getRecommendationType() { return recommendationType; }
    public void setRecommendationType(RecommendationType recommendationType) { this.recommendationType = recommendationType; }

    public Double getScore() { return score; }
    public void setScore(Double score) { this.score = score; }

    public String getDetailsJson() { return detailsJson; }
    public void setDetailsJson(String detailsJson) { this.detailsJson = detailsJson; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}

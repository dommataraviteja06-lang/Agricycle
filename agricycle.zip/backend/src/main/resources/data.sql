-- ========================================================
-- AgriCycle – Seed & Sample Data (MySQL 8.x)
-- Realistic Demonstration Data for Telangana & Andhra Pradesh
-- ========================================================

USE `agricycle_db`;

-- Note: The Spring Boot application's DataInitializer component automatically
-- bootstraps and hashes passwords for all users (Password: Password@123),
-- creates categories, harvests, 30+ listings, 10 requirements, 20 orders,
-- transport jobs, payments, and reviews upon first run.
--
-- This script contains reference DML statements for direct MySQL Workbench execution.

SELECT 'Database schema and initial structures ready for AgriCycle!' AS Status;

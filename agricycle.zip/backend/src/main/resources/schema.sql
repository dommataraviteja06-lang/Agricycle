-- ========================================================
-- AgriCycle – Relational Database Schema (MySQL 8.x)
-- “One Harvest. Multiple Markets. Better Income. Less Waste.”
-- ========================================================

CREATE DATABASE IF NOT EXISTS `agricycle_db` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `agricycle_db`;

SET FOREIGN_KEY_CHECKS = 0;

-- 1. Users Table
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
    `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
    `email` VARCHAR(120) NOT NULL UNIQUE,
    `password` VARCHAR(255) NOT NULL,
    `full_name` VARCHAR(100) NOT NULL,
    `mobile` VARCHAR(20),
    `role` VARCHAR(30) NOT NULL,
    `status` VARCHAR(30) NOT NULL DEFAULT 'ACTIVE',
    `failed_login_attempts` INT DEFAULT 0,
    `lock_until` DATETIME NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_user_email` (`email`),
    INDEX `idx_user_role` (`role`),
    INDEX `idx_user_status` (`status`)
) ENGINE=InnoDB;

-- 2. Farmer Profiles
DROP TABLE IF EXISTS `farmer_profiles`;
CREATE TABLE `farmer_profiles` (
    `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT NOT NULL UNIQUE,
    `village` VARCHAR(100),
    `district` VARCHAR(100) NOT NULL,
    `state` VARCHAR(100) NOT NULL,
    `farm_size_acres` DOUBLE,
    `main_crops` VARCHAR(255),
    `preferred_categories` VARCHAR(255),
    `profile_image` VARCHAR(500),
    `verification_status` VARCHAR(30) NOT NULL DEFAULT 'PENDING',
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_farmer_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
    INDEX `idx_farmer_district` (`district`),
    INDEX `idx_farmer_state` (`state`)
) ENGINE=InnoDB;

-- 3. Livestock Profiles
DROP TABLE IF EXISTS `livestock_profiles`;
CREATE TABLE `livestock_profiles` (
    `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT NOT NULL UNIQUE,
    `animal_type` VARCHAR(100),
    `number_of_animals` INT,
    `feed_preference` VARCHAR(100),
    `village` VARCHAR(100),
    `district` VARCHAR(100) NOT NULL,
    `state` VARCHAR(100) NOT NULL,
    `required_fodder_types` VARCHAR(255),
    `verification_status` VARCHAR(30) NOT NULL DEFAULT 'PENDING',
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_livestock_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
    INDEX `idx_livestock_district` (`district`)
) ENGINE=InnoDB;

-- 4. Company Profiles
DROP TABLE IF EXISTS `company_profiles`;
CREATE TABLE `company_profiles` (
    `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT NOT NULL UNIQUE,
    `company_name` VARCHAR(150) NOT NULL,
    `industry_type` VARCHAR(100),
    `gst_number` VARCHAR(50),
    `registration_number` VARCHAR(50),
    `address` VARCHAR(255),
    `district` VARCHAR(100) NOT NULL,
    `state` VARCHAR(100) NOT NULL,
    `contact_person` VARCHAR(100),
    `contact_phone` VARCHAR(20),
    `verification_status` VARCHAR(30) NOT NULL DEFAULT 'PENDING',
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_company_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
    INDEX `idx_company_district` (`district`)
) ENGINE=InnoDB;

-- 5. Transport Profiles
DROP TABLE IF EXISTS `transport_profiles`;
CREATE TABLE `transport_profiles` (
    `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT NOT NULL UNIQUE,
    `vehicle_number` VARCHAR(50),
    `vehicle_type` VARCHAR(50),
    `capacity_tons` DOUBLE,
    `service_area` VARCHAR(255),
    `is_available` BOOLEAN NOT NULL DEFAULT TRUE,
    `verification_status` VARCHAR(30) NOT NULL DEFAULT 'PENDING',
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_transport_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
    INDEX `idx_transporter_service_area` (`service_area`)
) ENGINE=InnoDB;

-- 6. Vehicles Fleet
DROP TABLE IF EXISTS `vehicles`;
CREATE TABLE `vehicles` (
    `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
    `transporter_id` BIGINT NOT NULL,
    `vehicle_number` VARCHAR(50) NOT NULL,
    `vehicle_type` VARCHAR(50) NOT NULL,
    `capacity_tons` DOUBLE NOT NULL,
    `district` VARCHAR(100),
    `is_available` BOOLEAN NOT NULL DEFAULT TRUE,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_vehicle_transporter` FOREIGN KEY (`transporter_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 7. Harvests
DROP TABLE IF EXISTS `harvests`;
CREATE TABLE `harvests` (
    `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
    `farmer_id` BIGINT NOT NULL,
    `crop_name` VARCHAR(100) NOT NULL,
    `crop_variety` VARCHAR(100),
    `harvest_date` DATE NOT NULL,
    `total_quantity` DOUBLE NOT NULL,
    `unit` VARCHAR(30) NOT NULL,
    `village` VARCHAR(100),
    `district` VARCHAR(100) NOT NULL,
    `state` VARCHAR(100) NOT NULL,
    `image_url` VARCHAR(500),
    `description` VARCHAR(1000),
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT `fk_harvest_farmer` FOREIGN KEY (`farmer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
    INDEX `idx_harvest_farmer` (`farmer_id`),
    INDEX `idx_harvest_crop` (`crop_name`),
    INDEX `idx_harvest_district` (`district`)
) ENGINE=InnoDB;

-- 8. Categories
DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
    `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(100) NOT NULL UNIQUE,
    `slug` VARCHAR(100),
    `category_type` VARCHAR(50) NOT NULL,
    `description` VARCHAR(255),
    `icon` VARCHAR(100),
    `is_active` BOOLEAN NOT NULL DEFAULT TRUE,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_category_type` (`category_type`),
    INDEX `idx_category_active` (`is_active`)
) ENGINE=InnoDB;

-- 9. Listings (with unique Digital Lot ID and spatial indexing)
DROP TABLE IF EXISTS `listings`;
CREATE TABLE `listings` (
    `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
    `seller_id` BIGINT NOT NULL,
    `harvest_id` BIGINT NULL,
    `category_id` BIGINT NOT NULL,
    `title` VARCHAR(150) NOT NULL,
    `product_material_name` VARCHAR(100) NOT NULL,
    `quantity` DOUBLE NOT NULL,
    `available_quantity` DOUBLE NOT NULL,
    `unit` VARCHAR(30) NOT NULL,
    `price_per_unit` DOUBLE NOT NULL,
    `village` VARCHAR(100),
    `district` VARCHAR(100) NOT NULL,
    `state` VARCHAR(100) NOT NULL,
    `latitude` DOUBLE,
    `longitude` DOUBLE,
    `lot_id` VARCHAR(50) UNIQUE,
    `images_json` VARCHAR(1000),
    `description` VARCHAR(2000),
    `suitable_use` VARCHAR(255),
    `listing_status` VARCHAR(30) NOT NULL DEFAULT 'APPROVED',
    `verification_status` VARCHAR(30) NOT NULL DEFAULT 'VERIFIED',
    `view_count` INT DEFAULT 0,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT `fk_listing_seller` FOREIGN KEY (`seller_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_listing_harvest` FOREIGN KEY (`harvest_id`) REFERENCES `harvests` (`id`) ON DELETE SET NULL,
    CONSTRAINT `fk_listing_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
    INDEX `idx_listing_seller` (`seller_id`),
    INDEX `idx_listing_lot_id` (`lot_id`),
    INDEX `idx_listing_status` (`listing_status`),
    INDEX `idx_listing_district` (`district`),
    INDEX `idx_listing_created` (`created_at`)
) ENGINE=InnoDB;

-- 10. Requirements (Company Bulk Procurement + Emergency Fodder)
DROP TABLE IF EXISTS `requirements`;
CREATE TABLE `requirements` (
    `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT NOT NULL,
    `category_id` BIGINT NULL,
    `material_name` VARCHAR(100) NOT NULL,
    `quantity_required` DOUBLE NOT NULL,
    `fulfilled_quantity` DOUBLE DEFAULT 0.0,
    `unit` VARCHAR(30) NOT NULL,
    `target_price` DOUBLE,
    `village` VARCHAR(100),
    `district` VARCHAR(100) NOT NULL,
    `state` VARCHAR(100) NOT NULL,
    `required_by_date` DATE,
    `animal_type` VARCHAR(100),
    `number_of_animals` INT,
    `is_emergency` BOOLEAN NOT NULL DEFAULT FALSE,
    `urgency` VARCHAR(30) NOT NULL DEFAULT 'MEDIUM',
    `quality_requirement` VARCHAR(500),
    `description` VARCHAR(1500),
    `delivery_requirement` VARCHAR(500),
    `status` VARCHAR(30) NOT NULL DEFAULT 'OPEN',
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT `fk_requirement_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_requirement_cat` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL,
    INDEX `idx_requirement_status` (`status`),
    INDEX `idx_requirement_urgency` (`urgency`),
    INDEX `idx_requirement_district` (`district`)
) ENGINE=InnoDB;

-- 11. Requirement Offers (Reverse Marketplace Supplier Proposals)
DROP TABLE IF EXISTS `requirement_offers`;
CREATE TABLE `requirement_offers` (
    `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
    `requirement_id` BIGINT NOT NULL,
    `supplier_id` BIGINT NOT NULL,
    `offered_quantity` DOUBLE NOT NULL,
    `price_per_unit` DOUBLE NOT NULL,
    `proposed_delivery_date` DATE,
    `notes` VARCHAR(500),
    `status` VARCHAR(30) NOT NULL DEFAULT 'SUBMITTED',
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_offer_requirement` FOREIGN KEY (`requirement_id`) REFERENCES `requirements` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_offer_supplier` FOREIGN KEY (`supplier_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 12. Orders
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
    `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
    `order_number` VARCHAR(60) NOT NULL UNIQUE,
    `buyer_id` BIGINT NOT NULL,
    `seller_id` BIGINT NOT NULL,
    `requirement_id` BIGINT NULL,
    `total_amount` DOUBLE NOT NULL,
    `status` VARCHAR(30) NOT NULL DEFAULT 'PENDING',
    `delivery_address` VARCHAR(300),
    `district` VARCHAR(100),
    `state` VARCHAR(100),
    `special_instructions` VARCHAR(500),
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT `fk_order_buyer` FOREIGN KEY (`buyer_id`) REFERENCES `users` (`id`),
    CONSTRAINT `fk_order_seller` FOREIGN KEY (`seller_id`) REFERENCES `users` (`id`),
    CONSTRAINT `fk_order_req` FOREIGN KEY (`requirement_id`) REFERENCES `requirements` (`id`) ON DELETE SET NULL,
    INDEX `idx_order_number` (`order_number`),
    INDEX `idx_order_buyer` (`buyer_id`),
    INDEX `idx_order_seller` (`seller_id`),
    INDEX `idx_order_status` (`status`)
) ENGINE=InnoDB;

-- 13. Order Items
DROP TABLE IF EXISTS `order_items`;
CREATE TABLE `order_items` (
    `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
    `order_id` BIGINT NOT NULL,
    `listing_id` BIGINT NULL,
    `material_name` VARCHAR(100) NOT NULL,
    `quantity` DOUBLE NOT NULL,
    `unit` VARCHAR(30) NOT NULL,
    `price_per_unit` DOUBLE NOT NULL,
    `total_price` DOUBLE NOT NULL,
    CONSTRAINT `fk_item_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_item_listing` FOREIGN KEY (`listing_id`) REFERENCES `listings` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB;

-- 14. Order Negotiations
DROP TABLE IF EXISTS `order_negotiations`;
CREATE TABLE `order_negotiations` (
    `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
    `order_id` BIGINT NOT NULL,
    `proposed_by_user_id` BIGINT NOT NULL,
    `proposed_price` DOUBLE NOT NULL,
    `proposed_quantity` DOUBLE NOT NULL,
    `proposed_delivery_date` DATE,
    `notes` VARCHAR(500),
    `status` VARCHAR(30) NOT NULL DEFAULT 'PROPOSED',
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_neg_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_neg_user` FOREIGN KEY (`proposed_by_user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB;

-- 15. Transport Jobs
DROP TABLE IF EXISTS `transport_jobs`;
CREATE TABLE `transport_jobs` (
    `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
    `order_id` BIGINT NOT NULL UNIQUE,
    `transporter_id` BIGINT NULL,
    `pickup_location` VARCHAR(255),
    `pickup_district` VARCHAR(100),
    `delivery_location` VARCHAR(255),
    `delivery_district` VARCHAR(100),
    `weight_tons` DOUBLE,
    `vehicle_type_required` VARCHAR(100),
    `agreed_fare` DOUBLE,
    `status` VARCHAR(30) NOT NULL DEFAULT 'REQUESTED',
    `is_shared_transport` BOOLEAN NOT NULL DEFAULT FALSE,
    `tracking_notes` VARCHAR(1000),
    `assigned_at` DATETIME NULL,
    `picked_up_at` DATETIME NULL,
    `delivered_at` DATETIME NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT `fk_job_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_job_transporter` FOREIGN KEY (`transporter_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
    INDEX `idx_transport_status` (`status`)
) ENGINE=InnoDB;

-- 16. Payments (Escrow status tracking without card/PII storage)
DROP TABLE IF EXISTS `payments`;
CREATE TABLE `payments` (
    `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
    `order_id` BIGINT NOT NULL UNIQUE,
    `transaction_reference` VARCHAR(100) UNIQUE,
    `amount` DOUBLE NOT NULL,
    `status` VARCHAR(30) NOT NULL DEFAULT 'PENDING',
    `payment_method` VARCHAR(50),
    `paid_at` DATETIME NULL,
    `failure_reason` VARCHAR(255),
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_payment_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 17. In-App Notifications
DROP TABLE IF EXISTS `notifications`;
CREATE TABLE `notifications` (
    `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
    `recipient_id` BIGINT NOT NULL,
    `title` VARCHAR(150) NOT NULL,
    `message` VARCHAR(1000) NOT NULL,
    `type` VARCHAR(30) NOT NULL DEFAULT 'SYSTEM',
    `reference_id` BIGINT NULL,
    `is_read` BOOLEAN NOT NULL DEFAULT FALSE,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_notif_recipient` FOREIGN KEY (`recipient_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
    INDEX `idx_notif_recipient` (`recipient_id`)
) ENGINE=InnoDB;

-- 18. Reviews & Ratings
DROP TABLE IF EXISTS `reviews`;
CREATE TABLE `reviews` (
    `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
    `order_id` BIGINT NOT NULL,
    `reviewer_id` BIGINT NOT NULL,
    `target_user_id` BIGINT NOT NULL,
    `review_type` VARCHAR(30) NOT NULL,
    `rating` INT NOT NULL,
    `comment` VARCHAR(1000),
    `is_reported` BOOLEAN NOT NULL DEFAULT FALSE,
    `report_reason` VARCHAR(255),
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `uk_order_reviewer_type` UNIQUE (`order_id`, `reviewer_id`, `review_type`),
    CONSTRAINT `fk_review_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_review_reviewer` FOREIGN KEY (`reviewer_id`) REFERENCES `users` (`id`),
    CONSTRAINT `fk_review_target` FOREIGN KEY (`target_user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB;

-- 19. Disputes
DROP TABLE IF EXISTS `disputes`;
CREATE TABLE `disputes` (
    `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
    `order_id` BIGINT NOT NULL,
    `raised_by_user_id` BIGINT NOT NULL,
    `reason` VARCHAR(150) NOT NULL,
    `description` VARCHAR(1500) NOT NULL,
    `status` VARCHAR(30) NOT NULL DEFAULT 'OPEN',
    `resolution_notes` VARCHAR(1500),
    `resolved_by_admin_id` BIGINT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `resolved_at` DATETIME NULL,
    CONSTRAINT `fk_dispute_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_dispute_raised_by` FOREIGN KEY (`raised_by_user_id`) REFERENCES `users` (`id`),
    CONSTRAINT `fk_dispute_admin` FOREIGN KEY (`resolved_by_admin_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB;

-- 20. Audit Logs
DROP TABLE IF EXISTS `audit_logs`;
CREATE TABLE `audit_logs` (
    `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
    `actor_id` BIGINT NULL,
    `actor_email` VARCHAR(120),
    `action` VARCHAR(100) NOT NULL,
    `resource_type` VARCHAR(50),
    `resource_id` BIGINT NULL,
    `details` VARCHAR(2000),
    `ip_address` VARCHAR(50),
    `result` VARCHAR(30),
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_audit_actor` (`actor_id`),
    INDEX `idx_audit_action` (`action`)
) ENGINE=InnoDB;

-- 21. AI Recommendations Log
DROP TABLE IF EXISTS `ai_recommendations`;
CREATE TABLE `ai_recommendations` (
    `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT NULL,
    `harvest_id` BIGINT NULL,
    `material_name` VARCHAR(100),
    `recommendation_type` VARCHAR(50) NOT NULL,
    `match_score` DOUBLE,
    `details_json` VARCHAR(3000),
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_ai_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
    CONSTRAINT `fk_ai_harvest` FOREIGN KEY (`harvest_id`) REFERENCES `harvests` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB;

SET FOREIGN_KEY_CHECKS = 1;

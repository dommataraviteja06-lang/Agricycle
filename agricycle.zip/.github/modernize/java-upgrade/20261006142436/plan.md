# Upgrade Plan: AgriCycle (20261006142436)

- **Generated**: 2026-10-06 21:12:00 +05:30
- **HEAD Branch**: master
- **HEAD Commit ID**: N/A (not exposed by the repository status tool)

## Available Tools

**JDKs**
- JDK 21: not available (baseline will be skipped)
- JDK 25.0.4.1: `C:\Program Files\Java\jdk-25.0.4.1\bin` (target JDK, used by upgrade verification)

**Build Tools**
- Maven 3.9.9: `C:\Users\domma\maven\apache-maven-3.9.9\bin`
- Maven Wrapper: not present

## Guidelines

> Note: You can add any specific guidelines or constraints for the upgrade process here if needed, bullet points are preferred.

## Options

- Working branch: appmod/java-upgrade-20261006142436
- Run tests before and after the upgrade: true
- Execution mode: auto-execution requested

## Upgrade Goals

- Upgrade the Java runtime and compilation target from Java 21 to Java 25 LTS.

## Technology Stack

| Technology/Dependency | Current | Min Compatible Version | Why Incompatible |
| --------------------- | ------- | ---------------------- | ---------------- |
| Java | 21 | 25 | User requested Java 25 LTS |
| Spring Boot parent | 3.3.4 | 3.5.16 | Use a stable Spring Boot line with Java 25 support |
| Maven | 3.9.9 | 3.9.9 | Compatible with JDK 25; no wrapper present |
| maven-compiler-plugin | Spring Boot parent managed | Parent-managed | Use Java 25 source and target values |
| Docker builder JDK | Maven 3.9.9 / Eclipse Temurin 21 | Maven 3.9.16 / Eclipse Temurin 25 | Use a published Maven image tag that provides JDK 25 |
| Docker runtime JRE | Eclipse Temurin 21 | Eclipse Temurin 25 | Runtime image must execute Java 25 bytecode |
| GitHub Actions JDK | Temurin 21 | Temurin 25 | CI must validate the target runtime |
| Springdoc OpenAPI | 2.6.0 | 2.8.17 | Spring Boot 3.5 compatibility requires Springdoc 2.8.x |

## Derived Upgrades

- Upgrade the Spring Boot parent from 3.3.4 to 3.5.16. Spring Boot 3.3.4 predates Java 25 support; 3.5.16 is the latest stable 3.5 release in Maven Central metadata and supports Java 25 while retaining the Spring Boot 3 / Jakarta baseline.
- Upgrade Springdoc OpenAPI from 2.6.0 to 2.8.17 because Springdoc 2.8.x is the compatible line for Spring Boot 3.5.
- Update Maven Java source and target properties to 25 so compilation emits Java 25 bytecode.
- Update container builder and runtime images, GitHub Actions, and Java-version documentation to Java 25 to avoid compiling or deploying a Java 25 artifact on a Java 21 runtime. The Maven 3.9.9 builder image is not published for JDK 25; use the verified Maven 3.9.16 JDK 25 image.

## Impact Analysis

### Dependency Changes

| File | Dependency | Current | Action | Target | Reason |
|------|-----------|---------|--------|--------|--------|
| pom.xml | spring-boot-starter-parent | 3.3.4 | upgrade | 3.5.16 | Align framework support with Java 25 |
| pom.xml | java.version | 21 | upgrade | 25 | Set Spring Boot and build Java version |
| pom.xml | maven.compiler.source | 21 | upgrade | 25 | Compile with Java 25 source compatibility |
| pom.xml | maven.compiler.target | 21 | upgrade | 25 | Emit Java 25 bytecode |
| pom.xml | springdoc-openapi-starter-webmvc-ui | 2.6.0 | upgrade | 2.8.17 | Spring Boot 3.5 compatibility |

### Source Code Changes

No Java source changes are identified for this runtime target.

### Configuration Changes

| File | Property/Setting | Current | Required Change | Reason |
|------|------------------|---------|-----------------|--------|
| Dockerfile | Builder image | `maven:3.9.9-eclipse-temurin-21-alpine` | Use `maven:3.9.16-eclipse-temurin-25-alpine` | Use a published builder image with the Java 25 JDK |
| Dockerfile | Runtime image | `eclipse-temurin:21-jre-alpine` | Use `eclipse-temurin:25-jre-alpine` | Run Java 25 bytecode |

### CI/CD Changes

| File | Location | Current | Required Change |
|------|----------|---------|----------------|
| .github/workflows/ci-cd.yml | Build job name and setup-java step | Java 21 / Temurin 21 | Update to Java 25 / Temurin 25 |

### Documentation Changes

| File | Location | Current | Required Change |
|------|----------|---------|----------------|
| README.md | Technology stack and prerequisites | Java 21 / 25, Spring Boot 3.3.4, Springdoc 2.6.0; JDK 21 or 25 | Document Java 25, Spring Boot 3.5.16, Springdoc 2.8.17; require JDK 25 |
| docs/DEPLOYMENT_GUIDE.md | Container architecture and standalone installation | Java 21, Spring Boot 3.3.4, OpenJDK 21 package | Update framework/runtime details and JRE installation to Java 25 |
| docs/PROJECT_HANDOVER.md | Executive overview and technology matrix | Java 21, Spring Boot 3.3.4, Springdoc 2.6.0 | Update to Java 25, Spring Boot 3.5.16, Springdoc 2.8.17 |
| docs/PRESENTATION_DECK.md | Technology stack, Java descriptions, CI description | Java 21, Spring Boot 3.3.4 | Update Java/runtime and framework versions to Java 25 and Spring Boot 3.5.16 |

### Risks & Warnings

- **Spring Boot compatibility**: Spring Boot 3.3.4 predates Java 25. **Mitigation**: Upgrade to the latest stable Spring Boot 3.5.x release and run a clean compilation and the complete test suite on JDK 25.
- **Existing local modifications**: The worktree contains unrelated uncommitted changes, including changes in some documentation files touched by this upgrade. **Mitigation**: Use the repository prepare-branch operation to preserve those edits in a stash before creating the isolated upgrade branch; apply only the planned targeted edits and do not discard unrelated work.
- **Baseline unavailable**: JDK 21 is not installed, so a pre-upgrade build/test baseline cannot be run locally. **Mitigation**: Record the baseline as skipped and perform target-JDK compilation and tests after the upgrade.

## Upgrade Steps

- Step 1: Setup Environment
  - **Rationale**: Confirm the required JDK 25 and Maven are usable before changing project configuration.
  - **Changes to Make**: No project files; verify the already available target JDK and Maven.
  - **Verification**: List installed JDKs; JDK 25 must be available. Maven 3.9.9 is available.
- Step 2: Setup Baseline
  - **Rationale**: Capture current build/test status where the current JDK is available.
  - **Changes to Make**: None; Java 21 is not installed, so skip baseline build and tests.
  - **Verification**: Record baseline as skipped because JDK 21 is unavailable.
- Step 3: Upgrade Java 25 Runtime and Compatibility
  - **Rationale**: Align framework, compiler, container, CI and user-facing setup instructions with the requested runtime.
  - **Changes to Make**: Apply all Dependency Changes, Configuration Changes, CI/CD Changes, and Documentation Changes above.
  - **Verification**: `mvn clean test-compile -q` with JDK 25; production and test sources compile.
- Step 4: CVE Validation and Fix
  - **Rationale**: Check the direct dependency set after the framework upgrade and patch any reported vulnerabilities.
  - **Changes to Make**: Upgrade vulnerable direct dependencies to patched compatible versions where necessary.
  - **Verification**: Scan dependencies, compile after any fixes, and re-scan to confirm remediation.
- Step 5: Final Validation
  - **Rationale**: Confirm the requested runtime is configured consistently and all tests pass on the target JDK.
  - **Changes to Make**: Resolve any issues found during target-JDK validation; no deferred workarounds.
  - **Verification**: `mvn clean test` using JDK 25; all tests pass.
